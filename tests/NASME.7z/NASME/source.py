import numpy as np
import pandas as pd
import os
import itertools
import argparse
# import traceback
import helper

parser = argparse.ArgumentParser(description="NASME 1.0", formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument("-m", "--mode", help="'opt' or 'sim'", required=True)
parser.add_argument("-s", "--solver", help="'ipopt', 'scip', or 'glpk'", default="ipopt", required=False)
parser.add_argument("-p", "--solver-path", help="Path to the solver executable", required=False)
parser.add_argument("-t", "--tolerance", help="Number of digits of tolerance, e.g., 5 --> 1E-5", default="5", required=False)
args = parser.parse_args()

if args.mode.lower() != "opt" and args.mode.lower() != "sim":
    print("Error: mode should be 'opt' or 'sim'")
    exit()

if args.mode.lower() == "opt":
    import pyomo.environ as pyo
    from pyomo.util.model_size import build_model_size_report

    if args.solver.lower() == "ipopt":
        solver = pyo.SolverFactory('ipopt', executable="C:\\dev\\Ipopt-3.14.12-win64-msvs2019-md\\bin\\ipopt.exe", symbolic_solver_labels=True)
        solver.options['print_level'] = 5  # Set the verbosity of IPOPT
        solver.options['output_file'] = 'ipopt_output.txt'  # Specify a file to write IPOPT’s output
        solver.options['print_timing_statistics'] = 'yes'
        solver.options['file_print_level'] = 5  # Set the verbosity of the output file
        solver.options['tol'] = 10 ** -int(args.tolerance)

    elif args.solver.lower() == "scip":
        solver = pyo.SolverFactory('scip', executable="scip.exe")

    elif args.solver.lower() == "glpk":
        solver = pyo.SolverFactory('glpk', executable="C:\\dev\\glpk-4.65\\w64\\glpsol.exe")

    if not solver.available():
        print("Solver not available")

    model = pyo.ConcreteModel()
    model.dual = pyo.Suffix(direction=pyo.Suffix.IMPORT)

if args.mode.lower() == "sim":
    model = helper.makeModel("variables_input")
    setattr(model, "CONSUMMAX", None)
    setattr(model, "CITRDEFREG", None)
    setattr(model, "BERSEEROT1", None)
    setattr(model, "CCDPMAX", None)
    setattr(model, "CONSUMMIN", None)
    setattr(model, "COTDEFREG", None)
    setattr(model, "CROPAREA", None)
    setattr(model, "CSTDEFLAB", None)
    setattr(model, "CSTDEFLREC", None)
    setattr(model, "CSTDEFOINP", None)
    setattr(model, "CSTDEFPM", None)
    setattr(model, "DIVADEF", None)
    setattr(model, "DIVARICDEF", None)
    setattr(model, "DGWBAL", None)
    setattr(model, "DSBALCNR", None)
    setattr(model, "DSBALIP1", None)
    setattr(model, "DSBALIP2", None)
    setattr(model, "DSFEEDBAL", None)
    setattr(model, "EXPORT", None)
    setattr(model, "FCDIST", None)
    setattr(model, "FDCMAX", None)
    setattr(model, "FDCOMP", None)
    setattr(model, "FDCTOT", None)
    setattr(model, "FEEDCDET", None)
    setattr(model, "FEEDTDET", None)
    setattr(model, "FEEDMDET", None)
    setattr(model, "FEEDDET", None)
    setattr(model, "FLAXROT", None)
    setattr(model, "GCOMPAV", None)
    setattr(model, "IMPORT", None)
    setattr(model, "LABBAL", None)
    setattr(model, "LANDCON", None)
    setattr(model, "NCOMPAV", None)
    setattr(model, "NILEBAL", None)
    setattr(model, "OBJFN", None)
    setattr(model, "POTATOROT", None)
    setattr(model, "PRDCROP", None)
    setattr(model, "PRDLVST", None)
    setattr(model, "QCNSCDET", None)
    setattr(model, "RICDEFREG", None)
    setattr(model, "RICEDEFNAT", None)
    setattr(model, "RTRADEBAL", None)
    setattr(model, "RTRAPRBAL", None)
    setattr(model, "SBDPMAX", None)
    setattr(model, "SBEDEFREG", None)
    setattr(model, "SCADEFREG", None)
    setattr(model, "SBEETROT", None)
    setattr(model, "SBERSEEROT", None)
    setattr(model, "SCDPMAX", None)
    setattr(model, "VEGWDEFREG", None)
    setattr(model, "VEGNDEFREG", None)
    setattr(model, "VEGSDEFREG", None)
    setattr(model, "WATERCOST", None)
    setattr(model, "XCDEFNAT", None)
    setattr(model, "VEGETW", None)
    setattr(model, "VEGETS", None)
    setattr(model, "VEGETN", None)
    setattr(model, "TOMATW", None)
    setattr(model, "TOMATS", None)
    setattr(model, "TOMATN", None)
    setattr(model, "CROPMIN", None)

scalars = helper.loadScalars("scalars/scalars.xlsx")



sets = {
    # primary and processed crop and livestock commodities
    "C": [
        ("BARLEY"),  # barley
        ("CITRUS"),  # all penennial fruits
        ("CTONELS"),  # ginned extra long staple cotton
        ("CTONLS"),  # ginned long staple cotton
        ("FBEAN"),  # fava bean
        ("FLAX"),  # flax (fibres & linseed)
        ("FXFIB"),  # flax fibres
        ("GRDNUT"),  # groundnuts
        ("LEGUME"),
        ("LENTIL"),  # lentil
        ("MAIZE"),  # maize
        ("ONION"),  # onion
        ("PADDY"),  # unmilled rice
        ("POTATO"),  # potato
        ("RICE"),  # milled paddy
        ("SEEDELS"),  # extra long staple seed cotton
        ("SEEDLS"),  # long staple seed cotton
        ("SESAME"),
        ("SGBEET"),  # sugarbeet
        ("SGCANE"),  # sugarcane for industrial processing
        ("SORGHUM"),  # sorghum
        ("SOYBEAN"),  # soybean
        ("SUGAR"),  # from sugarcane and sugarbeet
        ("TOMATO"),  # tomato
        ("VEGET"),
        ("VEG-OIL"),
        ("WHEAT"),  # wheat (grain)
        ("WHEATF"),  # wheat flour
        ("MAIZESTA"),  # maize stalks without cobs
        ("WHEATSTR"),  # dry wheat straw
        ("BARLEYSTR"),  # dry barley straw
        ("RICESTR"),  # dry rice straw
        ("FBEANFOD"),  # fava bean residues
        ("GRDNUTFOD"),  # groundnut haulms
        ("LENTILFOD"),  # lentil crop residues
        ("VEGETFOD"),  # vegetable fodder
        ("SCANEFOD"),  # fresh sugarcane tops
        ("SBEETFOD"),  # fresh sugarbeet leaves
        ("BRAN"),  # rice and wheat bran
        ("COTSCAKE"),  # cotton seed cake decorticated
        ("SOYACAKE"),  # soya cake
        ("SOYAFOD"),  # soybean haulms
        ("GNUTCAKE"),  # groundnut cake
        ("FLSECAKE"),  # flax sesame cake
        ("SBEETMOL"),  # sugar beet molasses
        ("SCANEMOL"),  # sugar cane molasses
        ("SBEETPULP"),  # dried sugar beet pulp
        ("BERSEEM"),  # berseem
        ("IMILK"),  # industrial processing milk
        ("BMILK"),  # buffalo milk with more than 5.5% fat
        ("CMILK"),  # cow milk
        ("VEAL"),  # veal
        ("FBEEF"),  # fattener beef and chilled import beef
        ("CBEEF"),  # cull beef and frozen import beef
        ("SGMT"),  # sheep and goat meat
        ("EGGS"),  # poultry eggs
        ("PMEAT"),  # poultry meat
        ("HUSK"),  # rice husk
        ("COTSTA"),  # cotton staks
        ("GNUTSH"),  # groundnut shells
    ],
    # final livestock outputs
    "CA": [  # spans set (C)
        ("BMILK"),
        ("CBEEF"),
        ("CMILK"),
        ("EGGS"),
        ("FBEEF"),
        ("IMILK"),
        ("PMEAT"),
        ("SGMT"),
        ("VEAL"),
    ],
    # crop commodities
    "CC": [  # spans set (C)
    ],
    # commodity inputs to processing and packaging
    "CIP": [  # spans set (C)
        ("WHEAT"),
        ("FLAX"),
        ("GRDNUT"),
        ("SGBEET"),
        ("SEEDLS"),
        ("SEEDELS"),
        ("PADDY"),
        ("SESAME"),
        ("SOYBEAN"),
        ("SGCANE"),
        ("VEGET"),
        ("TOMATO"),
        ("CITRUS"),
    ],
    # commodities consumed nationally
    "CN": [  # spans set (C)
        ("BARLEY"),
        ("CITRUS"),
        ("CTONELS"),
        ("CTONLS"),
        ("FBEAN"),
        ("FXFIB"),
        ("GRDNUT"),
        ("LEGUME"),
        ("LENTIL"),
        ("MAIZE"),
        ("ONION"),
        ("POTATO"),
        ("RICE"),
        ("SESAME"),
        ("SORGHUM"),
        ("SOYBEAN"),
        ("SUGAR"),
        ("TOMATO"),
        ("VEGET"),
        ("VEG-OIL"),
        ("WHEATF"),
        ("IMILK"),
        ("BMILK"),
        ("CMILK"),
        ("VEAL"),
        ("FBEEF"),
        ("CBEEF"),
        ("SGMT"),
        ("EGGS"),
        ("PMEAT"),
    ],
    # commodities consumed nationally as food
    "FCN": [  # spans set (C)
        ("BARLEY"),
        ("CITRUS"),
        ("FBEAN"),
        ("GRDNUT"),
        ("LEGUME"),
        ("LENTIL"),
        ("MAIZE"),
        ("ONION"),
        ("POTATO"),
        ("RICE"),
        ("SESAME"),
        ("SORGHUM"),
        ("SOYBEAN"),
        ("SUGAR"),
        ("TOMATO"),
        ("VEGET"),
        ("VEG-OIL"),
        ("WHEATF"),
        ("IMILK"),
        ("BMILK"),
        ("CMILK"),
        ("VEAL"),
        ("FBEEF"),
        ("CBEEF"),
        ("SGMT"),
        ("EGGS"),
        ("PMEAT"),
    ],
    # commodities traded regionally
    "CTR": [  # spans set (C)
        ("BARLEY"),
        ("CITRUS"),
        ("CTONELS"),
        ("CTONLS"),
        ("FBEAN"),
        ("FXFIB"),
        ("GRDNUT"),
        ("LENTIL"),
        ("MAIZE"),
        ("ONION"),
        ("POTATO"),
        ("RICE"),
        ("SESAME"),
        ("SORGHUM"),
        ("SOYBEAN"),
        ("SUGAR"),
        ("VEG-OIL"),
        ("WHEAT"),
        ("BRAN"),
        ("COTSCAKE"),
        ("SOYACAKE"),
        ("GNUTCAKE"),
        ("FLSECAKE"),
        ("SBEETMOL"),
        ("SCANEMOL"),
        ("SBEETPULP"),
        ("VEAL"),
        ("FBEEF"),
        ("CBEEF"),
        ("SGMT"),
        ("EGGS"),
        ("PMEAT"),
    ],
    # crop commodities consumed nationally fresh
    "CNF": [  # spans set (C)
        ("CITRUS"),
        ("LEGUME"),
        ("ONION"),
        ("POTATO"),
        ("TOMATO"),
        ("VEGET"),
    ],
    # crop commodities consumed nationally dry
    "CND": [  # spans set (C)
        ("BARLEY"),
        ("CTONELS"),
        ("CTONLS"),
        ("FBEAN"),
        ("FXFIB"),
        ("GRDNUT"),
        ("LENTIL"),
        ("MAIZE"),
        ("RICE"),
        ("SESAME"),
        ("SORGHUM"),
        ("SOYBEAN"),
        ("SUGAR"),
        ("VEG-OIL"),
        ("WHEATF"),
    ],
    # output products from processing
    "COP": [  # spans set (C)
        ("WHEATF"),
        ("SUGAR"),
        ("CTONLS"),
        ("CTONELS"),
        ("RICE"),
        ("VEG-OIL"),
        ("FXFIB"),
        ("COTSCAKE"),
        ("FLSECAKE"),
        ("SOYACAKE"),
        ("GNUTCAKE"),
        ("BRAN"),
        ("SBEETMOL"),
        ("SCANEMOL"),
        ("SBEETPULP"),
        ("HUSK"),
        ("GNUTSH"),
    ],
    # final and intermediate crop commodities
    "CNPP": [  # spans set (C)
        ("GRDNUT"),
        ("SESAME"),
        ("SOYBEAN"),
    ],
    # final crop commodities produced from CNPP
    "CNPF": [  # spans set (C)
        ("FLSECAKE"),
        ("GNUTCAKE"),
        ("SOYACAKE"),
        ("VEG-OIL"),
    ],
    # traded commodities as used for virtual water calculation
    "TRADE": [  # spans set (C)
        ("BARLEY"),
        ("CITRUS"),
        ("CTONELS"),
        ("CTONLS"),
        ("FBEAN"),
        ("FXFIB"),
        ("GRDNUT"),
        ("LEGUME"),
        ("LENTIL"),
        ("MAIZE"),
        ("ONION"),
        ("POTATO"),
        ("RICE"),
        ("SESAME"),
        ("SORGHUM"),
        ("SOYBEAN"),
        ("SUGAR"),
        ("TOMATO"),
        ("VEGET"),
        ("VEG-OIL"),
        ("WHEATF"),
        ("WHEAT"),
    ],
    # traded commodities as used for virtual water calculation
    "TRADE2": [  # spans set (C)
        ("BARLEY"),
        ("CITRUS"),
        ("CTONELS"),
        ("CTONLS"),
        ("FBEAN"),
        ("FXFIB"),
        ("GRDNUT"),
        ("LEGUME"),
        ("LENTIL"),
        ("MAIZE"),
        ("ONION"),
        ("POTATO"),
        ("RICE"),
        ("SESAME"),
        ("SORGHUM"),
        ("SOYBEAN"),
        ("SUGAR"),
        ("TOMATO"),
        ("VEGET"),
        ("WHEAT"),
    ],
    # crop commodities suitable for power production
    "BURN": [  # spans set (C)
        ("MAIZESTA"),
        ("RICESTR"),
        ("WHEATSTR"),
        ("BARLEYSTR"),
        ("HUSK"),
        ("COTSTA"),
        ("GNUTSH"),
    ],
    # crop inputs
    "INP": [
        ("NLINCST"),  # non labour inputs costs
        ("IRRICST"),  # irrigation costs
        ("RENT"),  # land rent
    ],
    # crop classification - plant name
    "XC": [
        ("BARLEY1"),  # barley
        ("CITRUS1"),  # orchards with perennial fruit trees
        ("FBEAN1"),  # fava bean
        ("FLAX1"),  # flax
        ("GNUT1"),  # ground nut
        ("LBSEEM1"),  # long berseem
        ("LENTIL1"),  # lentil
        ("MAIZEN1"),  # nili maize
        ("MAIZES1"),  # summer maize
        ("OLGUME1"),  # other legumes
        ("ONIONS1"),  # summer onion
        ("ONIONW1"),  # winter onion
        ("PADDY1"),  # rice
        ("PTATON1"),  # nili potato
        ("PTATOS1"),  # summer potato
        ("PTATOW1"),  # winter potato
        ("SBEAN1"),  # soybeans
        ("SBEET1"),  # sugar beet
        ("SBSEMW1"),  # short berseem winter
        ("SCANE1"),  # sugar cane for sugar processing only
        ("SDELS1"),  # extra long staple cotton
        ("SDLS1"),  # long staple cotton
        ("SESAME1"),  # sesame
        ("SORGMN1"),  # nili sorghum
        ("SORGMS1"),  # summer sorghum
        ("TMATON1"),  # nili tomato
        ("TMATOS1"),  # summer tomato
        ("TMATOW1"),  # winter tomato
        ("VEGETN1"),  # nili vegetables
        ("VEGETS1"),  # summer vegetables
        ("VEGETW1"),  # winter vegetables
        ("WHEAT1"),  # wheat
    ],
    # water consumption categories
    "XCCROP": [
        ("XC2000"),
        ("XC3500"),
        ("XC5000"),
        ("XC5001"),
    ],
    # map of water consumption categories and crops
    "MAPXCCROP": [  # spans set (XCCROP, XC)
        ("XC2000", "MAIZEN1"),  # expanded from XC2000.(MAIZEN1;FBEAN1;SBSEMW1;VEGETN1;SORGMN1;PTATON1;TMATON1;VEGETW1;TMATOW1)
        ("XC2000", "FBEAN1"),  # expanded from XC2000.(MAIZEN1;FBEAN1;SBSEMW1;VEGETN1;SORGMN1;PTATON1;TMATON1;VEGETW1;TMATOW1)
        ("XC2000", "SBSEMW1"),  # expanded from XC2000.(MAIZEN1;FBEAN1;SBSEMW1;VEGETN1;SORGMN1;PTATON1;TMATON1;VEGETW1;TMATOW1)
        ("XC2000", "VEGETN1"),  # expanded from XC2000.(MAIZEN1;FBEAN1;SBSEMW1;VEGETN1;SORGMN1;PTATON1;TMATON1;VEGETW1;TMATOW1)
        ("XC2000", "SORGMN1"),  # expanded from XC2000.(MAIZEN1;FBEAN1;SBSEMW1;VEGETN1;SORGMN1;PTATON1;TMATON1;VEGETW1;TMATOW1)
        ("XC2000", "PTATON1"),  # expanded from XC2000.(MAIZEN1;FBEAN1;SBSEMW1;VEGETN1;SORGMN1;PTATON1;TMATON1;VEGETW1;TMATOW1)
        ("XC2000", "TMATON1"),  # expanded from XC2000.(MAIZEN1;FBEAN1;SBSEMW1;VEGETN1;SORGMN1;PTATON1;TMATON1;VEGETW1;TMATOW1)
        ("XC2000", "VEGETW1"),  # expanded from XC2000.(MAIZEN1;FBEAN1;SBSEMW1;VEGETN1;SORGMN1;PTATON1;TMATON1;VEGETW1;TMATOW1)
        ("XC2000", "TMATOW1"),  # expanded from XC2000.(MAIZEN1;FBEAN1;SBSEMW1;VEGETN1;SORGMN1;PTATON1;TMATON1;VEGETW1;TMATOW1)
        ("XC3500", "SESAME1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "BARLEY1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "FLAX1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "SORGMS1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "LENTIL1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "SBEAN1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "MAIZES1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "SBEET1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "WHEAT1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "OLGUME1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "VEGETS1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "LBSEEM1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "PTATOS1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "PTATOW1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "GNUT1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "ONIONS1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "TMATOS1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC3500", "ONIONW1"),  # expanded from XC3500.(SESAME1;BARLEY1;FLAX1;SORGMS1;LENTIL1;SBEAN1;MAIZES1;SBEET1;WHEAT1;OLGUME1;VEGETS1;LBSEEM1;PTATOS1;PTATOW1;GNUT1;ONIONS1;TMATOS1;ONIONW1)
        ("XC5000", "SDELS1"),  # expanded from XC5000.(SDELS1;SDLS1;CITRUS1)
        ("XC5000", "SDLS1"),  # expanded from XC5000.(SDELS1;SDLS1;CITRUS1)
        ("XC5000", "CITRUS1"),  # expanded from XC5000.(SDELS1;SDLS1;CITRUS1)
        ("XC5001", "PADDY1"),  # expanded from XC5001.(PADDY1;SCANE1)
        ("XC5001", "SCANE1"),  # expanded from XC5001.(PADDY1;SCANE1)
    ],
    # crops producing final and intermediate commodities
    "XCPP": [  # spans set (XC)
        ("GNUT1"),
        ("SESAME1"),
        ("SBEAN1"),
    ],
    # sesame
    "SES": [  # spans set (XC)
        ("SESAME1"),
    ],
    # groundnut
    "GNU": [  # spans set (XC)
        ("GNUT1"),
    ],
    # soybean
    "SOY": [  # spans set (XC)
        ("SBEAN1"),
    ],
    # cotton crops
    "XCCOT": [  # spans set (XC)
        ("SDLS1"),
        ("SDELS1"),
    ],
    # citrus crops
    "XCCIT": [  # spans set (XC)
        ("CITRUS1"),
    ],
    # potato crops
    "XCPOT": [  # spans set (XC)
        ("PTATON1"),
        ("PTATOS1"),
        ("PTATOW1"),
    ],
    # rice crops
    "XCRICE": [  # spans set (XC)
        ("PADDY1"),
    ],
    # sugar cane crops
    "XCSCA": [  # spans set (XC)
        ("SCANE1"),
    ],
    # sugar beet crops
    "XCSBE": [  # spans set (XC)
        ("SBEET1"),
    ],
    # winter vegetable
    "XCVEGW": [  # spans set (XC)
        ("VEGETW1"),
    ],
    # nili vegetable
    "XCVEGN": [  # spans set (XC)
        ("VEGETN1"),
    ],
    # summer vegetable
    "XCVEGS": [  # spans set (XC)
        ("VEGETS1"),
    ],
    # grain wheat
    "XCGRAIN": [  # spans set (XC)
        ("BARLEY1"),
        ("WHEAT1"),
    ],
    # oilseeds soybean
    "XCOILS": [  # spans set (XC)
        ("SBEAN1"),
        ("GNUT1"),
        ("SESAME1"),
    ],
    #
    "XCOTLEG": [  # spans set (XC)
        ("OLGUME1"),
    ],
    #
    "XCFOD": [  # spans set (XC)
        ("LBSEEM1"),
        ("SBSEMW1"),
    ],
    #
    "XCSORG": [  # spans set (XC)
        ("SORGMN1"),
        ("SORGMS1"),
        ("MAIZEN1"),
        ("MAIZES1"),
    ],
    # winter crops
    "WXC": [  # spans set (XC)
        ("LBSEEM1"),
        ("SBSEMW1"),
        ("WHEAT1"),
        ("BARLEY1"),
        ("FBEAN1"),
        ("LENTIL1"),
        ("OLGUME1"),
        ("FLAX1"),
        ("ONIONW1"),
        ("TMATOW1"),
        ("VEGETW1"),
        ("SBEET1"),
        ("PTATOW1"),
    ],
    # nili crops
    "NXC": [  # spans set (XC)
        ("PTATON1"),
        ("TMATON1"),
        ("VEGETN1"),
        ("SORGMN1"),
        ("MAIZEN1"),
    ],
    # summer crops
    "SXC": [  # spans set (XC)
        ("SDLS1"),
        ("SDELS1"),
        ("PADDY1"),
        ("SESAME1"),
        ("GNUT1"),
        ("SBEAN1"),
        ("ONIONS1"),
        ("PTATOS1"),
        ("TMATOS1"),
        ("VEGETS1"),
        ("SORGMS1"),
        ("MAIZES1"),
    ],
    # perennial crops
    "PXC": [  # spans set (XC)
        ("CITRUS1"),
        ("SCANE1"),
    ],
    # vegetable and perennial crops
    "VP": [  # spans set (XC)
        ("ONIONW1"),
        ("TMATOW1"),
        ("VEGETW1"),
        ("ONIONS1"),
        ("PTATOS1"),
        ("TMATOS1"),
        ("VEGETS1"),
        ("PTATON1"),
        ("TMATON1"),
        ("VEGETN1"),
        ("CITRUS1"),
        ("SCANE1"),
    ],
    # annual crops
    "AXC": [  # spans set (XC)
        ("SDLS1"),
        ("SDELS1"),
        ("PADDY1"),
        ("SESAME1"),
        ("GNUT1"),
        ("SBEAN1"),
        ("ONIONS1"),
        ("PTATOS1"),
        ("TMATOS1"),
        ("VEGETS1"),
        ("SORGMS1"),
        ("MAIZES1"),
        ("PTATON1"),
        ("TMATON1"),
        ("VEGETN1"),
        ("SORGMN1"),
        ("MAIZEN1"),
        ("LBSEEM1"),
        ("SBSEMW1"),
        ("WHEAT1"),
        ("BARLEY1"),
        ("FBEAN1"),
        ("LENTIL1"),
        ("OLGUME1"),
        ("FLAX1"),
        ("ONIONW1"),
        ("TMATOW1"),
        ("VEGETW1"),
        ("SBEET1"),
        ("PTATOW1"),
    ],
    # annual non rice crops
    "ANRXC": [  # spans set (XC)
        ("SDLS1"),
        ("SDELS1"),
        ("SESAME1"),
        ("GNUT1"),
        ("SBEAN1"),
        ("ONIONS1"),
        ("PTATOS1"),
        ("TMATOS1"),
        ("VEGETS1"),
        ("SORGMS1"),
        ("MAIZES1"),
        ("PTATON1"),
        ("TMATON1"),
        ("VEGETN1"),
        ("SORGMN1"),
        ("MAIZEN1"),
        ("LBSEEM1"),
        ("SBSEMW1"),
        ("WHEAT1"),
        ("BARLEY1"),
        ("FBEAN1"),
        ("LENTIL1"),
        ("OLGUME1"),
        ("FLAX1"),
        ("ONIONW1"),
        ("TMATOW1"),
        ("VEGETW1"),
        ("SBEET1"),
        ("PTATOW1"),
    ],
    # mapping of crops and all crop commodities
    "XCCMAP": [  # spans set (XC, C)
        ("BARLEY1", "BARLEY"),  # expanded from BARLEY1.(BARLEY;BARLEYSTR)
        ("BARLEY1", "BARLEYSTR"),  # expanded from BARLEY1.(BARLEY;BARLEYSTR)
        ("CITRUS1", "CITRUS"),  # expanded from CITRUS1.CITRUS
        ("FBEAN1", "FBEAN"),  # expanded from FBEAN1.(FBEAN;FBEANFOD)
        ("FBEAN1", "FBEANFOD"),  # expanded from FBEAN1.(FBEAN;FBEANFOD)
        ("FLAX1", "FLAX"),  # expanded from FLAX1.(FLAX;FXFIB;FLSECAKE;VEG-OIL)
        ("FLAX1", "FXFIB"),  # expanded from FLAX1.(FLAX;FXFIB;FLSECAKE;VEG-OIL)
        ("FLAX1", "FLSECAKE"),  # expanded from FLAX1.(FLAX;FXFIB;FLSECAKE;VEG-OIL)
        ("FLAX1", "VEG-OIL"),  # expanded from FLAX1.(FLAX;FXFIB;FLSECAKE;VEG-OIL)
        ("GNUT1", "GRDNUT"),  # expanded from GNUT1.(GRDNUT;GRDNUTFOD;GNUTCAKE;VEG-OIL;GNUTSH)
        ("GNUT1", "GRDNUTFOD"),  # expanded from GNUT1.(GRDNUT;GRDNUTFOD;GNUTCAKE;VEG-OIL;GNUTSH)
        ("GNUT1", "GNUTCAKE"),  # expanded from GNUT1.(GRDNUT;GRDNUTFOD;GNUTCAKE;VEG-OIL;GNUTSH)
        ("GNUT1", "VEG-OIL"),  # expanded from GNUT1.(GRDNUT;GRDNUTFOD;GNUTCAKE;VEG-OIL;GNUTSH)
        ("GNUT1", "GNUTSH"),  # expanded from GNUT1.(GRDNUT;GRDNUTFOD;GNUTCAKE;VEG-OIL;GNUTSH)
        ("LBSEEM1", "BERSEEM"),  # expanded from (LBSEEM1;SBSEMW1).BERSEEM
        ("SBSEMW1", "BERSEEM"),  # expanded from (LBSEEM1;SBSEMW1).BERSEEM
        ("LENTIL1", "LENTIL"),  # expanded from LENTIL1.(LENTIL;LENTILFOD)
        ("LENTIL1", "LENTILFOD"),  # expanded from LENTIL1.(LENTIL;LENTILFOD)
        ("MAIZEN1", "MAIZE"),  # expanded from (MAIZEN1;MAIZES1).(MAIZE;MAIZESTA)
        ("MAIZEN1", "MAIZESTA"),  # expanded from (MAIZEN1;MAIZES1).(MAIZE;MAIZESTA)
        ("MAIZES1", "MAIZE"),  # expanded from (MAIZEN1;MAIZES1).(MAIZE;MAIZESTA)
        ("MAIZES1", "MAIZESTA"),  # expanded from (MAIZEN1;MAIZES1).(MAIZE;MAIZESTA)
        ("OLGUME1", "LEGUME"),  # expanded from OLGUME1.LEGUME
        ("ONIONS1", "ONION"),  # expanded from (ONIONS1;ONIONW1).ONION
        ("ONIONW1", "ONION"),  # expanded from (ONIONS1;ONIONW1).ONION
        ("PADDY1", "PADDY"),  # expanded from PADDY1.(PADDY;RICE;RICESTR;BRAN;HUSK)
        ("PADDY1", "RICE"),  # expanded from PADDY1.(PADDY;RICE;RICESTR;BRAN;HUSK)
        ("PADDY1", "RICESTR"),  # expanded from PADDY1.(PADDY;RICE;RICESTR;BRAN;HUSK)
        ("PADDY1", "BRAN"),  # expanded from PADDY1.(PADDY;RICE;RICESTR;BRAN;HUSK)
        ("PADDY1", "HUSK"),  # expanded from PADDY1.(PADDY;RICE;RICESTR;BRAN;HUSK)
        ("PTATON1", "POTATO"),  # expanded from (PTATON1;PTATOS1;PTATOW1).POTATO
        ("PTATOS1", "POTATO"),  # expanded from (PTATON1;PTATOS1;PTATOW1).POTATO
        ("PTATOW1", "POTATO"),  # expanded from (PTATON1;PTATOS1;PTATOW1).POTATO
        ("SBEAN1", "SOYBEAN"),  # expanded from SBEAN1.(SOYBEAN;SOYAFOD;SOYACAKE;VEG-OIL)
        ("SBEAN1", "SOYAFOD"),  # expanded from SBEAN1.(SOYBEAN;SOYAFOD;SOYACAKE;VEG-OIL)
        ("SBEAN1", "SOYACAKE"),  # expanded from SBEAN1.(SOYBEAN;SOYAFOD;SOYACAKE;VEG-OIL)
        ("SBEAN1", "VEG-OIL"),  # expanded from SBEAN1.(SOYBEAN;SOYAFOD;SOYACAKE;VEG-OIL)
        ("SBEET1", "SGBEET"),  # expanded from SBEET1.(SGBEET;SUGAR;SBEETFOD;SBEETMOL;SBEETPULP)
        ("SBEET1", "SUGAR"),  # expanded from SBEET1.(SGBEET;SUGAR;SBEETFOD;SBEETMOL;SBEETPULP)
        ("SBEET1", "SBEETFOD"),  # expanded from SBEET1.(SGBEET;SUGAR;SBEETFOD;SBEETMOL;SBEETPULP)
        ("SBEET1", "SBEETMOL"),  # expanded from SBEET1.(SGBEET;SUGAR;SBEETFOD;SBEETMOL;SBEETPULP)
        ("SBEET1", "SBEETPULP"),  # expanded from SBEET1.(SGBEET;SUGAR;SBEETFOD;SBEETMOL;SBEETPULP)
        ("SCANE1", "SGCANE"),  # expanded from SCANE1.(SGCANE;SUGAR;SCANEFOD;SCANEMOL)
        ("SCANE1", "SUGAR"),  # expanded from SCANE1.(SGCANE;SUGAR;SCANEFOD;SCANEMOL)
        ("SCANE1", "SCANEFOD"),  # expanded from SCANE1.(SGCANE;SUGAR;SCANEFOD;SCANEMOL)
        ("SCANE1", "SCANEMOL"),  # expanded from SCANE1.(SGCANE;SUGAR;SCANEFOD;SCANEMOL)
        ("SDELS1", "SEEDELS"),  # expanded from SDELS1.(SEEDELS;CTONELS;COTSCAKE;VEG-OIL;COTSTA)
        ("SDELS1", "CTONELS"),  # expanded from SDELS1.(SEEDELS;CTONELS;COTSCAKE;VEG-OIL;COTSTA)
        ("SDELS1", "COTSCAKE"),  # expanded from SDELS1.(SEEDELS;CTONELS;COTSCAKE;VEG-OIL;COTSTA)
        ("SDELS1", "VEG-OIL"),  # expanded from SDELS1.(SEEDELS;CTONELS;COTSCAKE;VEG-OIL;COTSTA)
        ("SDELS1", "COTSTA"),  # expanded from SDELS1.(SEEDELS;CTONELS;COTSCAKE;VEG-OIL;COTSTA)
        ("SDLS1", "SEEDLS"),  # expanded from SDLS1.(SEEDLS;CTONLS;COTSCAKE;VEG-OIL;COTSTA)
        ("SDLS1", "CTONLS"),  # expanded from SDLS1.(SEEDLS;CTONLS;COTSCAKE;VEG-OIL;COTSTA)
        ("SDLS1", "COTSCAKE"),  # expanded from SDLS1.(SEEDLS;CTONLS;COTSCAKE;VEG-OIL;COTSTA)
        ("SDLS1", "VEG-OIL"),  # expanded from SDLS1.(SEEDLS;CTONLS;COTSCAKE;VEG-OIL;COTSTA)
        ("SDLS1", "COTSTA"),  # expanded from SDLS1.(SEEDLS;CTONLS;COTSCAKE;VEG-OIL;COTSTA)
        ("SESAME1", "SESAME"),  # expanded from SESAME1.(SESAME;FLSECAKE;VEG-OIL)
        ("SESAME1", "FLSECAKE"),  # expanded from SESAME1.(SESAME;FLSECAKE;VEG-OIL)
        ("SESAME1", "VEG-OIL"),  # expanded from SESAME1.(SESAME;FLSECAKE;VEG-OIL)
        ("SORGMN1", "SORGHUM"),  # expanded from (SORGMN1;SORGMS1).SORGHUM
        ("SORGMS1", "SORGHUM"),  # expanded from (SORGMN1;SORGMS1).SORGHUM
        ("TMATON1", "TOMATO"),  # expanded from (TMATON1;TMATOS1;TMATOW1).TOMATO
        ("TMATOS1", "TOMATO"),  # expanded from (TMATON1;TMATOS1;TMATOW1).TOMATO
        ("TMATOW1", "TOMATO"),  # expanded from (TMATON1;TMATOS1;TMATOW1).TOMATO
        ("VEGETN1", "VEGET"),  # expanded from (VEGETN1;VEGETS1;VEGETW1).(VEGET;VEGETFOD)
        ("VEGETN1", "VEGETFOD"),  # expanded from (VEGETN1;VEGETS1;VEGETW1).(VEGET;VEGETFOD)
        ("VEGETS1", "VEGET"),  # expanded from (VEGETN1;VEGETS1;VEGETW1).(VEGET;VEGETFOD)
        ("VEGETS1", "VEGETFOD"),  # expanded from (VEGETN1;VEGETS1;VEGETW1).(VEGET;VEGETFOD)
        ("VEGETW1", "VEGET"),  # expanded from (VEGETN1;VEGETS1;VEGETW1).(VEGET;VEGETFOD)
        ("VEGETW1", "VEGETFOD"),  # expanded from (VEGETN1;VEGETS1;VEGETW1).(VEGET;VEGETFOD)
        ("WHEAT1", "WHEAT"),  # expanded from WHEAT1.(WHEAT;WHEATF;WHEATSTR;BRAN)
        ("WHEAT1", "WHEATF"),  # expanded from WHEAT1.(WHEAT;WHEATF;WHEATSTR;BRAN)
        ("WHEAT1", "WHEATSTR"),  # expanded from WHEAT1.(WHEAT;WHEATF;WHEATSTR;BRAN)
        ("WHEAT1", "BRAN"),  # expanded from WHEAT1.(WHEAT;WHEATF;WHEATSTR;BRAN)
    ],
    # mapping of crops and primary crop commodities
    "XCPCMAP": [  # spans set (XC, C)
        ("BARLEY1", "BARLEY"),  # expanded from BARLEY1.BARLEY
        ("CITRUS1", "CITRUS"),  # expanded from CITRUS1.CITRUS
        ("FBEAN1", "FBEAN"),  # expanded from FBEAN1.FBEAN
        ("FLAX1", "FLAX"),  # expanded from FLAX1.FLAX
        ("GNUT1", "GRDNUT"),  # expanded from GNUT1.GRDNUT
        ("LBSEEM1", "BERSEEM"),  # expanded from (LBSEEM1;SBSEMW1).BERSEEM
        ("SBSEMW1", "BERSEEM"),  # expanded from (LBSEEM1;SBSEMW1).BERSEEM
        ("LENTIL1", "LENTIL"),  # expanded from LENTIL1.LENTIL
        ("MAIZEN1", "MAIZE"),  # expanded from (MAIZEN1;MAIZES1).MAIZE
        ("MAIZES1", "MAIZE"),  # expanded from (MAIZEN1;MAIZES1).MAIZE
        ("OLGUME1", "LEGUME"),  # expanded from OLGUME1.LEGUME
        ("ONIONS1", "ONION"),  # expanded from (ONIONS1;ONIONW1).ONION
        ("ONIONW1", "ONION"),  # expanded from (ONIONS1;ONIONW1).ONION
        ("PADDY1", "PADDY"),  # expanded from PADDY1.PADDY
        ("PTATON1", "POTATO"),  # expanded from (PTATON1;PTATOS1;PTATOW1).POTATO
        ("PTATOS1", "POTATO"),  # expanded from (PTATON1;PTATOS1;PTATOW1).POTATO
        ("PTATOW1", "POTATO"),  # expanded from (PTATON1;PTATOS1;PTATOW1).POTATO
        ("SBEAN1", "SOYBEAN"),  # expanded from SBEAN1.SOYBEAN
        ("SBEET1", "SGBEET"),  # expanded from SBEET1.SGBEET
        ("SCANE1", "SGCANE"),  # expanded from SCANE1.SGCANE
        ("SDELS1", "SEEDELS"),  # expanded from SDELS1.SEEDELS
        ("SDLS1", "SEEDLS"),  # expanded from SDLS1.SEEDLS
        ("SESAME1", "SESAME"),  # expanded from SESAME1.SESAME
        ("SORGMN1", "SORGHUM"),  # expanded from (SORGMN1;SORGMS1).SORGHUM
        ("SORGMS1", "SORGHUM"),  # expanded from (SORGMN1;SORGMS1).SORGHUM
        ("TMATON1", "TOMATO"),  # expanded from (TMATON1;TMATOS1;TMATOW1).TOMATO
        ("TMATOS1", "TOMATO"),  # expanded from (TMATON1;TMATOS1;TMATOW1).TOMATO
        ("TMATOW1", "TOMATO"),  # expanded from (TMATON1;TMATOS1;TMATOW1).TOMATO
        ("VEGETN1", "VEGET"),  # expanded from (VEGETN1;VEGETS1;VEGETW1).VEGET
        ("VEGETS1", "VEGET"),  # expanded from (VEGETN1;VEGETS1;VEGETW1).VEGET
        ("VEGETW1", "VEGET"),  # expanded from (VEGETN1;VEGETS1;VEGETW1).VEGET
        ("WHEAT1", "WHEAT"),  # expanded from WHEAT1.WHEAT
    ],
    # planting date as technology
    "PT": [
        ("E"),  # one month early
        ("O"),  # normal planting date
        ("L"),  # one month late
    ],
    # water application as technology
    "WI": [
        ("HI"),  # optimum equal to ET
        ("RED05"),  # 5% Water Deficit
        ("RED10"),  # 10% Water Deficit
        ("RED15"),  # 15% Water Deficit
        ("RED20"),  # 20% Water Deficit
        ("RED25"),  # 25% Water Deficit
        ("RED30"),  # 25% Water Deficit
    ],
    # rgions  Governorates
    "R": [
        ("ALEX"),  # Alexandria_WD
        ("BEHAIRA"),  # Beheira_WD
        ("GHARBIA"),  # Gharbia_MD
        ("KFRSHIK"),  # Kafr-el-Sheihk_MD
        ("DAKHLIA"),  # Dakhlia_MD
        ("DAMIETA"),  # Damietta_MD
        ("SHARKIA"),  # Sharkia_ED
        ("ISMALIA"),  # Ismalia_ED
        ("PRTSAID"),  # Port Said_ED
        ("SUEZ"),  # Suez_ED
        ("MENUFIA"),  # Menoufia_MD
        ("QLYUBIA"),  # Qalyoubia_ED
        ("CAIRO"),  # Cairo_ME
        ("GIZA"),  # Giza_ME
        ("BNISUEF"),  # Beni-Suef_ME
        ("FAYOUM"),  # Fayoum_ME
        ("MENIA"),  # Menia_ME
        ("ASSUIT"),  # Assyout_UE
        ("SUHAG"),  # Suhag_UE
        ("QENA"),  # Qena_UE
        ("LUXOR"),  # Luxor_UE
        ("ASWAN"),  # Aswan_UE
        ("NVALLEY"),  # New-Valley_G
        ("MATRUH"),  # Matrough_G
        ("REDSEA"),  # Red-Sea_G
        ("NSINAI"),  # North-Sinai_ED
        ("SSINAI"),  # South_Sinai_G
        ("NUBARIA"),  # Noubaira_WD
        ("TOSHKA"),  # Toshka_UE
        ("SEA"),  # Sea_or_other
    ],
    # old land regions
    "OL": [  # spans set (R)
        ("ALEX"),  # Alexandria_WD
        ("BEHAIRA"),  # Beheira_WD
        ("GHARBIA"),  # Gharbia_WD
        ("KFRSHIK"),  # Kafr-el-Sheihk_MD
        ("DAKHLIA"),  # Dakhlia_ED
        ("DAMIETA"),  # Damietta_MD
        ("SHARKIA"),  # Sharkia_ED
        ("ISMALIA"),  # Ismalia_ED
        ("PRTSAID"),  # Port Said_ED
        ("SUEZ"),  # Suez_ED
        ("MENUFIA"),  # Menoufia_MD
        ("QLYUBIA"),  # Qalyoubia_ED
        ("CAIRO"),  # Cairo_ME
        ("GIZA"),  # Giza_ME
        ("BNISUEF"),  # Beni-Suef_ME
        ("FAYOUM"),  # Fayoum_ME
        ("MENIA"),  # Menia_ME
        ("ASSUIT"),  # Assyout_UE
        ("SUHAG"),  # Suhag_UP
        ("QENA"),  # Qena_UE
        ("LUXOR"),  # Luxor_UE
        ("ASWAN"),  # Aswan_UE
    ],
    # old land regions except Cairo
    "OLC": [  # spans set (R)
        ("ALEX"),  # Alexandria_WD
        ("BEHAIRA"),  # Beheira_WD
        ("GHARBIA"),  # Gharbia_WD
        ("KFRSHIK"),  # Kafr-el-Sheihk_MD
        ("DAKHLIA"),  # Dakhlia_MD
        ("DAMIETA"),  # Damietta_MD
        ("SHARKIA"),  # Sharkia_ED
        ("ISMALIA"),  # Ismalia_ED
        ("PRTSAID"),  # Port Said_ED
        ("SUEZ"),  # Suez_ED
        ("MENUFIA"),  # Menoufia_MD
        ("QLYUBIA"),  # Qalyoubia_ED
        ("GIZA"),  # Giza_ME
        ("BNISUEF"),  # Beni-Suef_ME
        ("FAYOUM"),  # Fayoum_ME
        ("MENIA"),  # Menia_ME
        ("ASSUIT"),  # Assyout_UE
        ("SUHAG"),  # Suhag_UP
        ("QENA"),  # Qena_UE
        ("LUXOR"),  # Luxor_UE
        ("ASWAN"),  # Aswan_UE
    ],
    # old new lands
    "ONL": [  # spans set (R)
        ("NUBARIA"),  # Nubaria_WD
    ],
    # old land and old new land regions
    "OLN": [  # spans set (R)
        ("ALEX"),  # Alexandria_WD
        ("BEHAIRA"),  # Beheira_WD
        ("GHARBIA"),  # Gharbia_MD
        ("KFRSHIK"),  # Kafr-el-Sheihk_MD
        ("DAKHLIA"),  # Dakhlia_MD
        ("DAMIETA"),  # Damietta_MD
        ("SHARKIA"),  # Sharkia_ED
        ("ISMALIA"),  # Ismalia_ED
        ("PRTSAID"),  # Port Said_ED
        ("SUEZ"),  # Suez_ED
        ("MENUFIA"),  # Menoufia_MD
        ("QLYUBIA"),  # Qalyoubia_ED
        ("CAIRO"),  # Cairo_ME
        ("GIZA"),  # Giza_ME
        ("BNISUEF"),  # Beni-Suef_ME
        ("FAYOUM"),  # Fayoum_ME
        ("MENIA"),  # Menia_ME
        ("ASSUIT"),  # Assyout_UE
        ("SUHAG"),  # Suhag_UP
        ("QENA"),  # Qena_UE
        ("LUXOR"),  # Luxor_UE
        ("ASWAN"),  # Aswan_UE
    ],
    # new land regions
    "NL": [  # spans set (R)
    ],
    #
    "": [
    ],
    # all delta regions
    "ADR": [  # spans set (R)
        ("ALEX"),  # Alexandria_WD
        ("BEHAIRA"),  # Beheira_WD
        ("NUBARIA"),  # Noubaira_WD
        ("GHARBIA"),  # Gharbia_MD
        ("KFRSHIK"),  # Kafr-el-Sheihk_MD
        ("DAKHLIA"),  # Dakhlia_MD
        ("DAMIETA"),  # Damietta_MD
        ("MENUFIA"),  # Menoufia_MD
        ("QLYUBIA"),  # Qalyoubia_ED
        ("SHARKIA"),  # Sharkia_ED
        ("ISMALIA"),  # Ismalia_ED
        ("PRTSAID"),  # Port Said_ED
        ("SUEZ"),  # Suez_ED
        ("NSINAI"),  # North-Sinai_ED
    ],
    # west delta regions
    "WDR": [  # spans set (R)
        ("ALEX"),  # Alexandria_WD
        ("BEHAIRA"),  # Beheira_WD
        ("NUBARIA"),  # Noubaira_WD
    ],
    # middle delta regions
    "MDR": [  # spans set (R)
        ("GHARBIA"),  # Gharbia_MD
        ("KFRSHIK"),  # Kafr-el-Sheihk_MD
        ("DAMIETA"),  # Damietta_MD
        ("MENUFIA"),  # Menoufia_MD
    ],
    # east delta regions
    "EDR": [  # spans set (R)
        ("QLYUBIA"),  # Qalyoubia_ED
        ("SHARKIA"),  # Sharkia_ED
        ("DAKHLIA"),  # Dakhlia_ED
        ("ISMALIA"),  # Ismalia_ED
        ("PRTSAID"),  # Port Said_ED
        ("SUEZ"),  # Suez_ED
        ("NSINAI"),  # North-Sinai_ED
    ],
    # upper egypt regions
    "UER": [  # spans set (R)
        ("ASSUIT"),  # Assyout_UE
        ("SUHAG"),  # Suhag_UE
        ("QENA"),  # Qena_UE
        ("LUXOR"),  # Luxor_UE
        ("ASWAN"),  # Aswan_UE
        ("TOSHKA"),  # Toshka_UE
    ],
    # middle egypt regions
    "MER": [  # spans set (R)
        ("CAIRO"),  # Cairo_ME
        ("GIZA"),  # Giza_ME
        ("BNISUEF"),  # Beni-Suef_ME
        ("FAYOUM"),  # Fayoum_ME
        ("MENIA"),  # Menia_ME
    ],
    # valley regions
    "VAR": [  # spans set (R)
        ("ASSUIT"),  # Assyout_UE
        ("SUHAG"),  # Suhag_UE
        ("QENA"),  # Qena_UE
        ("LUXOR"),  # Luxor_UE
        ("ASWAN"),  # Aswan_UE
        ("TOSHKA"),  # Toshka_UE
        ("CAIRO"),  # Cairo_ME
        ("GIZA"),  # Giza_ME
        ("BNISUEF"),  # Beni-Suef_ME
        ("FAYOUM"),  # Fayoum_ME
        ("MENIA"),  # Menia_ME
    ],
    # rgions with surface water as irrigation source
    "RSW": [  # spans set (R)
        ("ALEX"),  # Alexandria_WD
        ("BEHAIRA"),  # Beheira_WD
        ("GHARBIA"),  # Gharbia_MD
        ("KFRSHIK"),  # Kafr-el-Sheihk_MD
        ("DAKHLIA"),  # Dakhlia_MD
        ("DAMIETA"),  # Damietta_MD
        ("SHARKIA"),  # Sharkia_ED
        ("ISMALIA"),  # Ismalia_ED
        ("PRTSAID"),  # Port Said_ED
        ("SUEZ"),  # Suez_ED
        ("MENUFIA"),  # Menoufia_MD
        ("QLYUBIA"),  # Qalyoubia_ED
        ("CAIRO"),  # Cairo_ME
        ("GIZA"),  # Giza_ME
        ("BNISUEF"),  # Beni-Suef_ME
        ("FAYOUM"),  # Fayoum_ME
        ("MENIA"),  # Menia_ME
        ("ASSUIT"),  # Assyout_UE
        ("SUHAG"),  # Suhag_UP
        ("QENA"),  # Qena_UE
        ("LUXOR"),  # Luxor_UE
        ("ASWAN"),  # Aswan_UE
        ("NSINAI"),  # North-Sinai_ED
        ("NUBARIA"),  # Noubaira_WD
        ("TOSHKA"),  # Toshka_UE
    ],
    # rgion using deep ground water
    "DGW": [  # spans set (R)
        ("NVALLEY"),  # New-Valley_G
        ("MATRUH"),  # Matrough_G
        ("REDSEA"),  # Red-Sea_G
        ("SSINAI"),  # South_Sinai_G
    ],
    # land regions
    "RL": [  # spans set (R)
        ("ALEX"),  # Alexandria_WD
        ("BEHAIRA"),  # Beheira_WD
        ("GHARBIA"),  # Gharbia_MD
        ("KFRSHIK"),  # Kafr-el-Sheihk_MD
        ("DAKHLIA"),  # Dakhlia_MD
        ("DAMIETA"),  # Damietta_MD
        ("SHARKIA"),  # Sharkia_ED
        ("ISMALIA"),  # Ismalia_ED
        ("PRTSAID"),  # Port Said_ED
        ("SUEZ"),  # Suez_ED
        ("MENUFIA"),  # Menoufia_MD
        ("QLYUBIA"),  # Qalyoubia_ED
        ("CAIRO"),  # Cairo_ME
        ("GIZA"),  # Giza_ME
        ("BNISUEF"),  # Beni-Suef_ME
        ("FAYOUM"),  # Fayoum_ME
        ("MENIA"),  # Menia_ME
        ("ASSUIT"),  # Assyout_UE
        ("SUHAG"),  # Suhag_UP
        ("QENA"),  # Qena_UE
        ("LUXOR"),  # Luxor_UE
        ("ASWAN"),  # Aswan_UE
        ("NVALLEY"),  # New-Valley_G
        ("MATRUH"),  # Matrough_G
        ("REDSEA"),  # Red-Sea_G
        ("NSINAI"),  # North-Sinai_ED
        ("SSINAI"),  # South_Sinai_G
        ("NUBARIA"),  # Noubaira_WD
        ("TOSHKA"),  # Toshka_UE
    ],
    # sea also used as other
    "SEA": [
        ("SEA"),
    ],
    # rgions taking water from lake nasser
    "UENV": [  # spans set (R)
        ("ASWAN"),
        ("TOSHKA"),
    ],
    # livestock activities (production units)
    "XA": [
        ("BROI"),  # poultry broiler meat production
        ("CCDP"),  # commercial cattle dairy production
        ("FFAT"),  # fattening of yearlings on forage & conc. for meat
        ("LAYE"),  # poultry layer egg production
        ("REAR"),  # yearling rearing for meat or fattening
        ("SBDP"),  # semi intensive buffalo dairy production
        ("SCDP"),  # semi intensive cattle dairy production
        ("SFAT"),  # fattening of yearlings on straw & conc. for meat
        ("SHGO"),  # sheep and goat meat production in nile valley
        ("TBCD"),  # traditional buffalo and cattle breeding
        ("WEAN"),  # weaner rearing 60-180 kg for meat or rearing
    ],
    # method of feeding
    "M": [
        ("C"),  # with conventional feeds
        ("N"),  # with new feeds
    ],
    # feed types
    "FEEDS": [
        ("BALNG"),  # baladi ration when no green feed is available
        ("BALSR"),  # baladi summer ration
        ("BALWR"),  # baladi winter ration
        ("BFENF"),  # basal feed mix non forage season
        ("BFOMS"),  # basal forage mix for summer
        ("BFOMW"),  # basal forage mix for winter
        ("DACOF"),  # dairy concentrate feed
        ("ENMIX"),  # energy mix
        ("IMSTR"),  # improved straw
        ("INTFE"),  # integrated feed
        ("PLSTR"),  # plain straw
        ("POBRF"),  # poultry broiler feed
        ("POGRF"),  # poultry grower feed
        ("POLAF"),  # poultry layer feed
        ("PRCON"),  # protein concentrate mix
    ],
    # poultry feeds
    "POFEEDS": [  # spans set (FEEDS)
        ("POBRF"),
        ("POGRF"),
        ("POLAF"),
    ],
    # livestock labour inputs
    "LSLAB": [
        ("FRMMAN"),  # farm manager
        ("LSLABU"),  # semi skilled livestock labourer
    ],
    # livestock other inputs and outputs
    "LSOINP": [
        ("BRESER"),  # breeding service
        ("DONKEY"),  # draft services by donkey and manure
        ("FETRMI"),  # feed transport and mixing
        ("LSHOUS"),  # livestock housing and feed storage incl depreciation and maint
        ("MARKET"),  # marketing costs incl packaging for eggs
        ("MILKUT"),  # milk and egg handling utensils detergents water and energy
        ("UBRINE"),  # ubrine evacuation
        ("VETSER"),  # veterinary service
    ],
    # feed indicators and treatment costs
    "FEEDIND": [
        ("DM"),  # dry matter content (fraction)
        ("NETUSE"),  # total less losses (fraction)
        ("TDN-DM"),  # total digestible nutrients in dry matter (fraction)
        ("CP-DM"),  # crude protein in dry matter (fraction)
        ("ME-DM"),  # metabolic energy in dry matter (fraction)(for poultry only)
        ("TRCST"),  # cost of treatment (LE p t dry matter)
        ("MAXUSE"),  # max use of C.FCTYPE because of conservation constraints (fraction)
    ],
    # crop commodities and by-products used in feed ingredients
    "CF": [  # spans set (C)
        ("BARLEYSTR"),  # dry barley straw
        ("BERSEEM"),  # berseem
        ("BRAN"),  # rice and wheat bran incl rice and wheat midlings
        ("COTSCAKE"),  # cotton seed cake decorticated
        ("FBEAN"),  # dry fava beans
        ("FBEANFOD"),  # fava bean residues
        ("FLSECAKE"),  # flax sesame cake
        ("GNUTCAKE"),  # groundnut cake
        ("GRDNUTFOD"),  # groundnut haulms
        ("LENTILFOD"),  # lentil crop residues
        ("MAIZE"),  # maize grain
        ("MAIZESTA"),  # maize stalks without cobs
        ("RICESTR"),  # dry rice straw
        ("SBEETFOD"),  # fresh sugarbeet leaves
        ("SBEETMOL"),  # sugar beet molasses
        ("SBEETPULP"),  # dried sugar beet pulp
        ("SCANEFOD"),  # fresh sugarcane tops
        ("SCANEMOL"),  # sugar cane molasses
        ("SORGHUM"),  # sorghum grain
        ("SOYBEAN"),  # soybeans
        ("SOYACAKE"),  # soya cake
        ("SOYAFOD"),  # soya haulms
        ("VEGETFOD"),  # vegetable fodder
        ("WHEATSTR"),  # dry wheat straw
    ],
    # mapping of crops and feed commodities
    "FCMAP": [  # spans set (XC, C)
        ("LBSEEM1", "BERSEEM"),  # expanded from (LBSEEM1;SBSEMW1).BERSEEM
        ("SBSEMW1", "BERSEEM"),  # expanded from (LBSEEM1;SBSEMW1).BERSEEM
        ("MAIZEN1", "MAIZESTA"),  # expanded from (MAIZEN1;MAIZES1).MAIZESTA
        ("MAIZES1", "MAIZESTA"),  # expanded from (MAIZEN1;MAIZES1).MAIZESTA
        ("PADDY1", "RICESTR"),  # expanded from PADDY1.RICESTR
        ("PADDY1", "BRAN"),  # expanded from (PADDY1;WHEAT1).BRAN
        ("WHEAT1", "BRAN"),  # expanded from (PADDY1;WHEAT1).BRAN
        ("SORGMN1", "SORGHUM"),  # expanded from (SORGMN1;SORGMS1).SORGHUM
        ("SORGMS1", "SORGHUM"),  # expanded from (SORGMN1;SORGMS1).SORGHUM
        ("VEGETN1", "VEGETFOD"),  # expanded from (VEGETN1;VEGETS1;VEGETW1).VEGETFOD
        ("VEGETS1", "VEGETFOD"),  # expanded from (VEGETN1;VEGETS1;VEGETW1).VEGETFOD
        ("VEGETW1", "VEGETFOD"),  # expanded from (VEGETN1;VEGETS1;VEGETW1).VEGETFOD
        ("BARLEY1", "BARLEYSTR"),  # expanded from BARLEY1.BARLEYSTR
        ("SDLS1", "COTSCAKE"),  # expanded from (SDLS1;SDELS1).COTSCAKE
        ("SDELS1", "COTSCAKE"),  # expanded from (SDLS1;SDELS1).COTSCAKE
        ("FLAX1", "FLSECAKE"),  # expanded from (FLAX1;SESAME1).FLSECAKE
        ("SESAME1", "FLSECAKE"),  # expanded from (FLAX1;SESAME1).FLSECAKE
        ("FBEAN1", "FBEAN"),  # expanded from FBEAN1.(FBEAN;FBEANFOD)
        ("FBEAN1", "FBEANFOD"),  # expanded from FBEAN1.(FBEAN;FBEANFOD)
        ("MAIZEN1", "MAIZE"),  # expanded from (MAIZEN1;MAIZES1).MAIZE
        ("MAIZES1", "MAIZE"),  # expanded from (MAIZEN1;MAIZES1).MAIZE
        ("GNUT1", "GRDNUTFOD"),  # expanded from GNUT1.(GRDNUTFOD;GNUTCAKE)
        ("GNUT1", "GNUTCAKE"),  # expanded from GNUT1.(GRDNUTFOD;GNUTCAKE)
        ("LENTIL1", "LENTILFOD"),  # expanded from LENTIL1.LENTILFOD
        ("SBEET1", "SBEETFOD"),  # expanded from SBEET1.(SBEETFOD;SBEETMOL;SBEETPULP)
        ("SBEET1", "SBEETMOL"),  # expanded from SBEET1.(SBEETFOD;SBEETMOL;SBEETPULP)
        ("SBEET1", "SBEETPULP"),  # expanded from SBEET1.(SBEETFOD;SBEETMOL;SBEETPULP)
        ("SCANE1", "SCANEFOD"),  # expanded from SCANE1.(SCANEFOD;SCANEMOL)
        ("SCANE1", "SCANEMOL"),  # expanded from SCANE1.(SCANEFOD;SCANEMOL)
        ("SBEAN1", "SOYBEAN"),  # expanded from SBEAN1.(SOYBEAN;SOYAFOD;SOYACAKE)
        ("SBEAN1", "SOYAFOD"),  # expanded from SBEAN1.(SOYBEAN;SOYAFOD;SOYACAKE)
        ("SBEAN1", "SOYACAKE"),  # expanded from SBEAN1.(SOYBEAN;SOYAFOD;SOYACAKE)
        ("WHEAT1", "WHEATSTR"),  # expanded from WHEAT1.WHEATSTR
    ],
    # type of feed ingredients
    "FCTYPE": [
        ("F"),  # fresh fodder
        ("C"),  # conserved fodder
        ("S"),  # straw
        ("T"),  # treated straw
        ("G"),  # grain bran cake pulp molasses for concentrate
    ],
    # possible combinations of C and FCTYPE
    "CFCTMAP": [  # spans set (C, FCTYPE)
        ("BARLEYSTR", "S"),  # expanded from BARLEYSTR.(S;T)
        ("BARLEYSTR", "T"),  # expanded from BARLEYSTR.(S;T)
        ("BERSEEM", "C"),  # expanded from BERSEEM.(C;F;S)
        ("BERSEEM", "F"),  # expanded from BERSEEM.(C;F;S)
        ("BERSEEM", "S"),  # expanded from BERSEEM.(C;F;S)
        ("BRAN", "G"),  # expanded from BRAN.G
        ("COTSCAKE", "G"),  # expanded from COTSCAKE.G
        ("FBEAN", "G"),  # expanded from FBEAN.G
        ("FBEANFOD", "C"),  # expanded from FBEANFOD.(C;F;S;T)
        ("FBEANFOD", "F"),  # expanded from FBEANFOD.(C;F;S;T)
        ("FBEANFOD", "S"),  # expanded from FBEANFOD.(C;F;S;T)
        ("FBEANFOD", "T"),  # expanded from FBEANFOD.(C;F;S;T)
        ("FLSECAKE", "G"),  # expanded from FLSECAKE.G
        ("GNUTCAKE", "G"),  # expanded from GNUTCAKE.G
        ("GRDNUTFOD", "C"),  # expanded from GRDNUTFOD.(C;F;S)
        ("GRDNUTFOD", "F"),  # expanded from GRDNUTFOD.(C;F;S)
        ("GRDNUTFOD", "S"),  # expanded from GRDNUTFOD.(C;F;S)
        ("LENTILFOD", "S"),  # expanded from LENTILFOD.S
        ("MAIZE", "G"),  # expanded from MAIZE.G
        ("MAIZESTA", "C"),  # expanded from MAIZESTA.(C;F;S;T)
        ("MAIZESTA", "F"),  # expanded from MAIZESTA.(C;F;S;T)
        ("MAIZESTA", "S"),  # expanded from MAIZESTA.(C;F;S;T)
        ("MAIZESTA", "T"),  # expanded from MAIZESTA.(C;F;S;T)
        ("RICESTR", "S"),  # expanded from RICESTR.(S;T)
        ("RICESTR", "T"),  # expanded from RICESTR.(S;T)
        ("SBEETFOD", "C"),  # expanded from SBEETFOD.(C;F)
        ("SBEETFOD", "F"),  # expanded from SBEETFOD.(C;F)
        ("SBEETMOL", "G"),  # expanded from SBEETMOL.G
        ("SBEETPULP", "G"),  # expanded from SBEETPULP.G
        ("SCANEFOD", "C"),  # expanded from SCANEFOD.(C;F)
        ("SCANEFOD", "F"),  # expanded from SCANEFOD.(C;F)
        ("SCANEMOL", "G"),  # expanded from SCANEMOL.G
        ("SORGHUM", "G"),  # expanded from SORGHUM.G
        ("SOYACAKE", "G"),  # expanded from SOYACAKE.G
        ("SOYAFOD", "C"),  # expanded from SOYAFOD.(C;F;S)
        ("SOYAFOD", "F"),  # expanded from SOYAFOD.(C;F;S)
        ("SOYAFOD", "S"),  # expanded from SOYAFOD.(C;F;S)
        ("SOYBEAN", "G"),  # expanded from SOYBEAN.G
        ("VEGETFOD", "C"),  # expanded from VEGETFOD.(C;F)
        ("VEGETFOD", "F"),  # expanded from VEGETFOD.(C;F)
        ("WHEATSTR", "S"),  # expanded from WHEATSTR.(S;T)
        ("WHEATSTR", "T"),  # expanded from WHEATSTR.(S;T)
    ],
    # possible combinations of livestock activities and feeding methods
    "XAMMAP": [  # spans set (XA, M)
        ("BROI", "N"),  # expanded from BROI.N
        ("CCDP", "N"),  # expanded from CCDP.N
        ("FFAT", "N"),  # expanded from FFAT.N
        ("LAYE", "N"),  # expanded from LAYE.N
        ("REAR", "C"),  # expanded from REAR.(C;N)
        ("REAR", "N"),  # expanded from REAR.(C;N)
        ("SBDP", "N"),  # expanded from SBDP.N
        ("SCDP", "N"),  # expanded from SCDP.N
        ("SFAT", "C"),  # expanded from SFAT.C
        ("SHGO", "C"),  # expanded from SHGO.C
        ("TBCD", "C"),  # expanded from TBCD.C
        ("WEAN", "C"),  # expanded from WEAN.(C;N)
        ("WEAN", "N"),  # expanded from WEAN.(C;N)
    ],
    # crop commodities consumed by humans and livestock
    "CHL": [  # spans set (C)
    ],
    # drainage destinations
    "DRDEST": [
        ("TONILE"),  # proportion of drainage returning to Nile
        ("TODRAIN"),  # proportion of drainage going to drains to sea
        ("TOSINK"),  # proportion of drainage going to sinks
    ],
    # municipal and industrial diversions and returns
    "MIXX": [
        ("MUN-DIV"),  # municipal diversions
        ("MUN-RET"),  # municipal return flows
        ("MUN-NET"),  # net municipal use
        ("IND-DIV"),  # industrial diversions
        ("IND-RET"),  # industrial return flows
        ("IND-NET"),  # net industrial use
    ],
    # monthly time periods
    "TM": [
        ("OCT"),
        ("NOV"),
        ("DEC"),
        ("JAN"),
        ("FEB"),
        ("MAR"),
        ("APR"),
        ("MAY"),
        ("JUN"),
        ("JUL"),
        ("AUG"),
        ("SEP"),
    ],
    # water supply
    "MWD": [
        ("URB"),  # urban
        ("RUR"),  # rural
    ],
    #
    "S10": [
        ("DIV-AG+RI"),
        ("DIV-MUN"),
        ("DIV-IND"),
        ("DIV-TOT"),
        ("CON-AGR"),
        ("CON-MUN"),
        ("CON-IND"),
        ("CON-TOT"),
        ("WETSURF"),
        ("TO-SINK"),
        ("TO-DRAIN"),
    ],
    #
    "S10A": [
        ("DIV-AGR"),
        ("DIV-RIC"),
        ("DIV-MUN"),
        ("DIV-IND"),
        ("DIV-TOT"),
        ("CON-AGR"),
        ("CON-MUN"),
        ("CON-IND"),
        ("CON-TOT"),
        ("NETNILAGR"),
        ("NETNILMUN"),
        ("NETNILIND"),
        ("NETNILTOT"),
        ("WETSURF"),
        ("TOSINK-A"),
        ("TOSINK-MI"),
        ("TOSINK-T"),
        ("TONILE-A"),
        ("TONILE-MI"),
        ("TONILE-T"),
        ("TODRAIN-A"),
        ("TODRAIN-MI"),
        ("TODRAIN-T"),
        ("FRESH-SEA"),
        ("FISH-SEA"),
    ],
    #
    "S12": [
        ("DEMAND"),
        ("NILEWAT"),
        ("GW-PUMP"),
        ("DRAIN-RU"),
        ("SUPPLY"),
        ("SHORT"),
        ("PCT-SHORT"),
        ("AG-EFF"),
    ],
    #
    "S31": [
        ("RECHARGE"),
        ("PUMP-IRR"),
        ("PUMP-M+I"),
        ("IMBALANCE"),
    ],
    #
    "REPEMP": [
        ("FAMSUPPLY"),
        ("FAMILY"),
        ("HIRED"),
        ("UNEMPFAM%"),
        ("TOTAL"),
        ("CROPS%"),
        ("ANIMALS%"),
        ("CROPS"),
        ("ANIMALS"),
    ],
    # rice growing regions
    "RICEMAP": [  # spans set (R)
    ],
    # mapping of regions and primary and processed crop commodities
    "RCMAP": [  # spans set (R, C)
    ],
    # LNDREQ land requirement not >=0 and <=1 fed p fed for
    "CHECK0": [  # spans set (XC, PT, R, TM)
    ],
    # LNDREQ land requirement not 12 months for perennial crops for
    "CHECK0AA": [  # spans set (XC, PT, R)
    ],
    # LNDREQ land requirement not same for all PT
    "CHECK0A": [  # spans set (XC, PT, R)
    ],
    # LNDREQ land but no LABREQ1 labour specified for
    "CHECK1": [  # spans set (XC, PT, R, TM)
    ],
    # LABREQC1 labour requirement not same for all PT
    "CHECK1A": [  # spans set (XC, PT, R)
    ],
    # LABREQ1 labour requirement not >=0 and < 45 md p fed p months for
    "CHECK2A": [  # spans set (XC, PT, R, TM)
    ],
    # LABREQ1 labour but no LNDREQ land specified for
    "CHECK2": [  # spans set (XC, PT, R, TM)
    ],
    # WAVG male average not >10 and < 300 LE p day for
    "CHECK3": [  # spans set (R, TM)
    ],
    # WATER0 water requirement not >560 and < 9920 m3 p fed for
    "CHECK6": [  # spans set (XC, PT, R)
    ],
    # WATER0 water requirement not < 340 m3 p fed for
    "CHECK6A": [  # spans set (XC, PT, R)
    ],
    # YIELD0 yield not >0 and <110 AS IN RXCMAP for
    "CHECK12": [  # spans set (XC, C, R)
    ],
    # YIELD0 yield not specified for
    "CHECK12H": [  # spans set (XC, C, R)
    ],
    # YLDINC yield not >0 and <1.5 for
    "CHECK12A": [  # spans set (XC, C, *)
    ],
    # YLDINC yield not >0 and <2.2 for
    "CHECK12AA": [  # spans set (XC, C, *)
    ],
    # AVYIELD average yield not >0 and <55 for
    "CHECK12B": [  # spans set (XC, C)
    ],
    # WDEF water deficit not =>0 and <1.5 for
    "CHECK48": [  # spans set (WI)
    ],
    # Ky factor not >0 and <2 for
    "CHECK12C": [  # spans set (XC)
    ],
    # NLINPCST non-labour input costs >150 LE not specified for
    "CHECK12D": [  # spans set (XC, INP)
    ],
    # NLINPCST non-labour input costs >50 LE not specified for
    "CHECK12F": [  # spans set (XC, INP)
    ],
    # RENT >400 LE not specified for
    "CHECK12E": [  # spans set (XC, INP)
    ],
    # CSTPR processing cost not specified for
    "CHECK13": [  # spans set (CIP)
    ],
    # LABPR processing employment not specified for
    "CHECK14": [  # spans set (CIP)
    ],
    # DEMDAT base-price not specified for
    "CHECK15": [  # spans set (C, *)
    ],
    # DEMDAT export price exceeds import price for
    "CHECK15D": [  # spans set (C, *)
    ],
    # DEMDAT human rural consumption not specified for
    "CHECK16A": [  # spans set (C, *)
    ],
    # DEMDAT human urban consumption not specified for
    "CHECK16B": [  # spans set (C, *)
    ],
    # DEMDAT rural price elasticity out of range for
    "CHECK17A": [  # spans set (C, *)
    ],
    # DEMDAT urban price elasticity out of range for
    "CHECK17B": [  # spans set (C, *)
    ],
    # DEMDAT price elasticity PRIER05 out of range for
    "CHECK17C": [  # spans set (C, *)
    ],
    # DEMDAT price elasticity PRIEU05 out of range for
    "CHECK17D": [  # spans set (C, *)
    ],
    # DEMDAT price elasticity PELAR05 out of range for
    "CHECK17E": [  # spans set (C, *)
    ],
    # salt tolerace at 75% >1200 for
    "CHECK12K": [  # spans set (XC, *)
    ],
    # salt tolerace at 100% not <=500 for
    "CHECK12G": [  # spans set (XC, *)
    ],
    # historic areas not specified for
    "CHECK40": [  # spans set (XC, R)
    ],
    # FEEDREQ livestock feed requirements missing for
    "CHECK18": [  # spans set (XA, M)
    ],
    # LABREQLS husbandry labour not >0 and <12000 md for
    "CHECK22": [  # spans set (XA, M, LSLAB)
    ],
    # LSOINCST other livestock input costs missing for
    "CHECK23": [  # spans set (XA, M)
    ],
    # YLDS livestock yields missing for
    "CHECK24": [  # spans set (XA, M)
    ],
    # IEFF conveyance distribution efficiency not >0 and <1 for
    "CHECK43": [  # spans set (R)
    ],
    # FEFF field efficiency of irrigation not >0 and <1 for
    "CHECK43B": [  # spans set (R)
    ],
    # municipal demand not specified in MUNDEMG for
    "CHECK44A": [  # spans set (R)
    ],
    # INDDEM industrial demand not specified for
    "CHECK45": [  # spans set (R)
    ],
    # MUNRET municipal return factors not >0 and <1 for
    "CHECK46": [  # spans set (R)
    ],
    # fertilizers N P K
    "FERT": [
        ("NFERT"),
        ("PFERT"),
        ("KFERT"),
    ],
    # farm mechanisation tractor sprayer thresher
    "MHP": [
        ("TRAC"),
        ("SPRAY"),
        ("THRESH"),
    ],
}


if args.mode.lower() == "opt":
    model.add_component("C", pyo.Set(initialize=sets["C"]))
    model.add_component("CA", pyo.Set(initialize=sets["CA"], within=model.C))
    model.add_component("CIP", pyo.Set(initialize=sets["CIP"], within=model.C))
    model.add_component("CN", pyo.Set(initialize=sets["CN"], within=model.C))
    model.add_component("FCN", pyo.Set(initialize=sets["FCN"], within=model.C))
    model.add_component("CTR", pyo.Set(initialize=sets["CTR"], within=model.C))
    model.add_component("CNF", pyo.Set(initialize=sets["CNF"], within=model.C))
    model.add_component("CND", pyo.Set(initialize=sets["CND"], within=model.C))
    model.add_component("COP", pyo.Set(initialize=sets["COP"], within=model.C))
    model.add_component("CNPP", pyo.Set(initialize=sets["CNPP"], within=model.C))
    model.add_component("CNPF", pyo.Set(initialize=sets["CNPF"], within=model.C))
    model.add_component("TRADE", pyo.Set(initialize=sets["TRADE"], within=model.C))
    model.add_component("TRADE2", pyo.Set(initialize=sets["TRADE2"], within=model.C))
    model.add_component("BURN", pyo.Set(initialize=sets["BURN"], within=model.C))
    model.add_component("INP", pyo.Set(initialize=sets["INP"]))
    model.add_component("XC", pyo.Set(initialize=sets["XC"]))
    model.add_component("XCCROP", pyo.Set(initialize=sets["XCCROP"]))
    model.add_component("MAPXCCROP", pyo.Set(initialize=sets["MAPXCCROP"], within=model.XCCROP * model.XC))
    model.add_component("XCPP", pyo.Set(initialize=sets["XCPP"], within=model.XC))
    model.add_component("SES", pyo.Set(initialize=sets["SES"], within=model.XC))
    model.add_component("GNU", pyo.Set(initialize=sets["GNU"], within=model.XC))
    model.add_component("SOY", pyo.Set(initialize=sets["SOY"], within=model.XC))
    model.add_component("XCCOT", pyo.Set(initialize=sets["XCCOT"], within=model.XC))
    model.add_component("XCCIT", pyo.Set(initialize=sets["XCCIT"], within=model.XC))
    model.add_component("XCPOT", pyo.Set(initialize=sets["XCPOT"], within=model.XC))
    model.add_component("XCRICE", pyo.Set(initialize=sets["XCRICE"], within=model.XC))
    model.add_component("XCSCA", pyo.Set(initialize=sets["XCSCA"], within=model.XC))
    model.add_component("XCSBE", pyo.Set(initialize=sets["XCSBE"], within=model.XC))
    model.add_component("XCVEGW", pyo.Set(initialize=sets["XCVEGW"], within=model.XC))
    model.add_component("XCVEGN", pyo.Set(initialize=sets["XCVEGN"], within=model.XC))
    model.add_component("XCVEGS", pyo.Set(initialize=sets["XCVEGS"], within=model.XC))
    model.add_component("XCGRAIN", pyo.Set(initialize=sets["XCGRAIN"], within=model.XC))
    model.add_component("XCOILS", pyo.Set(initialize=sets["XCOILS"], within=model.XC))
    model.add_component("XCOTLEG", pyo.Set(initialize=sets["XCOTLEG"], within=model.XC))
    model.add_component("XCFOD", pyo.Set(initialize=sets["XCFOD"], within=model.XC))
    model.add_component("XCSORG", pyo.Set(initialize=sets["XCSORG"], within=model.XC))
    model.add_component("WXC", pyo.Set(initialize=sets["WXC"], within=model.XC))
    model.add_component("NXC", pyo.Set(initialize=sets["NXC"], within=model.XC))
    model.add_component("SXC", pyo.Set(initialize=sets["SXC"], within=model.XC))
    model.add_component("PXC", pyo.Set(initialize=sets["PXC"], within=model.XC))
    model.add_component("VP", pyo.Set(initialize=sets["VP"], within=model.XC))
    model.add_component("AXC", pyo.Set(initialize=sets["AXC"], within=model.XC))
    model.add_component("ANRXC", pyo.Set(initialize=sets["ANRXC"], within=model.XC))
    model.add_component("XCCMAP", pyo.Set(initialize=sets["XCCMAP"], within=model.XC * model.C))
    model.add_component("XCPCMAP", pyo.Set(initialize=sets["XCPCMAP"], within=model.XC * model.C))
    model.add_component("PT", pyo.Set(initialize=sets["PT"]))
    model.add_component("WI", pyo.Set(initialize=sets["WI"]))
    model.add_component("R", pyo.Set(initialize=sets["R"]))
    model.add_component("OL", pyo.Set(initialize=sets["OL"], within=model.R))
    model.add_component("OLC", pyo.Set(initialize=sets["OLC"], within=model.R))
    model.add_component("ONL", pyo.Set(initialize=sets["ONL"], within=model.R))
    model.add_component("OLN", pyo.Set(initialize=sets["OLN"], within=model.R))
    model.add_component("", pyo.Set(initialize=sets[""]))
    model.add_component("ADR", pyo.Set(initialize=sets["ADR"], within=model.R))
    model.add_component("WDR", pyo.Set(initialize=sets["WDR"], within=model.R))
    model.add_component("MDR", pyo.Set(initialize=sets["MDR"], within=model.R))
    model.add_component("EDR", pyo.Set(initialize=sets["EDR"], within=model.R))
    model.add_component("UER", pyo.Set(initialize=sets["UER"], within=model.R))
    model.add_component("MER", pyo.Set(initialize=sets["MER"], within=model.R))
    model.add_component("VAR", pyo.Set(initialize=sets["VAR"], within=model.R))
    model.add_component("RSW", pyo.Set(initialize=sets["RSW"], within=model.R))
    model.add_component("DGW", pyo.Set(initialize=sets["DGW"], within=model.R))
    model.add_component("RL", pyo.Set(initialize=sets["RL"], within=model.R))
    model.add_component("SEA", pyo.Set(initialize=sets["SEA"]))
    model.add_component("UENV", pyo.Set(initialize=sets["UENV"], within=model.R))
    model.add_component("XA", pyo.Set(initialize=sets["XA"]))
    model.add_component("M", pyo.Set(initialize=sets["M"]))
    model.add_component("FEEDS", pyo.Set(initialize=sets["FEEDS"]))
    model.add_component("POFEEDS", pyo.Set(initialize=sets["POFEEDS"], within=model.FEEDS))
    model.add_component("LSLAB", pyo.Set(initialize=sets["LSLAB"]))
    model.add_component("LSOINP", pyo.Set(initialize=sets["LSOINP"]))
    model.add_component("FEEDIND", pyo.Set(initialize=sets["FEEDIND"]))
    model.add_component("CF", pyo.Set(initialize=sets["CF"], within=model.C))
    model.add_component("FCMAP", pyo.Set(initialize=sets["FCMAP"], within=model.XC * model.C))
    model.add_component("FCTYPE", pyo.Set(initialize=sets["FCTYPE"]))
    model.add_component("CFCTMAP", pyo.Set(initialize=sets["CFCTMAP"], within=model.C * model.FCTYPE))
    model.add_component("XAMMAP", pyo.Set(initialize=sets["XAMMAP"], within=model.XA * model.M))
    model.add_component("DRDEST", pyo.Set(initialize=sets["DRDEST"]))
    model.add_component("MIXX", pyo.Set(initialize=sets["MIXX"]))
    model.add_component("TM", pyo.Set(initialize=sets["TM"]))
    model.add_component("MWD", pyo.Set(initialize=sets["MWD"]))
    model.add_component("S10", pyo.Set(initialize=sets["S10"]))
    model.add_component("S10A", pyo.Set(initialize=sets["S10A"]))
    model.add_component("S12", pyo.Set(initialize=sets["S12"]))
    model.add_component("S31", pyo.Set(initialize=sets["S31"]))
    model.add_component("REPEMP", pyo.Set(initialize=sets["REPEMP"]))
    model.add_component("FERT", pyo.Set(initialize=sets["FERT"]))
    model.add_component("MHP", pyo.Set(initialize=sets["MHP"]))

def addCellInDFDict(df_dict, col, row):
    if row not in df_dict["index"]:
        df_dict["index"].append(row)
        for key in df_dict:
            if key != "index":
                df_dict[key].append(float("nan"))
    if col not in df_dict:
        df_dict[col] = [float("nan") for _ in range(len(df_dict["index"]))]

# Table: mapping of crops to regions

df_RXCMAP = pd.read_excel("tables/RXCMAP.xlsx")
for col in df_RXCMAP.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table RXCMAP is a float, cast it to an int before casting it to a str, rename it.")
            df_RXCMAP.rename(columns={col: int(col)}, inplace=True)
df_RXCMAP.columns = df_RXCMAP.columns.astype(str)

missing_RXCMAP_rows = []
missing_RXCMAP_cols = []

def table_RXCMAP_0(R, XC):
    col = XC
    row = R
    if row not in df_RXCMAP["index"].tolist():
        if row not in missing_RXCMAP_rows:
            # print("Warning: row " + row + " is not in table RXCMAP, return 0.0")
            missing_RXCMAP_rows.append(row)
        return 0.0
    if col not in df_RXCMAP.columns:
        if col not in missing_RXCMAP_cols:
            # print("Warning: column " + col + " is not in table RXCMAP, return 0.0")
            missing_RXCMAP_cols.append(col)
        return 0.0
    value = df_RXCMAP[col][df_RXCMAP["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_RXCMAP[col][df_RXCMAP["index"].tolist().index(row)]
def table_RXCMAP(R, XC):
    return table_RXCMAP_0(R, XC)

# Table: land req. by governorate and plant. time (fed p fed)

df_LNDREQ = pd.read_excel("tables/LNDREQ.xlsx")
for col in df_LNDREQ.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table LNDREQ is a float, cast it to an int before casting it to a str, rename it.")
            df_LNDREQ.rename(columns={col: int(col)}, inplace=True)
df_LNDREQ.columns = df_LNDREQ.columns.astype(str)

missing_LNDREQ_rows = []
missing_LNDREQ_cols = []

def table_LNDREQ_0(XC, PT, R, TM):
    col = TM
    row = XC + "." + PT + "." + R
    if row not in df_LNDREQ["index"].tolist():
        if row not in missing_LNDREQ_rows:
            # print("Warning: row " + row + " is not in table LNDREQ, return 0.0")
            missing_LNDREQ_rows.append(row)
        return 0.0
    if col not in df_LNDREQ.columns:
        if col not in missing_LNDREQ_cols:
            # print("Warning: column " + col + " is not in table LNDREQ, return 0.0")
            missing_LNDREQ_cols.append(col)
        return 0.0
    value = df_LNDREQ[col][df_LNDREQ["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_LNDREQ[col][df_LNDREQ["index"].tolist().index(row)]
def table_LNDREQ_1(XC, PT, R, TM):
    if R == "ASSUIT":
        return table_LNDREQ_0(XC, PT, "ASWAN", TM)
    else:
        return table_LNDREQ_0(XC, PT, R, TM)

def table_LNDREQ_2(XC, PT, R, TM):
    if R == "SUHAG":
        return table_LNDREQ_1(XC, PT, "ASWAN", TM)
    else:
        return table_LNDREQ_1(XC, PT, R, TM)

def table_LNDREQ_3(XC, PT, R, TM):
    if R == "QENA":
        return table_LNDREQ_2(XC, PT, "ASWAN", TM)
    else:
        return table_LNDREQ_2(XC, PT, R, TM)

def table_LNDREQ_4(XC, PT, R, TM):
    if R == "LUXOR":
        return table_LNDREQ_3(XC, PT, "ASWAN", TM)
    else:
        return table_LNDREQ_3(XC, PT, R, TM)

def table_LNDREQ_5(XC, PT, R, TM):
    if R == "NVALLEY":
        return table_LNDREQ_4(XC, PT, "ASWAN", TM)
    else:
        return table_LNDREQ_4(XC, PT, R, TM)

def table_LNDREQ_6(XC, PT, R, TM):
    if R == "TOSHKA":
        return table_LNDREQ_5(XC, PT, "ASWAN", TM)
    else:
        return table_LNDREQ_5(XC, PT, R, TM)

def table_LNDREQ_7(XC, PT, R, TM):
    if R == "GIZA":
        return table_LNDREQ_6(XC, PT, "ASWAN", TM)
    else:
        return table_LNDREQ_6(XC, PT, R, TM)

def table_LNDREQ_8(XC, PT, R, TM):
    if R == "BNISUEF":
        return table_LNDREQ_7(XC, PT, "ASWAN", TM)
    else:
        return table_LNDREQ_7(XC, PT, R, TM)

def table_LNDREQ_9(XC, PT, R, TM):
    if R == "FAYOUM":
        return table_LNDREQ_8(XC, PT, "ASWAN", TM)
    else:
        return table_LNDREQ_8(XC, PT, R, TM)

def table_LNDREQ_10(XC, PT, R, TM):
    if R == "MENIA":
        return table_LNDREQ_9(XC, PT, "ASWAN", TM)
    else:
        return table_LNDREQ_9(XC, PT, R, TM)

def table_LNDREQ_11(XC, PT, R, TM):
    if R == "ALEX":
        return table_LNDREQ_10(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_10(XC, PT, R, TM)

def table_LNDREQ_12(XC, PT, R, TM):
    if R == "NUBARIA":
        return table_LNDREQ_11(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_11(XC, PT, R, TM)

def table_LNDREQ_13(XC, PT, R, TM):
    if R == "BEHAIRA":
        return table_LNDREQ_12(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_12(XC, PT, R, TM)

def table_LNDREQ_14(XC, PT, R, TM):
    if R == "GHARBIA":
        return table_LNDREQ_13(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_13(XC, PT, R, TM)

def table_LNDREQ_15(XC, PT, R, TM):
    if R == "KFRSHIK":
        return table_LNDREQ_14(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_14(XC, PT, R, TM)

def table_LNDREQ_16(XC, PT, R, TM):
    if R == "DAMIETA":
        return table_LNDREQ_15(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_15(XC, PT, R, TM)

def table_LNDREQ_17(XC, PT, R, TM):
    if R == "SHARKIA":
        return table_LNDREQ_16(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_16(XC, PT, R, TM)

def table_LNDREQ_18(XC, PT, R, TM):
    if R == "ISMALIA":
        return table_LNDREQ_17(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_17(XC, PT, R, TM)

def table_LNDREQ_19(XC, PT, R, TM):
    if R == "PRTSAID":
        return table_LNDREQ_18(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_18(XC, PT, R, TM)

def table_LNDREQ_20(XC, PT, R, TM):
    if R == "SUEZ":
        return table_LNDREQ_19(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_19(XC, PT, R, TM)

def table_LNDREQ_21(XC, PT, R, TM):
    if R == "MENUFIA":
        return table_LNDREQ_20(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_20(XC, PT, R, TM)

def table_LNDREQ_22(XC, PT, R, TM):
    if R == "QLYUBIA":
        return table_LNDREQ_21(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_21(XC, PT, R, TM)

def table_LNDREQ_23(XC, PT, R, TM):
    if R == "CAIRO":
        return table_LNDREQ_22(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_22(XC, PT, R, TM)

def table_LNDREQ_24(XC, PT, R, TM):
    if R == "MATRUH":
        return table_LNDREQ_23(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_23(XC, PT, R, TM)

def table_LNDREQ_25(XC, PT, R, TM):
    if R == "REDSEA":
        return table_LNDREQ_24(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_24(XC, PT, R, TM)

def table_LNDREQ_26(XC, PT, R, TM):
    if R == "NSINAI":
        return table_LNDREQ_25(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_25(XC, PT, R, TM)

def table_LNDREQ_27(XC, PT, R, TM):
    if R == "SSINAI":
        return table_LNDREQ_26(XC, PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_26(XC, PT, R, TM)

def table_LNDREQ_28(XC, PT, R, TM):
    if XC == "PADDY1" and R == "GIZA":
        return table_LNDREQ_27("PADDY1", PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_27(XC, PT, R, TM)

def table_LNDREQ_29(XC, PT, R, TM):
    if XC == "PADDY1" and R == "CAIRO":
        return table_LNDREQ_28("PADDY1", PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_28(XC, PT, R, TM)

def table_LNDREQ_30(XC, PT, R, TM):
    if XC == "PADDY1" and R == "BNISUEF":
        return table_LNDREQ_29("PADDY1", PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_29(XC, PT, R, TM)

def table_LNDREQ_31(XC, PT, R, TM):
    if XC == "PADDY1" and R == "FAYOUM":
        return table_LNDREQ_30("PADDY1", PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_30(XC, PT, R, TM)

def table_LNDREQ_32(XC, PT, R, TM):
    if XC == "PADDY1" and R == "MENIA":
        return table_LNDREQ_31("PADDY1", PT, "DAKHLIA", TM)
    else:
        return table_LNDREQ_31(XC, PT, R, TM)

def table_LNDREQ(XC, PT, R, TM):
    return table_LNDREQ_32(XC, PT, R, TM)

# Table: land availability (000fed)

df_LAND = pd.read_excel("tables/LAND.xlsx")
for col in df_LAND.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table LAND is a float, cast it to an int before casting it to a str, rename it.")
            df_LAND.rename(columns={col: int(col)}, inplace=True)
df_LAND.columns = df_LAND.columns.astype(str)

missing_LAND_rows = []
missing_LAND_cols = []

def table_LAND_0(R, IMP_LAND_1):
    col = IMP_LAND_1
    row = R
    if row not in df_LAND["index"].tolist():
        if row not in missing_LAND_rows:
            # print("Warning: row " + row + " is not in table LAND, return 0.0")
            missing_LAND_rows.append(row)
        return 0.0
    if col not in df_LAND.columns:
        if col not in missing_LAND_cols:
            # print("Warning: column " + col + " is not in table LAND, return 0.0")
            missing_LAND_cols.append(col)
        return 0.0
    value = df_LAND[col][df_LAND["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_LAND[col][df_LAND["index"].tolist().index(row)]
def table_LAND(R, IMP_LAND_1):
    return table_LAND_0(R, IMP_LAND_1)

# Table: labor requirement by crop and planting time (md p fed)

df_LABREQC1 = pd.read_excel("tables/LABREQC1.xlsx")
for col in df_LABREQC1.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table LABREQC1 is a float, cast it to an int before casting it to a str, rename it.")
            df_LABREQC1.rename(columns={col: int(col)}, inplace=True)
df_LABREQC1.columns = df_LABREQC1.columns.astype(str)

missing_LABREQC1_rows = []
missing_LABREQC1_cols = []

def table_LABREQC1_0(XC, PT, R, TM):
    col = TM
    row = XC + "." + PT + "." + R
    if row not in df_LABREQC1["index"].tolist():
        if row not in missing_LABREQC1_rows:
            # print("Warning: row " + row + " is not in table LABREQC1, return 0.0")
            missing_LABREQC1_rows.append(row)
        return 0.0
    if col not in df_LABREQC1.columns:
        if col not in missing_LABREQC1_cols:
            # print("Warning: column " + col + " is not in table LABREQC1, return 0.0")
            missing_LABREQC1_cols.append(col)
        return 0.0
    value = df_LABREQC1[col][df_LABREQC1["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_LABREQC1[col][df_LABREQC1["index"].tolist().index(row)]
def table_LABREQC1_1(XC, PT, R, TM):
    if R == "ASSUIT":
        return table_LABREQC1_0(XC, PT, "ASWAN", TM)
    else:
        return table_LABREQC1_0(XC, PT, R, TM)

def table_LABREQC1_2(XC, PT, R, TM):
    if R == "SUHAG":
        return table_LABREQC1_1(XC, PT, "ASWAN", TM)
    else:
        return table_LABREQC1_1(XC, PT, R, TM)

def table_LABREQC1_3(XC, PT, R, TM):
    if R == "QENA":
        return table_LABREQC1_2(XC, PT, "ASWAN", TM)
    else:
        return table_LABREQC1_2(XC, PT, R, TM)

def table_LABREQC1_4(XC, PT, R, TM):
    if R == "LUXOR":
        return table_LABREQC1_3(XC, PT, "ASWAN", TM)
    else:
        return table_LABREQC1_3(XC, PT, R, TM)

def table_LABREQC1_5(XC, PT, R, TM):
    if R == "NVALLEY":
        return table_LABREQC1_4(XC, PT, "ASWAN", TM)
    else:
        return table_LABREQC1_4(XC, PT, R, TM)

def table_LABREQC1_6(XC, PT, R, TM):
    if R == "TOSHKA":
        return table_LABREQC1_5(XC, PT, "ASWAN", TM)
    else:
        return table_LABREQC1_5(XC, PT, R, TM)

def table_LABREQC1_7(XC, PT, R, TM):
    if R == "GIZA":
        return table_LABREQC1_6(XC, PT, "ASWAN", TM)
    else:
        return table_LABREQC1_6(XC, PT, R, TM)

def table_LABREQC1_8(XC, PT, R, TM):
    if R == "BNISUEF":
        return table_LABREQC1_7(XC, PT, "ASWAN", TM)
    else:
        return table_LABREQC1_7(XC, PT, R, TM)

def table_LABREQC1_9(XC, PT, R, TM):
    if R == "FAYOUM":
        return table_LABREQC1_8(XC, PT, "ASWAN", TM)
    else:
        return table_LABREQC1_8(XC, PT, R, TM)

def table_LABREQC1_10(XC, PT, R, TM):
    if R == "MENIA":
        return table_LABREQC1_9(XC, PT, "ASWAN", TM)
    else:
        return table_LABREQC1_9(XC, PT, R, TM)

def table_LABREQC1_11(XC, PT, R, TM):
    if R == "ALEX":
        return table_LABREQC1_10(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_10(XC, PT, R, TM)

def table_LABREQC1_12(XC, PT, R, TM):
    if R == "BEHAIRA":
        return table_LABREQC1_11(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_11(XC, PT, R, TM)

def table_LABREQC1_13(XC, PT, R, TM):
    if R == "NUBARIA":
        return table_LABREQC1_12(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_12(XC, PT, R, TM)

def table_LABREQC1_14(XC, PT, R, TM):
    if R == "GHARBIA":
        return table_LABREQC1_13(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_13(XC, PT, R, TM)

def table_LABREQC1_15(XC, PT, R, TM):
    if R == "KFRSHIK":
        return table_LABREQC1_14(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_14(XC, PT, R, TM)

def table_LABREQC1_16(XC, PT, R, TM):
    if R == "DAMIETA":
        return table_LABREQC1_15(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_15(XC, PT, R, TM)

def table_LABREQC1_17(XC, PT, R, TM):
    if R == "SHARKIA":
        return table_LABREQC1_16(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_16(XC, PT, R, TM)

def table_LABREQC1_18(XC, PT, R, TM):
    if R == "ISMALIA":
        return table_LABREQC1_17(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_17(XC, PT, R, TM)

def table_LABREQC1_19(XC, PT, R, TM):
    if R == "PRTSAID":
        return table_LABREQC1_18(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_18(XC, PT, R, TM)

def table_LABREQC1_20(XC, PT, R, TM):
    if R == "SUEZ":
        return table_LABREQC1_19(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_19(XC, PT, R, TM)

def table_LABREQC1_21(XC, PT, R, TM):
    if R == "MENUFIA":
        return table_LABREQC1_20(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_20(XC, PT, R, TM)

def table_LABREQC1_22(XC, PT, R, TM):
    if R == "QLYUBIA":
        return table_LABREQC1_21(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_21(XC, PT, R, TM)

def table_LABREQC1_23(XC, PT, R, TM):
    if R == "CAIRO":
        return table_LABREQC1_22(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_22(XC, PT, R, TM)

def table_LABREQC1_24(XC, PT, R, TM):
    if R == "MATRUH":
        return table_LABREQC1_23(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_23(XC, PT, R, TM)

def table_LABREQC1_25(XC, PT, R, TM):
    if R == "REDSEA":
        return table_LABREQC1_24(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_24(XC, PT, R, TM)

def table_LABREQC1_26(XC, PT, R, TM):
    if R == "NSINAI":
        return table_LABREQC1_25(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_25(XC, PT, R, TM)

def table_LABREQC1_27(XC, PT, R, TM):
    if R == "SSINAI":
        return table_LABREQC1_26(XC, PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_26(XC, PT, R, TM)

def table_LABREQC1_28(XC, PT, R, TM):
    if XC == "PADDY1" and R == "GIZA":
        return table_LABREQC1_27("PADDY1", PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_27(XC, PT, R, TM)

def table_LABREQC1_29(XC, PT, R, TM):
    if XC == "PADDY1" and R == "BNISUEF":
        return table_LABREQC1_28("PADDY1", PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_28(XC, PT, R, TM)

def table_LABREQC1_30(XC, PT, R, TM):
    if XC == "PADDY1" and R == "FAYOUM":
        return table_LABREQC1_29("PADDY1", PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_29(XC, PT, R, TM)

def table_LABREQC1_31(XC, PT, R, TM):
    if XC == "PADDY1" and R == "MENIA":
        return table_LABREQC1_30("PADDY1", PT, "DAKHLIA", TM)
    else:
        return table_LABREQC1_30(XC, PT, R, TM)

def table_LABREQC1(XC, PT, R, TM):
    return table_LABREQC1_31(XC, PT, R, TM)

# Table: avg male wages (LE p day)

df_WAVG = pd.read_excel("tables/WAVG.xlsx")
for col in df_WAVG.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table WAVG is a float, cast it to an int before casting it to a str, rename it.")
            df_WAVG.rename(columns={col: int(col)}, inplace=True)
df_WAVG.columns = df_WAVG.columns.astype(str)

missing_WAVG_rows = []
missing_WAVG_cols = []

def table_WAVG_0(R, TM):
    col = TM
    row = R
    if row not in df_WAVG["index"].tolist():
        if row not in missing_WAVG_rows:
            # print("Warning: row " + row + " is not in table WAVG, return 0.0")
            missing_WAVG_rows.append(row)
        return 0.0
    if col not in df_WAVG.columns:
        if col not in missing_WAVG_cols:
            # print("Warning: column " + col + " is not in table WAVG, return 0.0")
            missing_WAVG_cols.append(col)
        return 0.0
    value = df_WAVG[col][df_WAVG["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_WAVG[col][df_WAVG["index"].tolist().index(row)]
def table_WAVG_1(R, TM):
    if R == "ALEX":
        return table_WAVG_0("DAKHLIA", TM)
    else:
        return table_WAVG_0(R, TM)

def table_WAVG_2(R, TM):
    if R == "BEHAIRA":
        return table_WAVG_1("DAKHLIA", TM)
    else:
        return table_WAVG_1(R, TM)

def table_WAVG_3(R, TM):
    if R == "NUBARIA":
        return table_WAVG_2("DAKHLIA", TM)
    else:
        return table_WAVG_2(R, TM)

def table_WAVG_4(R, TM):
    if R == "GHARBIA":
        return table_WAVG_3("DAKHLIA", TM)
    else:
        return table_WAVG_3(R, TM)

def table_WAVG_5(R, TM):
    if R == "KFRSHIK":
        return table_WAVG_4("DAKHLIA", TM)
    else:
        return table_WAVG_4(R, TM)

def table_WAVG_6(R, TM):
    if R == "DAMIETA":
        return table_WAVG_5("DAKHLIA", TM)
    else:
        return table_WAVG_5(R, TM)

def table_WAVG_7(R, TM):
    if R == "SHARKIA":
        return table_WAVG_6("DAKHLIA", TM)
    else:
        return table_WAVG_6(R, TM)

def table_WAVG_8(R, TM):
    if R == "ISMALIA":
        return table_WAVG_7("DAKHLIA", TM)
    else:
        return table_WAVG_7(R, TM)

def table_WAVG_9(R, TM):
    if R == "PRTSAID":
        return table_WAVG_8("DAKHLIA", TM)
    else:
        return table_WAVG_8(R, TM)

def table_WAVG_10(R, TM):
    if R == "SUEZ":
        return table_WAVG_9("DAKHLIA", TM)
    else:
        return table_WAVG_9(R, TM)

def table_WAVG_11(R, TM):
    if R == "MENUFIA":
        return table_WAVG_10("DAKHLIA", TM)
    else:
        return table_WAVG_10(R, TM)

def table_WAVG_12(R, TM):
    if R == "QLYUBIA":
        return table_WAVG_11("DAKHLIA", TM)
    else:
        return table_WAVG_11(R, TM)

def table_WAVG_13(R, TM):
    if R == "CAIRO":
        return table_WAVG_12("DAKHLIA", TM)
    else:
        return table_WAVG_12(R, TM)

def table_WAVG_14(R, TM):
    if R == "MATRUH":
        return table_WAVG_13("DAKHLIA", TM)
    else:
        return table_WAVG_13(R, TM)

def table_WAVG_15(R, TM):
    if R == "REDSEA":
        return table_WAVG_14("DAKHLIA", TM)
    else:
        return table_WAVG_14(R, TM)

def table_WAVG_16(R, TM):
    if R == "GIZA":
        return table_WAVG_15("FAYOUM", TM)
    else:
        return table_WAVG_15(R, TM)

def table_WAVG_17(R, TM):
    if R == "BNISUEF":
        return table_WAVG_16("FAYOUM", TM)
    else:
        return table_WAVG_16(R, TM)

def table_WAVG_18(R, TM):
    if R == "MENIA":
        return table_WAVG_17("FAYOUM", TM)
    else:
        return table_WAVG_17(R, TM)

def table_WAVG_19(R, TM):
    if R == "ASSUIT":
        return table_WAVG_18("ASWAN", TM)
    else:
        return table_WAVG_18(R, TM)

def table_WAVG_20(R, TM):
    if R == "SUHAG":
        return table_WAVG_19("ASWAN", TM)
    else:
        return table_WAVG_19(R, TM)

def table_WAVG_21(R, TM):
    if R == "QENA":
        return table_WAVG_20("ASWAN", TM)
    else:
        return table_WAVG_20(R, TM)

def table_WAVG_22(R, TM):
    if R == "LUXOR":
        return table_WAVG_21("ASWAN", TM)
    else:
        return table_WAVG_21(R, TM)

def table_WAVG_23(R, TM):
    if R == "NVALLEY":
        return table_WAVG_22("ASWAN", TM)
    else:
        return table_WAVG_22(R, TM)

def table_WAVG_24(R, TM):
    if R == "TOSHKA":
        return table_WAVG_23("ASWAN", TM)
    else:
        return table_WAVG_23(R, TM)

def table_WAVG_25(R, TM):
    if R == "NSINAI":
        return (table_WAVG_24("DAKHLIA", TM) * 1.2)
    else:
        return table_WAVG_24(R, TM)

def table_WAVG_26(R, TM):
    if R == "SSINAI":
        return (table_WAVG_25("DAKHLIA", TM) * 1.2)
    else:
        return table_WAVG_25(R, TM)

def table_WAVG_27(R, TM):
    if R == "TOSHKA":
        return (table_WAVG_26("ASWAN", TM) * 1.2)
    else:
        return table_WAVG_26(R, TM)

def table_WAVG(R, TM):
    return table_WAVG_27(R, TM)

# Table: gross crop consumptive use by pl. date and region (m3 p fed)

df_WATER0 = pd.read_excel("tables/WATER0.xlsx")
for col in df_WATER0.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table WATER0 is a float, cast it to an int before casting it to a str, rename it.")
            df_WATER0.rename(columns={col: int(col)}, inplace=True)
df_WATER0.columns = df_WATER0.columns.astype(str)

missing_WATER0_rows = []
missing_WATER0_cols = []

def table_WATER0_0(XC, PT, R):
    col = R
    row = XC + "." + PT
    if row not in df_WATER0["index"].tolist():
        if row not in missing_WATER0_rows:
            # print("Warning: row " + row + " is not in table WATER0, return 0.0")
            missing_WATER0_rows.append(row)
        return 0.0
    if col not in df_WATER0.columns:
        if col not in missing_WATER0_cols:
            # print("Warning: column " + col + " is not in table WATER0, return 0.0")
            missing_WATER0_cols.append(col)
        return 0.0
    value = df_WATER0[col][df_WATER0["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_WATER0[col][df_WATER0["index"].tolist().index(row)]
def table_WATER0_1(XC, PT, R):
    if R == "ALEX":
        return table_WATER0_0(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_0(XC, PT, R)

def table_WATER0_2(XC, PT, R):
    if R == "BEHAIRA":
        return table_WATER0_1(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_1(XC, PT, R)

def table_WATER0_3(XC, PT, R):
    if R == "NUBARIA":
        return table_WATER0_2(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_2(XC, PT, R)

def table_WATER0_4(XC, PT, R):
    if R == "GHARBIA":
        return table_WATER0_3(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_3(XC, PT, R)

def table_WATER0_5(XC, PT, R):
    if R == "KFRSHIK":
        return table_WATER0_4(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_4(XC, PT, R)

def table_WATER0_6(XC, PT, R):
    if R == "DAMIETA":
        return table_WATER0_5(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_5(XC, PT, R)

def table_WATER0_7(XC, PT, R):
    if R == "SHARKIA":
        return table_WATER0_6(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_6(XC, PT, R)

def table_WATER0_8(XC, PT, R):
    if R == "ISMALIA":
        return table_WATER0_7(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_7(XC, PT, R)

def table_WATER0_9(XC, PT, R):
    if R == "PRTSAID":
        return table_WATER0_8(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_8(XC, PT, R)

def table_WATER0_10(XC, PT, R):
    if R == "SUEZ":
        return table_WATER0_9(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_9(XC, PT, R)

def table_WATER0_11(XC, PT, R):
    if R == "MENUFIA":
        return table_WATER0_10(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_10(XC, PT, R)

def table_WATER0_12(XC, PT, R):
    if R == "QLYUBIA":
        return table_WATER0_11(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_11(XC, PT, R)

def table_WATER0_13(XC, PT, R):
    if R == "CAIRO":
        return table_WATER0_12(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_12(XC, PT, R)

def table_WATER0_14(XC, PT, R):
    if R == "MATRUH":
        return table_WATER0_13(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_13(XC, PT, R)

def table_WATER0_15(XC, PT, R):
    if R == "REDSEA":
        return table_WATER0_14(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_14(XC, PT, R)

def table_WATER0_16(XC, PT, R):
    if R == "NSINAI":
        return table_WATER0_15(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_15(XC, PT, R)

def table_WATER0_17(XC, PT, R):
    if R == "SSINAI":
        return table_WATER0_16(XC, PT, "DAKHLIA")
    else:
        return table_WATER0_16(XC, PT, R)

def table_WATER0_18(XC, PT, R):
    if R == "GIZA":
        return table_WATER0_17(XC, PT, "FAYOUM")
    else:
        return table_WATER0_17(XC, PT, R)

def table_WATER0_19(XC, PT, R):
    if R == "BNISUEF":
        return table_WATER0_18(XC, PT, "FAYOUM")
    else:
        return table_WATER0_18(XC, PT, R)

def table_WATER0_20(XC, PT, R):
    if R == "MENIA":
        return table_WATER0_19(XC, PT, "FAYOUM")
    else:
        return table_WATER0_19(XC, PT, R)

def table_WATER0_21(XC, PT, R):
    if R == "ASSUIT":
        return table_WATER0_20(XC, PT, "ASWAN")
    else:
        return table_WATER0_20(XC, PT, R)

def table_WATER0_22(XC, PT, R):
    if R == "SUHAG":
        return table_WATER0_21(XC, PT, "ASWAN")
    else:
        return table_WATER0_21(XC, PT, R)

def table_WATER0_23(XC, PT, R):
    if R == "QENA":
        return table_WATER0_22(XC, PT, "ASWAN")
    else:
        return table_WATER0_22(XC, PT, R)

def table_WATER0_24(XC, PT, R):
    if R == "LUXOR":
        return table_WATER0_23(XC, PT, "ASWAN")
    else:
        return table_WATER0_23(XC, PT, R)

def table_WATER0_25(XC, PT, R):
    if R == "NVALLEY":
        return table_WATER0_24(XC, PT, "ASWAN")
    else:
        return table_WATER0_24(XC, PT, R)

def table_WATER0_26(XC, PT, R):
    if R == "TOSHKA":
        return table_WATER0_25(XC, PT, "ASWAN")
    else:
        return table_WATER0_25(XC, PT, R)

def table_WATER0(XC, PT, R):
    return table_WATER0_26(XC, PT, R)

# Table: effective rainfall for each crop (m3 p fed)

df_RAINFALL = pd.read_excel("tables/RAINFALL.xlsx")
for col in df_RAINFALL.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table RAINFALL is a float, cast it to an int before casting it to a str, rename it.")
            df_RAINFALL.rename(columns={col: int(col)}, inplace=True)
df_RAINFALL.columns = df_RAINFALL.columns.astype(str)

missing_RAINFALL_rows = []
missing_RAINFALL_cols = []

def table_RAINFALL_0(XC, PT, R):
    col = R
    row = XC + "." + PT
    if row not in df_RAINFALL["index"].tolist():
        if row not in missing_RAINFALL_rows:
            # print("Warning: row " + row + " is not in table RAINFALL, return 0.0")
            missing_RAINFALL_rows.append(row)
        return 0.0
    if col not in df_RAINFALL.columns:
        if col not in missing_RAINFALL_cols:
            # print("Warning: column " + col + " is not in table RAINFALL, return 0.0")
            missing_RAINFALL_cols.append(col)
        return 0.0
    value = df_RAINFALL[col][df_RAINFALL["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_RAINFALL[col][df_RAINFALL["index"].tolist().index(row)]
def table_RAINFALL_1(XC, PT, R):
    if R == "ASWAN":
        return (0.9 * table_RAINFALL_0(XC, PT, "ASWAN"))
    else:
        return table_RAINFALL_0(XC, PT, R)

def table_RAINFALL_2(XC, PT, R):
    if R == "FAYOUM":
        return (0.9 * table_RAINFALL_1(XC, PT, "FAYOUM"))
    else:
        return table_RAINFALL_1(XC, PT, R)

def table_RAINFALL_3(XC, PT, R):
    if R == "DAKHLIA":
        return (0.9 * table_RAINFALL_2(XC, PT, "DAKHLIA"))
    else:
        return table_RAINFALL_2(XC, PT, R)

def table_RAINFALL_4(XC, PT, R):
    if R == "ALEX":
        return table_RAINFALL_3(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_3(XC, PT, R)

def table_RAINFALL_5(XC, PT, R):
    if R == "BEHAIRA":
        return table_RAINFALL_4(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_4(XC, PT, R)

def table_RAINFALL_6(XC, PT, R):
    if R == "GHARBIA":
        return table_RAINFALL_5(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_5(XC, PT, R)

def table_RAINFALL_7(XC, PT, R):
    if R == "KFRSHIK":
        return table_RAINFALL_6(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_6(XC, PT, R)

def table_RAINFALL_8(XC, PT, R):
    if R == "DAMIETA":
        return table_RAINFALL_7(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_7(XC, PT, R)

def table_RAINFALL_9(XC, PT, R):
    if R == "SHARKIA":
        return table_RAINFALL_8(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_8(XC, PT, R)

def table_RAINFALL_10(XC, PT, R):
    if R == "ISMALIA":
        return table_RAINFALL_9(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_9(XC, PT, R)

def table_RAINFALL_11(XC, PT, R):
    if R == "PRTSAID":
        return table_RAINFALL_10(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_10(XC, PT, R)

def table_RAINFALL_12(XC, PT, R):
    if R == "SUEZ":
        return table_RAINFALL_11(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_11(XC, PT, R)

def table_RAINFALL_13(XC, PT, R):
    if R == "MENUFIA":
        return table_RAINFALL_12(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_12(XC, PT, R)

def table_RAINFALL_14(XC, PT, R):
    if R == "QLYUBIA":
        return table_RAINFALL_13(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_13(XC, PT, R)

def table_RAINFALL_15(XC, PT, R):
    if R == "CAIRO":
        return table_RAINFALL_14(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_14(XC, PT, R)

def table_RAINFALL_16(XC, PT, R):
    if R == "MATRUH":
        return table_RAINFALL_15(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_15(XC, PT, R)

def table_RAINFALL_17(XC, PT, R):
    if R == "REDSEA":
        return table_RAINFALL_16(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_16(XC, PT, R)

def table_RAINFALL_18(XC, PT, R):
    if R == "NSINAI":
        return table_RAINFALL_17(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_17(XC, PT, R)

def table_RAINFALL_19(XC, PT, R):
    if R == "SSINAI":
        return table_RAINFALL_18(XC, PT, "DAKHLIA")
    else:
        return table_RAINFALL_18(XC, PT, R)

def table_RAINFALL_20(XC, PT, R):
    if R == "GIZA":
        return table_RAINFALL_19(XC, PT, "FAYOUM")
    else:
        return table_RAINFALL_19(XC, PT, R)

def table_RAINFALL_21(XC, PT, R):
    if R == "BNISUEF":
        return table_RAINFALL_20(XC, PT, "FAYOUM")
    else:
        return table_RAINFALL_20(XC, PT, R)

def table_RAINFALL_22(XC, PT, R):
    if R == "MENIA":
        return table_RAINFALL_21(XC, PT, "FAYOUM")
    else:
        return table_RAINFALL_21(XC, PT, R)

def table_RAINFALL_23(XC, PT, R):
    if R == "ASSUIT":
        return table_RAINFALL_22(XC, PT, "ASWAN")
    else:
        return table_RAINFALL_22(XC, PT, R)

def table_RAINFALL_24(XC, PT, R):
    if R == "SUHAG":
        return table_RAINFALL_23(XC, PT, "ASWAN")
    else:
        return table_RAINFALL_23(XC, PT, R)

def table_RAINFALL_25(XC, PT, R):
    if R == "QENA":
        return table_RAINFALL_24(XC, PT, "ASWAN")
    else:
        return table_RAINFALL_24(XC, PT, R)

def table_RAINFALL_26(XC, PT, R):
    if R == "LUXOR":
        return table_RAINFALL_25(XC, PT, "ASWAN")
    else:
        return table_RAINFALL_25(XC, PT, R)

def table_RAINFALL_27(XC, PT, R):
    if R == "NVALLEY":
        return table_RAINFALL_26(XC, PT, "ASWAN")
    else:
        return table_RAINFALL_26(XC, PT, R)

def table_RAINFALL_28(XC, PT, R):
    if R == "TOSHKA":
        return table_RAINFALL_27(XC, PT, "ASWAN")
    else:
        return table_RAINFALL_27(XC, PT, R)

def table_RAINFALL(XC, PT, R):
    return table_RAINFALL_28(XC, PT, R)

# Table: fallow land evaporation (m3 p feddan)

df_FALET = pd.read_excel("tables/FALET.xlsx")
for col in df_FALET.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table FALET is a float, cast it to an int before casting it to a str, rename it.")
            df_FALET.rename(columns={col: int(col)}, inplace=True)
df_FALET.columns = df_FALET.columns.astype(str)

missing_FALET_rows = []
missing_FALET_cols = []

def table_FALET_0(R, TM):
    col = TM
    row = R
    if row not in df_FALET["index"].tolist():
        if row not in missing_FALET_rows:
            # print("Warning: row " + row + " is not in table FALET, return 0.0")
            missing_FALET_rows.append(row)
        return 0.0
    if col not in df_FALET.columns:
        if col not in missing_FALET_cols:
            # print("Warning: column " + col + " is not in table FALET, return 0.0")
            missing_FALET_cols.append(col)
        return 0.0
    value = df_FALET[col][df_FALET["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_FALET[col][df_FALET["index"].tolist().index(row)]
def table_FALET_1(R, TM):
    if R == "ALEX":
        return table_FALET_0("ASWAN", TM)
    else:
        return table_FALET_0(R, TM)

def table_FALET_2(R, TM):
    if R == "BEHAIRA":
        return table_FALET_1("ASWAN", TM)
    else:
        return table_FALET_1(R, TM)

def table_FALET_3(R, TM):
    if R == "GHARBIA":
        return table_FALET_2("ASWAN", TM)
    else:
        return table_FALET_2(R, TM)

def table_FALET_4(R, TM):
    if R == "KFRSHIK":
        return table_FALET_3("ASWAN", TM)
    else:
        return table_FALET_3(R, TM)

def table_FALET_5(R, TM):
    if R == "DAMIETA":
        return table_FALET_4("ASWAN", TM)
    else:
        return table_FALET_4(R, TM)

def table_FALET_6(R, TM):
    if R == "SHARKIA":
        return table_FALET_5("ASWAN", TM)
    else:
        return table_FALET_5(R, TM)

def table_FALET_7(R, TM):
    if R == "ISMALIA":
        return table_FALET_6("ASWAN", TM)
    else:
        return table_FALET_6(R, TM)

def table_FALET_8(R, TM):
    if R == "PRTSAID":
        return table_FALET_7("ASWAN", TM)
    else:
        return table_FALET_7(R, TM)

def table_FALET_9(R, TM):
    if R == "SUEZ":
        return table_FALET_8("ASWAN", TM)
    else:
        return table_FALET_8(R, TM)

def table_FALET_10(R, TM):
    if R == "MENUFIA":
        return table_FALET_9("ASWAN", TM)
    else:
        return table_FALET_9(R, TM)

def table_FALET_11(R, TM):
    if R == "QLYUBIA":
        return table_FALET_10("ASWAN", TM)
    else:
        return table_FALET_10(R, TM)

def table_FALET_12(R, TM):
    if R == "CAIRO":
        return table_FALET_11("ASWAN", TM)
    else:
        return table_FALET_11(R, TM)

def table_FALET_13(R, TM):
    if R == "MATRUH":
        return table_FALET_12("ASWAN", TM)
    else:
        return table_FALET_12(R, TM)

def table_FALET_14(R, TM):
    if R == "REDSEA":
        return table_FALET_13("ASWAN", TM)
    else:
        return table_FALET_13(R, TM)

def table_FALET_15(R, TM):
    if R == "NSINAI":
        return table_FALET_14("ASWAN", TM)
    else:
        return table_FALET_14(R, TM)

def table_FALET_16(R, TM):
    if R == "SSINAI":
        return table_FALET_15("ASWAN", TM)
    else:
        return table_FALET_15(R, TM)

def table_FALET_17(R, TM):
    if R == "GIZA":
        return table_FALET_16("ASWAN", TM)
    else:
        return table_FALET_16(R, TM)

def table_FALET_18(R, TM):
    if R == "BNISUEF":
        return table_FALET_17("ASWAN", TM)
    else:
        return table_FALET_17(R, TM)

def table_FALET_19(R, TM):
    if R == "MENIA":
        return table_FALET_18("ASWAN", TM)
    else:
        return table_FALET_18(R, TM)

def table_FALET_20(R, TM):
    if R == "ASSUIT":
        return table_FALET_19("ASWAN", TM)
    else:
        return table_FALET_19(R, TM)

def table_FALET_21(R, TM):
    if R == "SUHAG":
        return table_FALET_20("ASWAN", TM)
    else:
        return table_FALET_20(R, TM)

def table_FALET_22(R, TM):
    if R == "QENA":
        return table_FALET_21("ASWAN", TM)
    else:
        return table_FALET_21(R, TM)

def table_FALET_23(R, TM):
    if R == "LUXOR":
        return table_FALET_22("ASWAN", TM)
    else:
        return table_FALET_22(R, TM)

def table_FALET_24(R, TM):
    if R == "NVALLEY":
        return table_FALET_23("ASWAN", TM)
    else:
        return table_FALET_23(R, TM)

def table_FALET_25(R, TM):
    if R == "TOSHKA":
        return table_FALET_24("ASWAN", TM)
    else:
        return table_FALET_24(R, TM)

def table_FALET(R, TM):
    return table_FALET_25(R, TM)

# Table: crop yields at 2013-14 level (t p fed)

df_YIELD = pd.read_excel("tables/YIELD.xlsx")
for col in df_YIELD.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table YIELD is a float, cast it to an int before casting it to a str, rename it.")
            df_YIELD.rename(columns={col: int(col)}, inplace=True)
df_YIELD.columns = df_YIELD.columns.astype(str)

missing_YIELD_rows = []
missing_YIELD_cols = []

def table_YIELD_0(XC, C, R):
    col = R
    row = XC + "." + C
    if row not in df_YIELD["index"].tolist():
        if row not in missing_YIELD_rows:
            # print("Warning: row " + row + " is not in table YIELD, return 0.0")
            missing_YIELD_rows.append(row)
        return 0.0
    if col not in df_YIELD.columns:
        if col not in missing_YIELD_cols:
            # print("Warning: column " + col + " is not in table YIELD, return 0.0")
            missing_YIELD_cols.append(col)
        return 0.0
    value = df_YIELD[col][df_YIELD["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_YIELD[col][df_YIELD["index"].tolist().index(row)]
def table_YIELD(XC, C, R):
    return table_YIELD_0(XC, C, R)

# Table: yield increase in 2015-30 compared to 2013-14 (factor)

df_YLDINC = pd.read_excel("tables/YLDINC.xlsx")
for col in df_YLDINC.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table YLDINC is a float, cast it to an int before casting it to a str, rename it.")
            df_YLDINC.rename(columns={col: int(col)}, inplace=True)
df_YLDINC.columns = df_YLDINC.columns.astype(str)

missing_YLDINC_rows = []
missing_YLDINC_cols = []

def table_YLDINC_0(XC, C, IMP_YLDINC_2):
    col = IMP_YLDINC_2
    row = XC + "." + C
    if row not in df_YLDINC["index"].tolist():
        if row not in missing_YLDINC_rows:
            # print("Warning: row " + row + " is not in table YLDINC, return 0.0")
            missing_YLDINC_rows.append(row)
        return 0.0
    if col not in df_YLDINC.columns:
        if col not in missing_YLDINC_cols:
            # print("Warning: column " + col + " is not in table YLDINC, return 0.0")
            missing_YLDINC_cols.append(col)
        return 0.0
    value = df_YLDINC[col][df_YLDINC["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_YLDINC[col][df_YLDINC["index"].tolist().index(row)]
def table_YLDINC_1(XC, C, IMP_YLDINC_2):
    if XC == "BARLEY1" and C == "BARLEYSTR" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_0("BARLEY1", "BARLEY", "2015")
    else:
        return table_YLDINC_0(XC, C, IMP_YLDINC_2)

def table_YLDINC_2(XC, C, IMP_YLDINC_2):
    if XC == "FBEAN1" and C == "FBEANFOD" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_1("FBEAN1", "FBEAN", "2015")
    else:
        return table_YLDINC_1(XC, C, IMP_YLDINC_2)

def table_YLDINC_3(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GRDNUTFOD" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_2("GNUT1", "GRDNUT", "2015")
    else:
        return table_YLDINC_2(XC, C, IMP_YLDINC_2)

def table_YLDINC_4(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GNUTSH" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_3("GNUT1", "GRDNUT", "2015")
    else:
        return table_YLDINC_3(XC, C, IMP_YLDINC_2)

def table_YLDINC_5(XC, C, IMP_YLDINC_2):
    if XC == "LENTIL1" and C == "LENTILFOD" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_4("LENTIL1", "LENTIL", "2015")
    else:
        return table_YLDINC_4(XC, C, IMP_YLDINC_2)

def table_YLDINC_6(XC, C, IMP_YLDINC_2):
    if XC == "MAIZEN1" and C == "MAIZESTA" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_5("MAIZEN1", "MAIZE", "2015")
    else:
        return table_YLDINC_5(XC, C, IMP_YLDINC_2)

def table_YLDINC_7(XC, C, IMP_YLDINC_2):
    if XC == "MAIZES1" and C == "MAIZESTA" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_6("MAIZES1", "MAIZE", "2015")
    else:
        return table_YLDINC_6(XC, C, IMP_YLDINC_2)

def table_YLDINC_8(XC, C, IMP_YLDINC_2):
    if XC == "VEGETS1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_7("VEGETS1", "VEGET", "2015")
    else:
        return table_YLDINC_7(XC, C, IMP_YLDINC_2)

def table_YLDINC_9(XC, C, IMP_YLDINC_2):
    if XC == "VEGETW1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_8("VEGETW1", "VEGET", "2015")
    else:
        return table_YLDINC_8(XC, C, IMP_YLDINC_2)

def table_YLDINC_10(XC, C, IMP_YLDINC_2):
    if XC == "VEGETN1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_9("VEGETN1", "VEGET", "2015")
    else:
        return table_YLDINC_9(XC, C, IMP_YLDINC_2)

def table_YLDINC_11(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "RICESTR" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_10("PADDY1", "PADDY", "2015")
    else:
        return table_YLDINC_10(XC, C, IMP_YLDINC_2)

def table_YLDINC_12(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "BRAN" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_11("PADDY1", "PADDY", "2015")
    else:
        return table_YLDINC_11(XC, C, IMP_YLDINC_2)

def table_YLDINC_13(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "HUSK" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_12("PADDY1", "PADDY", "2015")
    else:
        return table_YLDINC_12(XC, C, IMP_YLDINC_2)

def table_YLDINC_14(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETFOD" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_13("SBEET1", "SGBEET", "2015")
    else:
        return table_YLDINC_13(XC, C, IMP_YLDINC_2)

def table_YLDINC_15(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SCANEFOD" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_14("SCANE1", "SGCANE", "2015")
    else:
        return table_YLDINC_14(XC, C, IMP_YLDINC_2)

def table_YLDINC_16(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "SOYAFOD" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_15("SBEAN1", "SOYBEAN", "2015")
    else:
        return table_YLDINC_15(XC, C, IMP_YLDINC_2)

def table_YLDINC_17(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "WHEATSTR" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_16("WHEAT1", "WHEAT", "2015")
    else:
        return table_YLDINC_16(XC, C, IMP_YLDINC_2)

def table_YLDINC_18(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "FXFIB" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_17("FLAX1", "FLAX", "2015")
    else:
        return table_YLDINC_17(XC, C, IMP_YLDINC_2)

def table_YLDINC_19(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "FLSECAKE" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_18("FLAX1", "FLAX", "2015")
    else:
        return table_YLDINC_18(XC, C, IMP_YLDINC_2)

def table_YLDINC_20(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_19("FLAX1", "FLAX", "2015")
    else:
        return table_YLDINC_19(XC, C, IMP_YLDINC_2)

def table_YLDINC_21(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GNUTCAKE" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_20("GNUT1", "GRDNUT", "2015")
    else:
        return table_YLDINC_20(XC, C, IMP_YLDINC_2)

def table_YLDINC_22(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_21("GNUT1", "GRDNUT", "2015")
    else:
        return table_YLDINC_21(XC, C, IMP_YLDINC_2)

def table_YLDINC_23(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "RICE" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_22("PADDY1", "PADDY", "2015")
    else:
        return table_YLDINC_22(XC, C, IMP_YLDINC_2)

def table_YLDINC_24(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "BRAN" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_23("PADDY1", "PADDY", "2015")
    else:
        return table_YLDINC_23(XC, C, IMP_YLDINC_2)

def table_YLDINC_25(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_24("SDLS1", "SEEDLS", "2015")
    else:
        return table_YLDINC_24(XC, C, IMP_YLDINC_2)

def table_YLDINC_26(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "CTONLS" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_25("SDLS1", "SEEDLS", "2015")
    else:
        return table_YLDINC_25(XC, C, IMP_YLDINC_2)

def table_YLDINC_27(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "COTSCAKE" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_26("SDLS1", "SEEDLS", "2015")
    else:
        return table_YLDINC_26(XC, C, IMP_YLDINC_2)

def table_YLDINC_28(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "COTSTA" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_27("SDLS1", "SEEDLS", "2015")
    else:
        return table_YLDINC_27(XC, C, IMP_YLDINC_2)

def table_YLDINC_29(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_28("SDELS1", "SEEDELS", "2015")
    else:
        return table_YLDINC_28(XC, C, IMP_YLDINC_2)

def table_YLDINC_30(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "CTONELS" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_29("SDELS1", "SEEDELS", "2015")
    else:
        return table_YLDINC_29(XC, C, IMP_YLDINC_2)

def table_YLDINC_31(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "COTSCAKE" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_30("SDELS1", "SEEDELS", "2015")
    else:
        return table_YLDINC_30(XC, C, IMP_YLDINC_2)

def table_YLDINC_32(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "COTSTA" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_31("SDELS1", "SEEDELS", "2015")
    else:
        return table_YLDINC_31(XC, C, IMP_YLDINC_2)

def table_YLDINC_33(XC, C, IMP_YLDINC_2):
    if XC == "SESAME1" and C == "FLSECAKE" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_32("SESAME1", "SESAME", "2015")
    else:
        return table_YLDINC_32(XC, C, IMP_YLDINC_2)

def table_YLDINC_34(XC, C, IMP_YLDINC_2):
    if XC == "SESAME1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_33("SESAME1", "SESAME", "2015")
    else:
        return table_YLDINC_33(XC, C, IMP_YLDINC_2)

def table_YLDINC_35(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SUGAR" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_34("SBEET1", "SGBEET", "2015")
    else:
        return table_YLDINC_34(XC, C, IMP_YLDINC_2)

def table_YLDINC_36(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETMOL" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_35("SBEET1", "SGBEET", "2015")
    else:
        return table_YLDINC_35(XC, C, IMP_YLDINC_2)

def table_YLDINC_37(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETPULP" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_36("SBEET1", "SGBEET", "2015")
    else:
        return table_YLDINC_36(XC, C, IMP_YLDINC_2)

def table_YLDINC_38(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SUGAR" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_37("SCANE1", "SGCANE", "2015")
    else:
        return table_YLDINC_37(XC, C, IMP_YLDINC_2)

def table_YLDINC_39(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SCANEMOL" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_38("SCANE1", "SGCANE", "2015")
    else:
        return table_YLDINC_38(XC, C, IMP_YLDINC_2)

def table_YLDINC_40(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "SOYACAKE" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_39("SBEAN1", "SOYBEAN", "2015")
    else:
        return table_YLDINC_39(XC, C, IMP_YLDINC_2)

def table_YLDINC_41(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_40("SBEAN1", "SOYBEAN", "2015")
    else:
        return table_YLDINC_40(XC, C, IMP_YLDINC_2)

def table_YLDINC_42(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "WHEATF" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_41("WHEAT1", "WHEAT", "2015")
    else:
        return table_YLDINC_41(XC, C, IMP_YLDINC_2)

def table_YLDINC_43(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "BRAN" and IMP_YLDINC_2 == "2015":
        return table_YLDINC_42("WHEAT1", "WHEAT", "2015")
    else:
        return table_YLDINC_42(XC, C, IMP_YLDINC_2)

def table_YLDINC_44(XC, C, IMP_YLDINC_2):
    if XC == "BARLEY1" and C == "BARLEYSTR" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_43("BARLEY1", "BARLEY", "2017")
    else:
        return table_YLDINC_43(XC, C, IMP_YLDINC_2)

def table_YLDINC_45(XC, C, IMP_YLDINC_2):
    if XC == "FBEAN1" and C == "FBEANFOD" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_44("FBEAN1", "FBEAN", "2017")
    else:
        return table_YLDINC_44(XC, C, IMP_YLDINC_2)

def table_YLDINC_46(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GRDNUTFOD" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_45("GNUT1", "GRDNUT", "2017")
    else:
        return table_YLDINC_45(XC, C, IMP_YLDINC_2)

def table_YLDINC_47(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GNUTSH" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_46("GNUT1", "GRDNUT", "2017")
    else:
        return table_YLDINC_46(XC, C, IMP_YLDINC_2)

def table_YLDINC_48(XC, C, IMP_YLDINC_2):
    if XC == "LENTIL1" and C == "LENTILFOD" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_47("LENTIL1", "LENTIL", "2017")
    else:
        return table_YLDINC_47(XC, C, IMP_YLDINC_2)

def table_YLDINC_49(XC, C, IMP_YLDINC_2):
    if XC == "MAIZEN1" and C == "MAIZESTA" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_48("MAIZEN1", "MAIZE", "2017")
    else:
        return table_YLDINC_48(XC, C, IMP_YLDINC_2)

def table_YLDINC_50(XC, C, IMP_YLDINC_2):
    if XC == "MAIZES1" and C == "MAIZESTA" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_49("MAIZES1", "MAIZE", "2017")
    else:
        return table_YLDINC_49(XC, C, IMP_YLDINC_2)

def table_YLDINC_51(XC, C, IMP_YLDINC_2):
    if XC == "VEGETS1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_50("VEGETS1", "VEGET", "2017")
    else:
        return table_YLDINC_50(XC, C, IMP_YLDINC_2)

def table_YLDINC_52(XC, C, IMP_YLDINC_2):
    if XC == "VEGETW1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_51("VEGETW1", "VEGET", "2017")
    else:
        return table_YLDINC_51(XC, C, IMP_YLDINC_2)

def table_YLDINC_53(XC, C, IMP_YLDINC_2):
    if XC == "VEGETN1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_52("VEGETN1", "VEGET", "2017")
    else:
        return table_YLDINC_52(XC, C, IMP_YLDINC_2)

def table_YLDINC_54(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "RICESTR" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_53("PADDY1", "PADDY", "2017")
    else:
        return table_YLDINC_53(XC, C, IMP_YLDINC_2)

def table_YLDINC_55(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "BRAN" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_54("PADDY1", "PADDY", "2017")
    else:
        return table_YLDINC_54(XC, C, IMP_YLDINC_2)

def table_YLDINC_56(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "HUSK" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_55("PADDY1", "PADDY", "2017")
    else:
        return table_YLDINC_55(XC, C, IMP_YLDINC_2)

def table_YLDINC_57(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETFOD" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_56("SBEET1", "SGBEET", "2017")
    else:
        return table_YLDINC_56(XC, C, IMP_YLDINC_2)

def table_YLDINC_58(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SCANEFOD" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_57("SCANE1", "SGCANE", "2017")
    else:
        return table_YLDINC_57(XC, C, IMP_YLDINC_2)

def table_YLDINC_59(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "SOYAFOD" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_58("SBEAN1", "SOYBEAN", "2017")
    else:
        return table_YLDINC_58(XC, C, IMP_YLDINC_2)

def table_YLDINC_60(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "WHEATSTR" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_59("WHEAT1", "WHEAT", "2017")
    else:
        return table_YLDINC_59(XC, C, IMP_YLDINC_2)

def table_YLDINC_61(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "FXFIB" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_60("FLAX1", "FLAX", "2017")
    else:
        return table_YLDINC_60(XC, C, IMP_YLDINC_2)

def table_YLDINC_62(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "FLSECAKE" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_61("FLAX1", "FLAX", "2017")
    else:
        return table_YLDINC_61(XC, C, IMP_YLDINC_2)

def table_YLDINC_63(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_62("FLAX1", "FLAX", "2017")
    else:
        return table_YLDINC_62(XC, C, IMP_YLDINC_2)

def table_YLDINC_64(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GNUTCAKE" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_63("GNUT1", "GRDNUT", "2017")
    else:
        return table_YLDINC_63(XC, C, IMP_YLDINC_2)

def table_YLDINC_65(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_64("GNUT1", "GRDNUT", "2017")
    else:
        return table_YLDINC_64(XC, C, IMP_YLDINC_2)

def table_YLDINC_66(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "RICE" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_65("PADDY1", "PADDY", "2017")
    else:
        return table_YLDINC_65(XC, C, IMP_YLDINC_2)

def table_YLDINC_67(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "BRAN" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_66("PADDY1", "PADDY", "2017")
    else:
        return table_YLDINC_66(XC, C, IMP_YLDINC_2)

def table_YLDINC_68(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_67("SDLS1", "SEEDLS", "2017")
    else:
        return table_YLDINC_67(XC, C, IMP_YLDINC_2)

def table_YLDINC_69(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "CTONLS" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_68("SDLS1", "SEEDLS", "2017")
    else:
        return table_YLDINC_68(XC, C, IMP_YLDINC_2)

def table_YLDINC_70(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "COTSCAKE" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_69("SDLS1", "SEEDLS", "2017")
    else:
        return table_YLDINC_69(XC, C, IMP_YLDINC_2)

def table_YLDINC_71(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "COTSTA" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_70("SDLS1", "SEEDLS", "2017")
    else:
        return table_YLDINC_70(XC, C, IMP_YLDINC_2)

def table_YLDINC_72(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_71("SDELS1", "SEEDELS", "2017")
    else:
        return table_YLDINC_71(XC, C, IMP_YLDINC_2)

def table_YLDINC_73(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "CTONELS" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_72("SDELS1", "SEEDELS", "2017")
    else:
        return table_YLDINC_72(XC, C, IMP_YLDINC_2)

def table_YLDINC_74(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "COTSCAKE" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_73("SDELS1", "SEEDELS", "2017")
    else:
        return table_YLDINC_73(XC, C, IMP_YLDINC_2)

def table_YLDINC_75(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "COTSTA" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_74("SDELS1", "SEEDELS", "2017")
    else:
        return table_YLDINC_74(XC, C, IMP_YLDINC_2)

def table_YLDINC_76(XC, C, IMP_YLDINC_2):
    if XC == "SESAME1" and C == "FLSECAKE" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_75("SESAME1", "SESAME", "2017")
    else:
        return table_YLDINC_75(XC, C, IMP_YLDINC_2)

def table_YLDINC_77(XC, C, IMP_YLDINC_2):
    if XC == "SESAME1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_76("SESAME1", "SESAME", "2017")
    else:
        return table_YLDINC_76(XC, C, IMP_YLDINC_2)

def table_YLDINC_78(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SUGAR" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_77("SBEET1", "SGBEET", "2017")
    else:
        return table_YLDINC_77(XC, C, IMP_YLDINC_2)

def table_YLDINC_79(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETMOL" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_78("SBEET1", "SGBEET", "2017")
    else:
        return table_YLDINC_78(XC, C, IMP_YLDINC_2)

def table_YLDINC_80(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETPULP" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_79("SBEET1", "SGBEET", "2017")
    else:
        return table_YLDINC_79(XC, C, IMP_YLDINC_2)

def table_YLDINC_81(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SUGAR" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_80("SCANE1", "SGCANE", "2017")
    else:
        return table_YLDINC_80(XC, C, IMP_YLDINC_2)

def table_YLDINC_82(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SCANEMOL" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_81("SCANE1", "SGCANE", "2017")
    else:
        return table_YLDINC_81(XC, C, IMP_YLDINC_2)

def table_YLDINC_83(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "SOYACAKE" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_82("SBEAN1", "SOYBEAN", "2017")
    else:
        return table_YLDINC_82(XC, C, IMP_YLDINC_2)

def table_YLDINC_84(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_83("SBEAN1", "SOYBEAN", "2017")
    else:
        return table_YLDINC_83(XC, C, IMP_YLDINC_2)

def table_YLDINC_85(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "WHEATF" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_84("WHEAT1", "WHEAT", "2017")
    else:
        return table_YLDINC_84(XC, C, IMP_YLDINC_2)

def table_YLDINC_86(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "BRAN" and IMP_YLDINC_2 == "2017":
        return table_YLDINC_85("WHEAT1", "WHEAT", "2017")
    else:
        return table_YLDINC_85(XC, C, IMP_YLDINC_2)

def table_YLDINC_87(XC, C, IMP_YLDINC_2):
    if XC == "BARLEY1" and C == "BARLEYSTR" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_86("BARLEY1", "BARLEY", "2020")
    else:
        return table_YLDINC_86(XC, C, IMP_YLDINC_2)

def table_YLDINC_88(XC, C, IMP_YLDINC_2):
    if XC == "FBEAN1" and C == "FBEANFOD" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_87("FBEAN1", "FBEAN", "2020")
    else:
        return table_YLDINC_87(XC, C, IMP_YLDINC_2)

def table_YLDINC_89(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GRDNUTFOD" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_88("GNUT1", "GRDNUT", "2020")
    else:
        return table_YLDINC_88(XC, C, IMP_YLDINC_2)

def table_YLDINC_90(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GNUTSH" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_89("GNUT1", "GRDNUT", "2020")
    else:
        return table_YLDINC_89(XC, C, IMP_YLDINC_2)

def table_YLDINC_91(XC, C, IMP_YLDINC_2):
    if XC == "LENTIL1" and C == "LENTILFOD" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_90("LENTIL1", "LENTIL", "2020")
    else:
        return table_YLDINC_90(XC, C, IMP_YLDINC_2)

def table_YLDINC_92(XC, C, IMP_YLDINC_2):
    if XC == "MAIZEN1" and C == "MAIZESTA" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_91("MAIZEN1", "MAIZE", "2020")
    else:
        return table_YLDINC_91(XC, C, IMP_YLDINC_2)

def table_YLDINC_93(XC, C, IMP_YLDINC_2):
    if XC == "MAIZES1" and C == "MAIZESTA" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_92("MAIZES1", "MAIZE", "2020")
    else:
        return table_YLDINC_92(XC, C, IMP_YLDINC_2)

def table_YLDINC_94(XC, C, IMP_YLDINC_2):
    if XC == "VEGETS1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_93("VEGETS1", "VEGET", "2020")
    else:
        return table_YLDINC_93(XC, C, IMP_YLDINC_2)

def table_YLDINC_95(XC, C, IMP_YLDINC_2):
    if XC == "VEGETW1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_94("VEGETW1", "VEGET", "2020")
    else:
        return table_YLDINC_94(XC, C, IMP_YLDINC_2)

def table_YLDINC_96(XC, C, IMP_YLDINC_2):
    if XC == "VEGETN1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_95("VEGETN1", "VEGET", "2020")
    else:
        return table_YLDINC_95(XC, C, IMP_YLDINC_2)

def table_YLDINC_97(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "RICESTR" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_96("PADDY1", "PADDY", "2020")
    else:
        return table_YLDINC_96(XC, C, IMP_YLDINC_2)

def table_YLDINC_98(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "BRAN" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_97("PADDY1", "PADDY", "2020")
    else:
        return table_YLDINC_97(XC, C, IMP_YLDINC_2)

def table_YLDINC_99(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "HUSK" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_98("PADDY1", "PADDY", "2020")
    else:
        return table_YLDINC_98(XC, C, IMP_YLDINC_2)

def table_YLDINC_100(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETFOD" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_99("SBEET1", "SGBEET", "2020")
    else:
        return table_YLDINC_99(XC, C, IMP_YLDINC_2)

def table_YLDINC_101(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SCANEFOD" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_100("SCANE1", "SGCANE", "2020")
    else:
        return table_YLDINC_100(XC, C, IMP_YLDINC_2)

def table_YLDINC_102(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "SOYAFOD" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_101("SBEAN1", "SOYBEAN", "2020")
    else:
        return table_YLDINC_101(XC, C, IMP_YLDINC_2)

def table_YLDINC_103(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "WHEATSTR" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_102("WHEAT1", "WHEAT", "2020")
    else:
        return table_YLDINC_102(XC, C, IMP_YLDINC_2)

def table_YLDINC_104(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "FXFIB" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_103("FLAX1", "FLAX", "2020")
    else:
        return table_YLDINC_103(XC, C, IMP_YLDINC_2)

def table_YLDINC_105(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "FLSECAKE" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_104("FLAX1", "FLAX", "2020")
    else:
        return table_YLDINC_104(XC, C, IMP_YLDINC_2)

def table_YLDINC_106(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_105("FLAX1", "FLAX", "2020")
    else:
        return table_YLDINC_105(XC, C, IMP_YLDINC_2)

def table_YLDINC_107(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GNUTCAKE" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_106("GNUT1", "GRDNUT", "2020")
    else:
        return table_YLDINC_106(XC, C, IMP_YLDINC_2)

def table_YLDINC_108(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_107("GNUT1", "GRDNUT", "2020")
    else:
        return table_YLDINC_107(XC, C, IMP_YLDINC_2)

def table_YLDINC_109(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "RICE" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_108("PADDY1", "PADDY", "2020")
    else:
        return table_YLDINC_108(XC, C, IMP_YLDINC_2)

def table_YLDINC_110(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "BRAN" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_109("PADDY1", "PADDY", "2020")
    else:
        return table_YLDINC_109(XC, C, IMP_YLDINC_2)

def table_YLDINC_111(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_110("SDLS1", "SEEDLS", "2020")
    else:
        return table_YLDINC_110(XC, C, IMP_YLDINC_2)

def table_YLDINC_112(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "CTONLS" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_111("SDLS1", "SEEDLS", "2020")
    else:
        return table_YLDINC_111(XC, C, IMP_YLDINC_2)

def table_YLDINC_113(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "COTSCAKE" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_112("SDLS1", "SEEDLS", "2020")
    else:
        return table_YLDINC_112(XC, C, IMP_YLDINC_2)

def table_YLDINC_114(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "COTSTA" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_113("SDLS1", "SEEDLS", "2020")
    else:
        return table_YLDINC_113(XC, C, IMP_YLDINC_2)

def table_YLDINC_115(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_114("SDELS1", "SEEDELS", "2020")
    else:
        return table_YLDINC_114(XC, C, IMP_YLDINC_2)

def table_YLDINC_116(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "CTONELS" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_115("SDELS1", "SEEDELS", "2020")
    else:
        return table_YLDINC_115(XC, C, IMP_YLDINC_2)

def table_YLDINC_117(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "COTSCAKE" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_116("SDELS1", "SEEDELS", "2020")
    else:
        return table_YLDINC_116(XC, C, IMP_YLDINC_2)

def table_YLDINC_118(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "COTSTA" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_117("SDELS1", "SEEDELS", "2020")
    else:
        return table_YLDINC_117(XC, C, IMP_YLDINC_2)

def table_YLDINC_119(XC, C, IMP_YLDINC_2):
    if XC == "SESAME1" and C == "FLSECAKE" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_118("SESAME1", "SESAME", "2020")
    else:
        return table_YLDINC_118(XC, C, IMP_YLDINC_2)

def table_YLDINC_120(XC, C, IMP_YLDINC_2):
    if XC == "SESAME1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_119("SESAME1", "SESAME", "2020")
    else:
        return table_YLDINC_119(XC, C, IMP_YLDINC_2)

def table_YLDINC_121(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SUGAR" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_120("SBEET1", "SGBEET", "2020")
    else:
        return table_YLDINC_120(XC, C, IMP_YLDINC_2)

def table_YLDINC_122(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETMOL" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_121("SBEET1", "SGBEET", "2020")
    else:
        return table_YLDINC_121(XC, C, IMP_YLDINC_2)

def table_YLDINC_123(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETPULP" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_122("SBEET1", "SGBEET", "2020")
    else:
        return table_YLDINC_122(XC, C, IMP_YLDINC_2)

def table_YLDINC_124(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SUGAR" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_123("SCANE1", "SGCANE", "2020")
    else:
        return table_YLDINC_123(XC, C, IMP_YLDINC_2)

def table_YLDINC_125(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SCANEMOL" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_124("SCANE1", "SGCANE", "2020")
    else:
        return table_YLDINC_124(XC, C, IMP_YLDINC_2)

def table_YLDINC_126(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "SOYACAKE" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_125("SBEAN1", "SOYBEAN", "2020")
    else:
        return table_YLDINC_125(XC, C, IMP_YLDINC_2)

def table_YLDINC_127(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_126("SBEAN1", "SOYBEAN", "2020")
    else:
        return table_YLDINC_126(XC, C, IMP_YLDINC_2)

def table_YLDINC_128(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "WHEATF" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_127("WHEAT1", "WHEAT", "2020")
    else:
        return table_YLDINC_127(XC, C, IMP_YLDINC_2)

def table_YLDINC_129(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "BRAN" and IMP_YLDINC_2 == "2020":
        return table_YLDINC_128("WHEAT1", "WHEAT", "2020")
    else:
        return table_YLDINC_128(XC, C, IMP_YLDINC_2)

def table_YLDINC_130(XC, C, IMP_YLDINC_2):
    if XC == "BARLEY1" and C == "BARLEYSTR" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_129("BARLEY1", "BARLEY", "2025")
    else:
        return table_YLDINC_129(XC, C, IMP_YLDINC_2)

def table_YLDINC_131(XC, C, IMP_YLDINC_2):
    if XC == "FBEAN1" and C == "FBEANFOD" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_130("FBEAN1", "FBEAN", "2025")
    else:
        return table_YLDINC_130(XC, C, IMP_YLDINC_2)

def table_YLDINC_132(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GRDNUTFOD" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_131("GNUT1", "GRDNUT", "2025")
    else:
        return table_YLDINC_131(XC, C, IMP_YLDINC_2)

def table_YLDINC_133(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GNUTSH" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_132("GNUT1", "GRDNUT", "2025")
    else:
        return table_YLDINC_132(XC, C, IMP_YLDINC_2)

def table_YLDINC_134(XC, C, IMP_YLDINC_2):
    if XC == "LENTIL1" and C == "LENTILFOD" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_133("LENTIL1", "LENTIL", "2025")
    else:
        return table_YLDINC_133(XC, C, IMP_YLDINC_2)

def table_YLDINC_135(XC, C, IMP_YLDINC_2):
    if XC == "MAIZEN1" and C == "MAIZESTA" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_134("MAIZEN1", "MAIZE", "2025")
    else:
        return table_YLDINC_134(XC, C, IMP_YLDINC_2)

def table_YLDINC_136(XC, C, IMP_YLDINC_2):
    if XC == "MAIZES1" and C == "MAIZESTA" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_135("MAIZES1", "MAIZE", "2025")
    else:
        return table_YLDINC_135(XC, C, IMP_YLDINC_2)

def table_YLDINC_137(XC, C, IMP_YLDINC_2):
    if XC == "VEGETS1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_136("VEGETS1", "VEGET", "2025")
    else:
        return table_YLDINC_136(XC, C, IMP_YLDINC_2)

def table_YLDINC_138(XC, C, IMP_YLDINC_2):
    if XC == "VEGETW1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_137("VEGETW1", "VEGET", "2025")
    else:
        return table_YLDINC_137(XC, C, IMP_YLDINC_2)

def table_YLDINC_139(XC, C, IMP_YLDINC_2):
    if XC == "VEGETN1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_138("VEGETN1", "VEGET", "2025")
    else:
        return table_YLDINC_138(XC, C, IMP_YLDINC_2)

def table_YLDINC_140(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "RICESTR" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_139("PADDY1", "PADDY", "2025")
    else:
        return table_YLDINC_139(XC, C, IMP_YLDINC_2)

def table_YLDINC_141(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "BRAN" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_140("PADDY1", "PADDY", "2025")
    else:
        return table_YLDINC_140(XC, C, IMP_YLDINC_2)

def table_YLDINC_142(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "HUSK" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_141("PADDY1", "PADDY", "2025")
    else:
        return table_YLDINC_141(XC, C, IMP_YLDINC_2)

def table_YLDINC_143(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETFOD" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_142("SBEET1", "SGBEET", "2025")
    else:
        return table_YLDINC_142(XC, C, IMP_YLDINC_2)

def table_YLDINC_144(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SCANEFOD" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_143("SCANE1", "SGCANE", "2025")
    else:
        return table_YLDINC_143(XC, C, IMP_YLDINC_2)

def table_YLDINC_145(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "SOYAFOD" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_144("SBEAN1", "SOYBEAN", "2025")
    else:
        return table_YLDINC_144(XC, C, IMP_YLDINC_2)

def table_YLDINC_146(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "WHEATSTR" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_145("WHEAT1", "WHEAT", "2025")
    else:
        return table_YLDINC_145(XC, C, IMP_YLDINC_2)

def table_YLDINC_147(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "FXFIB" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_146("FLAX1", "FLAX", "2025")
    else:
        return table_YLDINC_146(XC, C, IMP_YLDINC_2)

def table_YLDINC_148(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "FLSECAKE" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_147("FLAX1", "FLAX", "2025")
    else:
        return table_YLDINC_147(XC, C, IMP_YLDINC_2)

def table_YLDINC_149(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_148("FLAX1", "FLAX", "2025")
    else:
        return table_YLDINC_148(XC, C, IMP_YLDINC_2)

def table_YLDINC_150(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GNUTCAKE" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_149("GNUT1", "GRDNUT", "2025")
    else:
        return table_YLDINC_149(XC, C, IMP_YLDINC_2)

def table_YLDINC_151(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_150("GNUT1", "GRDNUT", "2025")
    else:
        return table_YLDINC_150(XC, C, IMP_YLDINC_2)

def table_YLDINC_152(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "RICE" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_151("PADDY1", "PADDY", "2025")
    else:
        return table_YLDINC_151(XC, C, IMP_YLDINC_2)

def table_YLDINC_153(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "BRAN" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_152("PADDY1", "PADDY", "2025")
    else:
        return table_YLDINC_152(XC, C, IMP_YLDINC_2)

def table_YLDINC_154(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_153("SDLS1", "SEEDLS", "2025")
    else:
        return table_YLDINC_153(XC, C, IMP_YLDINC_2)

def table_YLDINC_155(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "CTONLS" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_154("SDLS1", "SEEDLS", "2025")
    else:
        return table_YLDINC_154(XC, C, IMP_YLDINC_2)

def table_YLDINC_156(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "COTSCAKE" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_155("SDLS1", "SEEDLS", "2025")
    else:
        return table_YLDINC_155(XC, C, IMP_YLDINC_2)

def table_YLDINC_157(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "COTSTA" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_156("SDLS1", "SEEDLS", "2025")
    else:
        return table_YLDINC_156(XC, C, IMP_YLDINC_2)

def table_YLDINC_158(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_157("SDELS1", "SEEDELS", "2025")
    else:
        return table_YLDINC_157(XC, C, IMP_YLDINC_2)

def table_YLDINC_159(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "CTONELS" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_158("SDELS1", "SEEDELS", "2025")
    else:
        return table_YLDINC_158(XC, C, IMP_YLDINC_2)

def table_YLDINC_160(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "COTSCAKE" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_159("SDELS1", "SEEDELS", "2025")
    else:
        return table_YLDINC_159(XC, C, IMP_YLDINC_2)

def table_YLDINC_161(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "COTSTA" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_160("SDELS1", "SEEDELS", "2025")
    else:
        return table_YLDINC_160(XC, C, IMP_YLDINC_2)

def table_YLDINC_162(XC, C, IMP_YLDINC_2):
    if XC == "SESAME1" and C == "FLSECAKE" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_161("SESAME1", "SESAME", "2025")
    else:
        return table_YLDINC_161(XC, C, IMP_YLDINC_2)

def table_YLDINC_163(XC, C, IMP_YLDINC_2):
    if XC == "SESAME1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_162("SESAME1", "SESAME", "2025")
    else:
        return table_YLDINC_162(XC, C, IMP_YLDINC_2)

def table_YLDINC_164(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SUGAR" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_163("SBEET1", "SGBEET", "2025")
    else:
        return table_YLDINC_163(XC, C, IMP_YLDINC_2)

def table_YLDINC_165(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETMOL" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_164("SBEET1", "SGBEET", "2025")
    else:
        return table_YLDINC_164(XC, C, IMP_YLDINC_2)

def table_YLDINC_166(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETPULP" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_165("SBEET1", "SGBEET", "2025")
    else:
        return table_YLDINC_165(XC, C, IMP_YLDINC_2)

def table_YLDINC_167(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SUGAR" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_166("SCANE1", "SGCANE", "2025")
    else:
        return table_YLDINC_166(XC, C, IMP_YLDINC_2)

def table_YLDINC_168(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SCANEMOL" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_167("SCANE1", "SGCANE", "2025")
    else:
        return table_YLDINC_167(XC, C, IMP_YLDINC_2)

def table_YLDINC_169(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "SOYACAKE" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_168("SBEAN1", "SOYBEAN", "2025")
    else:
        return table_YLDINC_168(XC, C, IMP_YLDINC_2)

def table_YLDINC_170(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_169("SBEAN1", "SOYBEAN", "2025")
    else:
        return table_YLDINC_169(XC, C, IMP_YLDINC_2)

def table_YLDINC_171(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "WHEATF" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_170("WHEAT1", "WHEAT", "2025")
    else:
        return table_YLDINC_170(XC, C, IMP_YLDINC_2)

def table_YLDINC_172(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "BRAN" and IMP_YLDINC_2 == "2025":
        return table_YLDINC_171("WHEAT1", "WHEAT", "2025")
    else:
        return table_YLDINC_171(XC, C, IMP_YLDINC_2)

def table_YLDINC_173(XC, C, IMP_YLDINC_2):
    if XC == "BARLEY1" and C == "BARLEYSTR" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_172("BARLEY1", "BARLEY", "2030")
    else:
        return table_YLDINC_172(XC, C, IMP_YLDINC_2)

def table_YLDINC_174(XC, C, IMP_YLDINC_2):
    if XC == "FBEAN1" and C == "FBEANFOD" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_173("FBEAN1", "FBEAN", "2030")
    else:
        return table_YLDINC_173(XC, C, IMP_YLDINC_2)

def table_YLDINC_175(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GRDNUTFOD" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_174("GNUT1", "GRDNUT", "2030")
    else:
        return table_YLDINC_174(XC, C, IMP_YLDINC_2)

def table_YLDINC_176(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GNUTSH" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_175("GNUT1", "GRDNUT", "2030")
    else:
        return table_YLDINC_175(XC, C, IMP_YLDINC_2)

def table_YLDINC_177(XC, C, IMP_YLDINC_2):
    if XC == "LENTIL1" and C == "LENTILFOD" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_176("LENTIL1", "LENTIL", "2030")
    else:
        return table_YLDINC_176(XC, C, IMP_YLDINC_2)

def table_YLDINC_178(XC, C, IMP_YLDINC_2):
    if XC == "MAIZEN1" and C == "MAIZESTA" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_177("MAIZEN1", "MAIZE", "2030")
    else:
        return table_YLDINC_177(XC, C, IMP_YLDINC_2)

def table_YLDINC_179(XC, C, IMP_YLDINC_2):
    if XC == "MAIZES1" and C == "MAIZESTA" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_178("MAIZES1", "MAIZE", "2030")
    else:
        return table_YLDINC_178(XC, C, IMP_YLDINC_2)

def table_YLDINC_180(XC, C, IMP_YLDINC_2):
    if XC == "VEGETS1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_179("VEGETS1", "VEGET", "2030")
    else:
        return table_YLDINC_179(XC, C, IMP_YLDINC_2)

def table_YLDINC_181(XC, C, IMP_YLDINC_2):
    if XC == "VEGETW1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_180("VEGETW1", "VEGET", "2030")
    else:
        return table_YLDINC_180(XC, C, IMP_YLDINC_2)

def table_YLDINC_182(XC, C, IMP_YLDINC_2):
    if XC == "VEGETN1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_181("VEGETN1", "VEGET", "2030")
    else:
        return table_YLDINC_181(XC, C, IMP_YLDINC_2)

def table_YLDINC_183(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "RICESTR" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_182("PADDY1", "PADDY", "2030")
    else:
        return table_YLDINC_182(XC, C, IMP_YLDINC_2)

def table_YLDINC_184(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "BRAN" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_183("PADDY1", "PADDY", "2030")
    else:
        return table_YLDINC_183(XC, C, IMP_YLDINC_2)

def table_YLDINC_185(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "HUSK" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_184("PADDY1", "PADDY", "2030")
    else:
        return table_YLDINC_184(XC, C, IMP_YLDINC_2)

def table_YLDINC_186(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETFOD" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_185("SBEET1", "SGBEET", "2030")
    else:
        return table_YLDINC_185(XC, C, IMP_YLDINC_2)

def table_YLDINC_187(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SCANEFOD" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_186("SCANE1", "SGCANE", "2030")
    else:
        return table_YLDINC_186(XC, C, IMP_YLDINC_2)

def table_YLDINC_188(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "SOYAFOD" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_187("SBEAN1", "SOYBEAN", "2030")
    else:
        return table_YLDINC_187(XC, C, IMP_YLDINC_2)

def table_YLDINC_189(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "WHEATSTR" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_188("WHEAT1", "WHEAT", "2030")
    else:
        return table_YLDINC_188(XC, C, IMP_YLDINC_2)

def table_YLDINC_190(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "FXFIB" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_189("FLAX1", "FLAX", "2030")
    else:
        return table_YLDINC_189(XC, C, IMP_YLDINC_2)

def table_YLDINC_191(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "FLSECAKE" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_190("FLAX1", "FLAX", "2030")
    else:
        return table_YLDINC_190(XC, C, IMP_YLDINC_2)

def table_YLDINC_192(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_191("FLAX1", "FLAX", "2030")
    else:
        return table_YLDINC_191(XC, C, IMP_YLDINC_2)

def table_YLDINC_193(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GNUTCAKE" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_192("GNUT1", "GRDNUT", "2030")
    else:
        return table_YLDINC_192(XC, C, IMP_YLDINC_2)

def table_YLDINC_194(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_193("GNUT1", "GRDNUT", "2030")
    else:
        return table_YLDINC_193(XC, C, IMP_YLDINC_2)

def table_YLDINC_195(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "RICE" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_194("PADDY1", "PADDY", "2030")
    else:
        return table_YLDINC_194(XC, C, IMP_YLDINC_2)

def table_YLDINC_196(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "BRAN" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_195("PADDY1", "PADDY", "2030")
    else:
        return table_YLDINC_195(XC, C, IMP_YLDINC_2)

def table_YLDINC_197(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_196("SDLS1", "SEEDLS", "2030")
    else:
        return table_YLDINC_196(XC, C, IMP_YLDINC_2)

def table_YLDINC_198(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "CTONLS" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_197("SDLS1", "SEEDLS", "2030")
    else:
        return table_YLDINC_197(XC, C, IMP_YLDINC_2)

def table_YLDINC_199(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "COTSCAKE" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_198("SDLS1", "SEEDLS", "2030")
    else:
        return table_YLDINC_198(XC, C, IMP_YLDINC_2)

def table_YLDINC_200(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "COTSTA" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_199("SDLS1", "SEEDLS", "2030")
    else:
        return table_YLDINC_199(XC, C, IMP_YLDINC_2)

def table_YLDINC_201(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_200("SDELS1", "SEEDELS", "2030")
    else:
        return table_YLDINC_200(XC, C, IMP_YLDINC_2)

def table_YLDINC_202(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "CTONELS" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_201("SDELS1", "SEEDELS", "2030")
    else:
        return table_YLDINC_201(XC, C, IMP_YLDINC_2)

def table_YLDINC_203(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "COTSCAKE" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_202("SDELS1", "SEEDELS", "2030")
    else:
        return table_YLDINC_202(XC, C, IMP_YLDINC_2)

def table_YLDINC_204(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "COTSTA" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_203("SDELS1", "SEEDELS", "2030")
    else:
        return table_YLDINC_203(XC, C, IMP_YLDINC_2)

def table_YLDINC_205(XC, C, IMP_YLDINC_2):
    if XC == "SESAME1" and C == "FLSECAKE" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_204("SESAME1", "SESAME", "2030")
    else:
        return table_YLDINC_204(XC, C, IMP_YLDINC_2)

def table_YLDINC_206(XC, C, IMP_YLDINC_2):
    if XC == "SESAME1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_205("SESAME1", "SESAME", "2030")
    else:
        return table_YLDINC_205(XC, C, IMP_YLDINC_2)

def table_YLDINC_207(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SUGAR" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_206("SBEET1", "SGBEET", "2030")
    else:
        return table_YLDINC_206(XC, C, IMP_YLDINC_2)

def table_YLDINC_208(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETMOL" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_207("SBEET1", "SGBEET", "2030")
    else:
        return table_YLDINC_207(XC, C, IMP_YLDINC_2)

def table_YLDINC_209(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETPULP" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_208("SBEET1", "SGBEET", "2030")
    else:
        return table_YLDINC_208(XC, C, IMP_YLDINC_2)

def table_YLDINC_210(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SUGAR" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_209("SCANE1", "SGCANE", "2030")
    else:
        return table_YLDINC_209(XC, C, IMP_YLDINC_2)

def table_YLDINC_211(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SCANEMOL" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_210("SCANE1", "SGCANE", "2030")
    else:
        return table_YLDINC_210(XC, C, IMP_YLDINC_2)

def table_YLDINC_212(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "SOYACAKE" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_211("SBEAN1", "SOYBEAN", "2030")
    else:
        return table_YLDINC_211(XC, C, IMP_YLDINC_2)

def table_YLDINC_213(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_212("SBEAN1", "SOYBEAN", "2030")
    else:
        return table_YLDINC_212(XC, C, IMP_YLDINC_2)

def table_YLDINC_214(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "WHEATF" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_213("WHEAT1", "WHEAT", "2030")
    else:
        return table_YLDINC_213(XC, C, IMP_YLDINC_2)

def table_YLDINC_215(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "BRAN" and IMP_YLDINC_2 == "2030":
        return table_YLDINC_214("WHEAT1", "WHEAT", "2030")
    else:
        return table_YLDINC_214(XC, C, IMP_YLDINC_2)

def table_YLDINC_216(XC, C, IMP_YLDINC_2):
    if XC == "BARLEY1" and C == "BARLEYSTR" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_215("BARLEY1", "BARLEY", "2037")
    else:
        return table_YLDINC_215(XC, C, IMP_YLDINC_2)

def table_YLDINC_217(XC, C, IMP_YLDINC_2):
    if XC == "FBEAN1" and C == "FBEANFOD" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_216("FBEAN1", "FBEAN", "2037")
    else:
        return table_YLDINC_216(XC, C, IMP_YLDINC_2)

def table_YLDINC_218(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GRDNUTFOD" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_217("GNUT1", "GRDNUT", "2037")
    else:
        return table_YLDINC_217(XC, C, IMP_YLDINC_2)

def table_YLDINC_219(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GNUTSH" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_218("GNUT1", "GRDNUT", "2037")
    else:
        return table_YLDINC_218(XC, C, IMP_YLDINC_2)

def table_YLDINC_220(XC, C, IMP_YLDINC_2):
    if XC == "LENTIL1" and C == "LENTILFOD" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_219("LENTIL1", "LENTIL", "2037")
    else:
        return table_YLDINC_219(XC, C, IMP_YLDINC_2)

def table_YLDINC_221(XC, C, IMP_YLDINC_2):
    if XC == "MAIZEN1" and C == "MAIZESTA" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_220("MAIZEN1", "MAIZE", "2037")
    else:
        return table_YLDINC_220(XC, C, IMP_YLDINC_2)

def table_YLDINC_222(XC, C, IMP_YLDINC_2):
    if XC == "MAIZES1" and C == "MAIZESTA" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_221("MAIZES1", "MAIZE", "2037")
    else:
        return table_YLDINC_221(XC, C, IMP_YLDINC_2)

def table_YLDINC_223(XC, C, IMP_YLDINC_2):
    if XC == "VEGETS1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_222("VEGETS1", "VEGET", "2037")
    else:
        return table_YLDINC_222(XC, C, IMP_YLDINC_2)

def table_YLDINC_224(XC, C, IMP_YLDINC_2):
    if XC == "VEGETW1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_223("VEGETW1", "VEGET", "2037")
    else:
        return table_YLDINC_223(XC, C, IMP_YLDINC_2)

def table_YLDINC_225(XC, C, IMP_YLDINC_2):
    if XC == "VEGETN1" and C == "VEGETFOD" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_224("VEGETN1", "VEGET", "2037")
    else:
        return table_YLDINC_224(XC, C, IMP_YLDINC_2)

def table_YLDINC_226(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "RICESTR" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_225("PADDY1", "PADDY", "2037")
    else:
        return table_YLDINC_225(XC, C, IMP_YLDINC_2)

def table_YLDINC_227(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "BRAN" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_226("PADDY1", "PADDY", "2037")
    else:
        return table_YLDINC_226(XC, C, IMP_YLDINC_2)

def table_YLDINC_228(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "HUSK" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_227("PADDY1", "PADDY", "2037")
    else:
        return table_YLDINC_227(XC, C, IMP_YLDINC_2)

def table_YLDINC_229(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETFOD" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_228("SBEET1", "SGBEET", "2037")
    else:
        return table_YLDINC_228(XC, C, IMP_YLDINC_2)

def table_YLDINC_230(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SCANEFOD" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_229("SCANE1", "SGCANE", "2037")
    else:
        return table_YLDINC_229(XC, C, IMP_YLDINC_2)

def table_YLDINC_231(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "SOYAFOD" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_230("SBEAN1", "SOYBEAN", "2037")
    else:
        return table_YLDINC_230(XC, C, IMP_YLDINC_2)

def table_YLDINC_232(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "WHEATSTR" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_231("WHEAT1", "WHEAT", "2037")
    else:
        return table_YLDINC_231(XC, C, IMP_YLDINC_2)

def table_YLDINC_233(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "FXFIB" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_232("FLAX1", "FLAX", "2037")
    else:
        return table_YLDINC_232(XC, C, IMP_YLDINC_2)

def table_YLDINC_234(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "FLSECAKE" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_233("FLAX1", "FLAX", "2037")
    else:
        return table_YLDINC_233(XC, C, IMP_YLDINC_2)

def table_YLDINC_235(XC, C, IMP_YLDINC_2):
    if XC == "FLAX1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_234("FLAX1", "FLAX", "2037")
    else:
        return table_YLDINC_234(XC, C, IMP_YLDINC_2)

def table_YLDINC_236(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "GNUTCAKE" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_235("GNUT1", "GRDNUT", "2037")
    else:
        return table_YLDINC_235(XC, C, IMP_YLDINC_2)

def table_YLDINC_237(XC, C, IMP_YLDINC_2):
    if XC == "GNUT1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_236("GNUT1", "GRDNUT", "2037")
    else:
        return table_YLDINC_236(XC, C, IMP_YLDINC_2)

def table_YLDINC_238(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "RICE" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_237("PADDY1", "PADDY", "2037")
    else:
        return table_YLDINC_237(XC, C, IMP_YLDINC_2)

def table_YLDINC_239(XC, C, IMP_YLDINC_2):
    if XC == "PADDY1" and C == "BRAN" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_238("PADDY1", "PADDY", "2037")
    else:
        return table_YLDINC_238(XC, C, IMP_YLDINC_2)

def table_YLDINC_240(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_239("SDLS1", "SEEDLS", "2037")
    else:
        return table_YLDINC_239(XC, C, IMP_YLDINC_2)

def table_YLDINC_241(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "CTONLS" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_240("SDLS1", "SEEDLS", "2037")
    else:
        return table_YLDINC_240(XC, C, IMP_YLDINC_2)

def table_YLDINC_242(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "COTSCAKE" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_241("SDLS1", "SEEDLS", "2037")
    else:
        return table_YLDINC_241(XC, C, IMP_YLDINC_2)

def table_YLDINC_243(XC, C, IMP_YLDINC_2):
    if XC == "SDLS1" and C == "COTSTA" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_242("SDLS1", "SEEDLS", "2037")
    else:
        return table_YLDINC_242(XC, C, IMP_YLDINC_2)

def table_YLDINC_244(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_243("SDELS1", "SEEDELS", "2037")
    else:
        return table_YLDINC_243(XC, C, IMP_YLDINC_2)

def table_YLDINC_245(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "CTONELS" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_244("SDELS1", "SEEDELS", "2037")
    else:
        return table_YLDINC_244(XC, C, IMP_YLDINC_2)

def table_YLDINC_246(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "COTSCAKE" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_245("SDELS1", "SEEDELS", "2037")
    else:
        return table_YLDINC_245(XC, C, IMP_YLDINC_2)

def table_YLDINC_247(XC, C, IMP_YLDINC_2):
    if XC == "SDELS1" and C == "COTSTA" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_246("SDELS1", "SEEDELS", "2037")
    else:
        return table_YLDINC_246(XC, C, IMP_YLDINC_2)

def table_YLDINC_248(XC, C, IMP_YLDINC_2):
    if XC == "SESAME1" and C == "FLSECAKE" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_247("SESAME1", "SESAME", "2037")
    else:
        return table_YLDINC_247(XC, C, IMP_YLDINC_2)

def table_YLDINC_249(XC, C, IMP_YLDINC_2):
    if XC == "SESAME1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_248("SESAME1", "SESAME", "2037")
    else:
        return table_YLDINC_248(XC, C, IMP_YLDINC_2)

def table_YLDINC_250(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SUGAR" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_249("SBEET1", "SGBEET", "2037")
    else:
        return table_YLDINC_249(XC, C, IMP_YLDINC_2)

def table_YLDINC_251(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETMOL" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_250("SBEET1", "SGBEET", "2037")
    else:
        return table_YLDINC_250(XC, C, IMP_YLDINC_2)

def table_YLDINC_252(XC, C, IMP_YLDINC_2):
    if XC == "SBEET1" and C == "SBEETPULP" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_251("SBEET1", "SGBEET", "2037")
    else:
        return table_YLDINC_251(XC, C, IMP_YLDINC_2)

def table_YLDINC_253(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SUGAR" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_252("SCANE1", "SGCANE", "2037")
    else:
        return table_YLDINC_252(XC, C, IMP_YLDINC_2)

def table_YLDINC_254(XC, C, IMP_YLDINC_2):
    if XC == "SCANE1" and C == "SCANEMOL" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_253("SCANE1", "SGCANE", "2037")
    else:
        return table_YLDINC_253(XC, C, IMP_YLDINC_2)

def table_YLDINC_255(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "SOYACAKE" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_254("SBEAN1", "SOYBEAN", "2037")
    else:
        return table_YLDINC_254(XC, C, IMP_YLDINC_2)

def table_YLDINC_256(XC, C, IMP_YLDINC_2):
    if XC == "SBEAN1" and C == "VEG-OIL" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_255("SBEAN1", "SOYBEAN", "2037")
    else:
        return table_YLDINC_255(XC, C, IMP_YLDINC_2)

def table_YLDINC_257(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "WHEATF" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_256("WHEAT1", "WHEAT", "2037")
    else:
        return table_YLDINC_256(XC, C, IMP_YLDINC_2)

def table_YLDINC_258(XC, C, IMP_YLDINC_2):
    if XC == "WHEAT1" and C == "BRAN" and IMP_YLDINC_2 == "2037":
        return table_YLDINC_257("WHEAT1", "WHEAT", "2037")
    else:
        return table_YLDINC_257(XC, C, IMP_YLDINC_2)

def table_YLDINC(XC, C, IMP_YLDINC_2):
    return table_YLDINC_258(XC, C, IMP_YLDINC_2)

# Table: yield reduction in 2030 compared to 2014 (factor)

df_YLDCLIM = pd.read_excel("tables/YLDCLIM.xlsx")
for col in df_YLDCLIM.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table YLDCLIM is a float, cast it to an int before casting it to a str, rename it.")
            df_YLDCLIM.rename(columns={col: int(col)}, inplace=True)
df_YLDCLIM.columns = df_YLDCLIM.columns.astype(str)

missing_YLDCLIM_rows = []
missing_YLDCLIM_cols = []

def table_YLDCLIM_0(XC, C, IMP_YLDCLIM_2):
    col = IMP_YLDCLIM_2
    row = XC + "." + C
    if row not in df_YLDCLIM["index"].tolist():
        if row not in missing_YLDCLIM_rows:
            # print("Warning: row " + row + " is not in table YLDCLIM, return 0.0")
            missing_YLDCLIM_rows.append(row)
        return 0.0
    if col not in df_YLDCLIM.columns:
        if col not in missing_YLDCLIM_cols:
            # print("Warning: column " + col + " is not in table YLDCLIM, return 0.0")
            missing_YLDCLIM_cols.append(col)
        return 0.0
    value = df_YLDCLIM[col][df_YLDCLIM["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_YLDCLIM[col][df_YLDCLIM["index"].tolist().index(row)]
def table_YLDCLIM_1(XC, C, IMP_YLDCLIM_2):
    if XC == "BARLEY1" and C == "BARLEYSTR" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_0("BARLEY1", "BARLEY", "2030")
    else:
        return table_YLDCLIM_0(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_2(XC, C, IMP_YLDCLIM_2):
    if XC == "FBEAN1" and C == "FBEANFOD" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_1("FBEAN1", "FBEAN", "2030")
    else:
        return table_YLDCLIM_1(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_3(XC, C, IMP_YLDCLIM_2):
    if XC == "GNUT1" and C == "GRDNUTFOD" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_2("GNUT1", "GRDNUT", "2030")
    else:
        return table_YLDCLIM_2(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_4(XC, C, IMP_YLDCLIM_2):
    if XC == "GNUT1" and C == "GNUTSH" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_3("GNUT1", "GRDNUT", "2030")
    else:
        return table_YLDCLIM_3(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_5(XC, C, IMP_YLDCLIM_2):
    if XC == "LENTIL1" and C == "LENTILFOD" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_4("LENTIL1", "LENTIL", "2030")
    else:
        return table_YLDCLIM_4(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_6(XC, C, IMP_YLDCLIM_2):
    if XC == "MAIZEN1" and C == "MAIZESTA" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_5("MAIZEN1", "MAIZE", "2030")
    else:
        return table_YLDCLIM_5(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_7(XC, C, IMP_YLDCLIM_2):
    if XC == "MAIZES1" and C == "MAIZESTA" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_6("MAIZES1", "MAIZE", "2030")
    else:
        return table_YLDCLIM_6(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_8(XC, C, IMP_YLDCLIM_2):
    if XC == "VEGETS1" and C == "VEGETFOD" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_7("VEGETS1", "VEGET", "2030")
    else:
        return table_YLDCLIM_7(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_9(XC, C, IMP_YLDCLIM_2):
    if XC == "VEGETW1" and C == "VEGETFOD" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_8("VEGETW1", "VEGET", "2030")
    else:
        return table_YLDCLIM_8(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_10(XC, C, IMP_YLDCLIM_2):
    if XC == "VEGETN1" and C == "VEGETFOD" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_9("VEGETN1", "VEGET", "2030")
    else:
        return table_YLDCLIM_9(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_11(XC, C, IMP_YLDCLIM_2):
    if XC == "PADDY1" and C == "RICESTR" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_10("PADDY1", "PADDY", "2030")
    else:
        return table_YLDCLIM_10(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_12(XC, C, IMP_YLDCLIM_2):
    if XC == "PADDY1" and C == "HUSK" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_11("PADDY1", "PADDY", "2030")
    else:
        return table_YLDCLIM_11(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_13(XC, C, IMP_YLDCLIM_2):
    if XC == "SBEET1" and C == "SBEETFOD" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_12("SBEET1", "SGBEET", "2030")
    else:
        return table_YLDCLIM_12(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_14(XC, C, IMP_YLDCLIM_2):
    if XC == "SCANE1" and C == "SCANEFOD" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_13("SCANE1", "SGCANE", "2030")
    else:
        return table_YLDCLIM_13(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_15(XC, C, IMP_YLDCLIM_2):
    if XC == "SBEAN1" and C == "SOYAFOD" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_14("SBEAN1", "SOYBEAN", "2030")
    else:
        return table_YLDCLIM_14(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_16(XC, C, IMP_YLDCLIM_2):
    if XC == "WHEAT1" and C == "WHEATSTR" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_15("WHEAT1", "WHEAT", "2030")
    else:
        return table_YLDCLIM_15(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_17(XC, C, IMP_YLDCLIM_2):
    if XC == "FLAX1" and C == "FXFIB" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_16("FLAX1", "FLAX", "2030")
    else:
        return table_YLDCLIM_16(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_18(XC, C, IMP_YLDCLIM_2):
    if XC == "FLAX1" and C == "FLSECAKE" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_17("FLAX1", "FLAX", "2030")
    else:
        return table_YLDCLIM_17(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_19(XC, C, IMP_YLDCLIM_2):
    if XC == "FLAX1" and C == "VEG-OIL" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_18("FLAX1", "FLAX", "2030")
    else:
        return table_YLDCLIM_18(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_20(XC, C, IMP_YLDCLIM_2):
    if XC == "GNUT1" and C == "GNUTCAKE" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_19("GNUT1", "GRDNUT", "2030")
    else:
        return table_YLDCLIM_19(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_21(XC, C, IMP_YLDCLIM_2):
    if XC == "GNUT1" and C == "VEG-OIL" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_20("GNUT1", "GRDNUT", "2030")
    else:
        return table_YLDCLIM_20(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_22(XC, C, IMP_YLDCLIM_2):
    if XC == "PADDY1" and C == "RICE" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_21("PADDY1", "PADDY", "2030")
    else:
        return table_YLDCLIM_21(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_23(XC, C, IMP_YLDCLIM_2):
    if XC == "PADDY1" and C == "BRAN" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_22("PADDY1", "PADDY", "2030")
    else:
        return table_YLDCLIM_22(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_24(XC, C, IMP_YLDCLIM_2):
    if XC == "SDLS1" and C == "VEG-OIL" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_23("SDLS1", "SEEDLS", "2030")
    else:
        return table_YLDCLIM_23(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_25(XC, C, IMP_YLDCLIM_2):
    if XC == "SDLS1" and C == "CTONLS" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_24("SDLS1", "SEEDLS", "2030")
    else:
        return table_YLDCLIM_24(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_26(XC, C, IMP_YLDCLIM_2):
    if XC == "SDLS1" and C == "COTSCAKE" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_25("SDLS1", "SEEDLS", "2030")
    else:
        return table_YLDCLIM_25(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_27(XC, C, IMP_YLDCLIM_2):
    if XC == "SDLS1" and C == "COTSTA" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_26("SDLS1", "SEEDLS", "2030")
    else:
        return table_YLDCLIM_26(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_28(XC, C, IMP_YLDCLIM_2):
    if XC == "SDELS1" and C == "VEG-OIL" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_27("SDELS1", "SEEDELS", "2030")
    else:
        return table_YLDCLIM_27(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_29(XC, C, IMP_YLDCLIM_2):
    if XC == "SDELS1" and C == "CTONELS" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_28("SDELS1", "SEEDELS", "2030")
    else:
        return table_YLDCLIM_28(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_30(XC, C, IMP_YLDCLIM_2):
    if XC == "SDELS1" and C == "COTSCAKE" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_29("SDELS1", "SEEDELS", "2030")
    else:
        return table_YLDCLIM_29(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_31(XC, C, IMP_YLDCLIM_2):
    if XC == "SDELS1" and C == "COTSTA" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_30("SDELS1", "SEEDELS", "2030")
    else:
        return table_YLDCLIM_30(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_32(XC, C, IMP_YLDCLIM_2):
    if XC == "SESAME1" and C == "FLSECAKE" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_31("SESAME1", "SESAME", "2030")
    else:
        return table_YLDCLIM_31(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_33(XC, C, IMP_YLDCLIM_2):
    if XC == "SESAME1" and C == "VEG-OIL" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_32("SESAME1", "SESAME", "2030")
    else:
        return table_YLDCLIM_32(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_34(XC, C, IMP_YLDCLIM_2):
    if XC == "SBEET1" and C == "SUGAR" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_33("SBEET1", "SGBEET", "2030")
    else:
        return table_YLDCLIM_33(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_35(XC, C, IMP_YLDCLIM_2):
    if XC == "SBEET1" and C == "SBEETMOL" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_34("SBEET1", "SGBEET", "2030")
    else:
        return table_YLDCLIM_34(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_36(XC, C, IMP_YLDCLIM_2):
    if XC == "SBEET1" and C == "SBEETPULP" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_35("SBEET1", "SGBEET", "2030")
    else:
        return table_YLDCLIM_35(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_37(XC, C, IMP_YLDCLIM_2):
    if XC == "SCANE1" and C == "SUGAR" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_36("SCANE1", "SGCANE", "2030")
    else:
        return table_YLDCLIM_36(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_38(XC, C, IMP_YLDCLIM_2):
    if XC == "SCANE1" and C == "SCANEMOL" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_37("SCANE1", "SGCANE", "2030")
    else:
        return table_YLDCLIM_37(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_39(XC, C, IMP_YLDCLIM_2):
    if XC == "SBEAN1" and C == "SOYACAKE" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_38("SBEAN1", "SOYBEAN", "2030")
    else:
        return table_YLDCLIM_38(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_40(XC, C, IMP_YLDCLIM_2):
    if XC == "SBEAN1" and C == "VEG-OIL" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_39("SBEAN1", "SOYBEAN", "2030")
    else:
        return table_YLDCLIM_39(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_41(XC, C, IMP_YLDCLIM_2):
    if XC == "WHEAT1" and C == "WHEATF" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_40("WHEAT1", "WHEAT", "2030")
    else:
        return table_YLDCLIM_40(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM_42(XC, C, IMP_YLDCLIM_2):
    if XC == "WHEAT1" and C == "BRAN" and IMP_YLDCLIM_2 == "2030":
        return table_YLDCLIM_41("WHEAT1", "WHEAT", "2030")
    else:
        return table_YLDCLIM_41(XC, C, IMP_YLDCLIM_2)

def table_YLDCLIM(XC, C, IMP_YLDCLIM_2):
    return table_YLDCLIM_42(XC, C, IMP_YLDCLIM_2)

# Table: irrigation rent and non-labor input costs by crop (LE p fed)

df_INPUT = pd.read_excel("tables/INPUT.xlsx")
for col in df_INPUT.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table INPUT is a float, cast it to an int before casting it to a str, rename it.")
            df_INPUT.rename(columns={col: int(col)}, inplace=True)
df_INPUT.columns = df_INPUT.columns.astype(str)

missing_INPUT_rows = []
missing_INPUT_cols = []

def table_INPUT_0(XC, INP):
    col = INP
    row = XC
    if row not in df_INPUT["index"].tolist():
        if row not in missing_INPUT_rows:
            # print("Warning: row " + row + " is not in table INPUT, return 0.0")
            missing_INPUT_rows.append(row)
        return 0.0
    if col not in df_INPUT.columns:
        if col not in missing_INPUT_cols:
            # print("Warning: column " + col + " is not in table INPUT, return 0.0")
            missing_INPUT_cols.append(col)
        return 0.0
    value = df_INPUT[col][df_INPUT["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_INPUT[col][df_INPUT["index"].tolist().index(row)]
def table_INPUT(XC, INP):
    return table_INPUT_0(XC, INP)

# Table: historic 2013-14 cultivated areas (000fed)

df_HAREAS = pd.read_excel("tables/HAREAS.xlsx")
for col in df_HAREAS.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table HAREAS is a float, cast it to an int before casting it to a str, rename it.")
            df_HAREAS.rename(columns={col: int(col)}, inplace=True)
df_HAREAS.columns = df_HAREAS.columns.astype(str)

missing_HAREAS_rows = []
missing_HAREAS_cols = []

def table_HAREAS_0(XC, R):
    col = R
    row = XC
    if row not in df_HAREAS["index"].tolist():
        if row not in missing_HAREAS_rows:
            # print("Warning: row " + row + " is not in table HAREAS, return 0.0")
            missing_HAREAS_rows.append(row)
        return 0.0
    if col not in df_HAREAS.columns:
        if col not in missing_HAREAS_cols:
            # print("Warning: column " + col + " is not in table HAREAS, return 0.0")
            missing_HAREAS_cols.append(col)
        return 0.0
    value = df_HAREAS[col][df_HAREAS["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_HAREAS[col][df_HAREAS["index"].tolist().index(row)]
def table_HAREAS(XC, R):
    return table_HAREAS_0(XC, R)

# Table: caloric values protein and fat content of commodities per kg

df_NUTRITION = pd.read_excel("tables/NUTRITION.xlsx")
for col in df_NUTRITION.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table NUTRITION is a float, cast it to an int before casting it to a str, rename it.")
            df_NUTRITION.rename(columns={col: int(col)}, inplace=True)
df_NUTRITION.columns = df_NUTRITION.columns.astype(str)

missing_NUTRITION_rows = []
missing_NUTRITION_cols = []

def table_NUTRITION_0(C, IMP_NUTRITION_1):
    col = IMP_NUTRITION_1
    row = C
    if row not in df_NUTRITION["index"].tolist():
        if row not in missing_NUTRITION_rows:
            # print("Warning: row " + row + " is not in table NUTRITION, return 0.0")
            missing_NUTRITION_rows.append(row)
        return 0.0
    if col not in df_NUTRITION.columns:
        if col not in missing_NUTRITION_cols:
            # print("Warning: column " + col + " is not in table NUTRITION, return 0.0")
            missing_NUTRITION_cols.append(col)
        return 0.0
    value = df_NUTRITION[col][df_NUTRITION["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_NUTRITION[col][df_NUTRITION["index"].tolist().index(row)]
def table_NUTRITION(C, IMP_NUTRITION_1):
    return table_NUTRITION_0(C, IMP_NUTRITION_1)

# Table: irrigation water salinity tolerance of crops (ppm)

df_SALTOL = pd.read_excel("tables/SALTOL.xlsx")
for col in df_SALTOL.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table SALTOL is a float, cast it to an int before casting it to a str, rename it.")
            df_SALTOL.rename(columns={col: int(col)}, inplace=True)
df_SALTOL.columns = df_SALTOL.columns.astype(str)

missing_SALTOL_rows = []
missing_SALTOL_cols = []

def table_SALTOL_0(XC, IMP_SALTOL_1):
    col = IMP_SALTOL_1
    row = XC
    if row not in df_SALTOL["index"].tolist():
        if row not in missing_SALTOL_rows:
            # print("Warning: row " + row + " is not in table SALTOL, return 0.0")
            missing_SALTOL_rows.append(row)
        return 0.0
    if col not in df_SALTOL.columns:
        if col not in missing_SALTOL_cols:
            # print("Warning: column " + col + " is not in table SALTOL, return 0.0")
            missing_SALTOL_cols.append(col)
        return 0.0
    value = df_SALTOL[col][df_SALTOL["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_SALTOL[col][df_SALTOL["index"].tolist().index(row)]
def table_SALTOL(XC, IMP_SALTOL_1):
    return table_SALTOL_0(XC, IMP_SALTOL_1)

# Table: urban and rural population and farmers (000capita)

df_POPULATION = pd.read_excel("tables/POPULATION.xlsx")
for col in df_POPULATION.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table POPULATION is a float, cast it to an int before casting it to a str, rename it.")
            df_POPULATION.rename(columns={col: int(col)}, inplace=True)
df_POPULATION.columns = df_POPULATION.columns.astype(str)

missing_POPULATION_rows = []
missing_POPULATION_cols = []

def table_POPULATION_0(R, IMP_POPULATION_1):
    col = IMP_POPULATION_1
    row = R
    if row not in df_POPULATION["index"].tolist():
        if row not in missing_POPULATION_rows:
            # print("Warning: row " + row + " is not in table POPULATION, return 0.0")
            missing_POPULATION_rows.append(row)
        return 0.0
    if col not in df_POPULATION.columns:
        if col not in missing_POPULATION_cols:
            # print("Warning: column " + col + " is not in table POPULATION, return 0.0")
            missing_POPULATION_cols.append(col)
        return 0.0
    value = df_POPULATION[col][df_POPULATION["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_POPULATION[col][df_POPULATION["index"].tolist().index(row)]
def table_POPULATION_1(R, IMP_POPULATION_1):
    if IMP_POPULATION_1 == "URB":
        return table_POPULATION_0(R, "URB21")
    else:
        return table_POPULATION_0(R, IMP_POPULATION_1)

def table_POPULATION_2(R, IMP_POPULATION_1):
    if IMP_POPULATION_1 == "RUR":
        return table_POPULATION_1(R, "RUR21")
    else:
        return table_POPULATION_1(R, IMP_POPULATION_1)

def table_POPULATION(R, IMP_POPULATION_1):
    return table_POPULATION_2(R, IMP_POPULATION_1)

# Table: crop and livestock commodity demand data

df_DEMDAT = pd.read_excel("tables/DEMDAT.xlsx")
for col in df_DEMDAT.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table DEMDAT is a float, cast it to an int before casting it to a str, rename it.")
            df_DEMDAT.rename(columns={col: int(col)}, inplace=True)
df_DEMDAT.columns = df_DEMDAT.columns.astype(str)

missing_DEMDAT_rows = []
missing_DEMDAT_cols = []

def table_DEMDAT_0(C, IMP_DEMDAT_1):
    col = IMP_DEMDAT_1
    row = C
    if row not in df_DEMDAT["index"].tolist():
        if row not in missing_DEMDAT_rows:
            # print("Warning: row " + row + " is not in table DEMDAT, return 0.0")
            missing_DEMDAT_rows.append(row)
        return 0.0
    if col not in df_DEMDAT.columns:
        if col not in missing_DEMDAT_cols:
            # print("Warning: column " + col + " is not in table DEMDAT, return 0.0")
            missing_DEMDAT_cols.append(col)
        return 0.0
    value = df_DEMDAT[col][df_DEMDAT["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_DEMDAT[col][df_DEMDAT["index"].tolist().index(row)]
def table_DEMDAT_1(C, IMP_DEMDAT_1):
    if IMP_DEMDAT_1 == "BASE-P":
        return table_DEMDAT_0(C, "2021FGP")
    else:
        return table_DEMDAT_0(C, IMP_DEMDAT_1)

def table_DEMDAT_2(C, IMP_DEMDAT_1):
    if IMP_DEMDAT_1 == "IMP-Q":
        return table_DEMDAT_1(C, "IMPQ21")
    else:
        return table_DEMDAT_1(C, IMP_DEMDAT_1)

def table_DEMDAT_3(C, IMP_DEMDAT_1):
    if IMP_DEMDAT_1 == "IMP-P":
        return table_DEMDAT_2(C, "IMPP21")
    else:
        return table_DEMDAT_2(C, IMP_DEMDAT_1)

def table_DEMDAT_4(C, IMP_DEMDAT_1):
    if IMP_DEMDAT_1 == "EXP-Q":
        return table_DEMDAT_3(C, "EXPQ21")
    else:
        return table_DEMDAT_3(C, IMP_DEMDAT_1)

def table_DEMDAT_5(C, IMP_DEMDAT_1):
    if IMP_DEMDAT_1 == "EXP-P":
        return table_DEMDAT_4(C, "EXPP21")
    else:
        return table_DEMDAT_4(C, IMP_DEMDAT_1)

def table_DEMDAT_6(C, IMP_DEMDAT_1):
    if IMP_DEMDAT_1 == "HUMCONR":
        return table_DEMDAT_5(C, "DHCR21")
    else:
        return table_DEMDAT_5(C, IMP_DEMDAT_1)

def table_DEMDAT_7(C, IMP_DEMDAT_1):
    if IMP_DEMDAT_1 == "HUMCONU":
        return table_DEMDAT_6(C, "DHCU21")
    else:
        return table_DEMDAT_6(C, IMP_DEMDAT_1)

def table_DEMDAT_8(C, IMP_DEMDAT_1):
    if IMP_DEMDAT_1 == "PRIELASR":
        return table_DEMDAT_7(C, "PELAR05")
    else:
        return table_DEMDAT_7(C, IMP_DEMDAT_1)

def table_DEMDAT_9(C, IMP_DEMDAT_1):
    if IMP_DEMDAT_1 == "PRIELASU":
        return table_DEMDAT_8(C, "PELAU05")
    else:
        return table_DEMDAT_8(C, IMP_DEMDAT_1)

def table_DEMDAT(C, IMP_DEMDAT_1):
    return table_DEMDAT_9(C, IMP_DEMDAT_1)

# Table: min. nutrient and protein req. of feeds (fraction)

df_FEEDSCOMP = pd.read_excel("tables/FEEDSCOMP.xlsx")
for col in df_FEEDSCOMP.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table FEEDSCOMP is a float, cast it to an int before casting it to a str, rename it.")
            df_FEEDSCOMP.rename(columns={col: int(col)}, inplace=True)
df_FEEDSCOMP.columns = df_FEEDSCOMP.columns.astype(str)

missing_FEEDSCOMP_rows = []
missing_FEEDSCOMP_cols = []

def table_FEEDSCOMP_0(FEEDS, FEEDIND):
    col = FEEDIND
    row = FEEDS
    if row not in df_FEEDSCOMP["index"].tolist():
        if row not in missing_FEEDSCOMP_rows:
            # print("Warning: row " + row + " is not in table FEEDSCOMP, return 0.0")
            missing_FEEDSCOMP_rows.append(row)
        return 0.0
    if col not in df_FEEDSCOMP.columns:
        if col not in missing_FEEDSCOMP_cols:
            # print("Warning: column " + col + " is not in table FEEDSCOMP, return 0.0")
            missing_FEEDSCOMP_cols.append(col)
        return 0.0
    value = df_FEEDSCOMP[col][df_FEEDSCOMP["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_FEEDSCOMP[col][df_FEEDSCOMP["index"].tolist().index(row)]
def table_FEEDSCOMP(FEEDS, FEEDIND):
    return table_FEEDSCOMP_0(FEEDS, FEEDIND)

# Table: indicators of feed ingredients (fraction)

df_FCCONT = pd.read_excel("tables/FCCONT.xlsx")
for col in df_FCCONT.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table FCCONT is a float, cast it to an int before casting it to a str, rename it.")
            df_FCCONT.rename(columns={col: int(col)}, inplace=True)
df_FCCONT.columns = df_FCCONT.columns.astype(str)

missing_FCCONT_rows = []
missing_FCCONT_cols = []

def table_FCCONT_0(C, FCTYPE, FEEDIND):
    col = FEEDIND
    row = C + "." + FCTYPE
    if row not in df_FCCONT["index"].tolist():
        if row not in missing_FCCONT_rows:
            # print("Warning: row " + row + " is not in table FCCONT, return 0.0")
            missing_FCCONT_rows.append(row)
        return 0.0
    if col not in df_FCCONT.columns:
        if col not in missing_FCCONT_cols:
            # print("Warning: column " + col + " is not in table FCCONT, return 0.0")
            missing_FCCONT_cols.append(col)
        return 0.0
    value = df_FCCONT[col][df_FCCONT["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_FCCONT[col][df_FCCONT["index"].tolist().index(row)]
def table_FCCONT(C, FCTYPE, FEEDIND):
    return table_FCCONT_0(C, FCTYPE, FEEDIND)

# Table: max of feed ingredients in feeds (fraction)

df_FCMAX = pd.read_excel("tables/FCMAX.xlsx")
for col in df_FCMAX.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table FCMAX is a float, cast it to an int before casting it to a str, rename it.")
            df_FCMAX.rename(columns={col: int(col)}, inplace=True)
df_FCMAX.columns = df_FCMAX.columns.astype(str)

missing_FCMAX_rows = []
missing_FCMAX_cols = []

def table_FCMAX_0(C, FCTYPE, FEEDS):
    col = FEEDS
    row = C + "." + FCTYPE
    if row not in df_FCMAX["index"].tolist():
        if row not in missing_FCMAX_rows:
            # print("Warning: row " + row + " is not in table FCMAX, return 0.0")
            missing_FCMAX_rows.append(row)
        return 0.0
    if col not in df_FCMAX.columns:
        if col not in missing_FCMAX_cols:
            # print("Warning: column " + col + " is not in table FCMAX, return 0.0")
            missing_FCMAX_cols.append(col)
        return 0.0
    value = df_FCMAX[col][df_FCMAX["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_FCMAX[col][df_FCMAX["index"].tolist().index(row)]
def table_FCMAX(C, FCTYPE, FEEDS):
    return table_FCMAX_0(C, FCTYPE, FEEDS)

# Table: feed req. per livestock activity (t DM p y)

df_FEEDREQ = pd.read_excel("tables/FEEDREQ.xlsx")
for col in df_FEEDREQ.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table FEEDREQ is a float, cast it to an int before casting it to a str, rename it.")
            df_FEEDREQ.rename(columns={col: int(col)}, inplace=True)
df_FEEDREQ.columns = df_FEEDREQ.columns.astype(str)

missing_FEEDREQ_rows = []
missing_FEEDREQ_cols = []

def table_FEEDREQ_0(XA, M, FEEDS):
    col = FEEDS
    row = XA + "." + M
    if row not in df_FEEDREQ["index"].tolist():
        if row not in missing_FEEDREQ_rows:
            # print("Warning: row " + row + " is not in table FEEDREQ, return 0.0")
            missing_FEEDREQ_rows.append(row)
        return 0.0
    if col not in df_FEEDREQ.columns:
        if col not in missing_FEEDREQ_cols:
            # print("Warning: column " + col + " is not in table FEEDREQ, return 0.0")
            missing_FEEDREQ_cols.append(col)
        return 0.0
    value = df_FEEDREQ[col][df_FEEDREQ["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_FEEDREQ[col][df_FEEDREQ["index"].tolist().index(row)]
def table_FEEDREQ(XA, M, FEEDS):
    return table_FEEDREQ_0(XA, M, FEEDS)

# Table: livestock labour requirements (man day p y)

df_LABREQLS = pd.read_excel("tables/LABREQLS.xlsx")
for col in df_LABREQLS.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table LABREQLS is a float, cast it to an int before casting it to a str, rename it.")
            df_LABREQLS.rename(columns={col: int(col)}, inplace=True)
df_LABREQLS.columns = df_LABREQLS.columns.astype(str)

missing_LABREQLS_rows = []
missing_LABREQLS_cols = []

def table_LABREQLS_0(XA, M, LSLAB):
    col = LSLAB
    row = XA + "." + M
    if row not in df_LABREQLS["index"].tolist():
        if row not in missing_LABREQLS_rows:
            # print("Warning: row " + row + " is not in table LABREQLS, return 0.0")
            missing_LABREQLS_rows.append(row)
        return 0.0
    if col not in df_LABREQLS.columns:
        if col not in missing_LABREQLS_cols:
            # print("Warning: column " + col + " is not in table LABREQLS, return 0.0")
            missing_LABREQLS_cols.append(col)
        return 0.0
    value = df_LABREQLS[col][df_LABREQLS["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_LABREQLS[col][df_LABREQLS["index"].tolist().index(row)]
def table_LABREQLS(XA, M, LSLAB):
    return table_LABREQLS_0(XA, M, LSLAB)

# Table: livestock other input costs (LE p unit)

df_LSOICST = pd.read_excel("tables/LSOICST.xlsx")
for col in df_LSOICST.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table LSOICST is a float, cast it to an int before casting it to a str, rename it.")
            df_LSOICST.rename(columns={col: int(col)}, inplace=True)
df_LSOICST.columns = df_LSOICST.columns.astype(str)

missing_LSOICST_rows = []
missing_LSOICST_cols = []

def table_LSOICST_0(XA, M, LSOINP):
    col = LSOINP
    row = XA + "." + M
    if row not in df_LSOICST["index"].tolist():
        if row not in missing_LSOICST_rows:
            # print("Warning: row " + row + " is not in table LSOICST, return 0.0")
            missing_LSOICST_rows.append(row)
        return 0.0
    if col not in df_LSOICST.columns:
        if col not in missing_LSOICST_cols:
            # print("Warning: column " + col + " is not in table LSOICST, return 0.0")
            missing_LSOICST_cols.append(col)
        return 0.0
    value = df_LSOICST[col][df_LSOICST["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_LSOICST[col][df_LSOICST["index"].tolist().index(row)]
def table_LSOICST(XA, M, LSOINP):
    return table_LSOICST_0(XA, M, LSOINP)

# Table: livestock yield per unit (t p y)

df_YLDA = pd.read_excel("tables/YLDA.xlsx")
for col in df_YLDA.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table YLDA is a float, cast it to an int before casting it to a str, rename it.")
            df_YLDA.rename(columns={col: int(col)}, inplace=True)
df_YLDA.columns = df_YLDA.columns.astype(str)

missing_YLDA_rows = []
missing_YLDA_cols = []

def table_YLDA_0(XA, M, C):
    col = C
    row = XA + "." + M
    if row not in df_YLDA["index"].tolist():
        if row not in missing_YLDA_rows:
            # print("Warning: row " + row + " is not in table YLDA, return 0.0")
            missing_YLDA_rows.append(row)
        return 0.0
    if col not in df_YLDA.columns:
        if col not in missing_YLDA_cols:
            # print("Warning: column " + col + " is not in table YLDA, return 0.0")
            missing_YLDA_cols.append(col)
        return 0.0
    value = df_YLDA[col][df_YLDA["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_YLDA[col][df_YLDA["index"].tolist().index(row)]
def table_YLDA(XA, M, C):
    return table_YLDA_0(XA, M, C)

# Table: drainage destinations (fraction)

df_DRAINAGE = pd.read_excel("tables/DRAINAGE.xlsx")
for col in df_DRAINAGE.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table DRAINAGE is a float, cast it to an int before casting it to a str, rename it.")
            df_DRAINAGE.rename(columns={col: int(col)}, inplace=True)
df_DRAINAGE.columns = df_DRAINAGE.columns.astype(str)

missing_DRAINAGE_rows = []
missing_DRAINAGE_cols = []

def table_DRAINAGE_0(R, DRDEST):
    col = DRDEST
    row = R
    if row not in df_DRAINAGE["index"].tolist():
        if row not in missing_DRAINAGE_rows:
            # print("Warning: row " + row + " is not in table DRAINAGE, return 0.0")
            missing_DRAINAGE_rows.append(row)
        return 0.0
    if col not in df_DRAINAGE.columns:
        if col not in missing_DRAINAGE_cols:
            # print("Warning: column " + col + " is not in table DRAINAGE, return 0.0")
            missing_DRAINAGE_cols.append(col)
        return 0.0
    value = df_DRAINAGE[col][df_DRAINAGE["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_DRAINAGE[col][df_DRAINAGE["index"].tolist().index(row)]
def table_DRAINAGE(R, DRDEST):
    return table_DRAINAGE_0(R, DRDEST)

# Table: municipal water abstraction per governorate (BCM)

df_MUNDEMG = pd.read_excel("tables/MUNDEMG.xlsx")
for col in df_MUNDEMG.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table MUNDEMG is a float, cast it to an int before casting it to a str, rename it.")
            df_MUNDEMG.rename(columns={col: int(col)}, inplace=True)
df_MUNDEMG.columns = df_MUNDEMG.columns.astype(str)

missing_MUNDEMG_rows = []
missing_MUNDEMG_cols = []

def table_MUNDEMG_0(R, IMP_MUNDEMG_1):
    col = IMP_MUNDEMG_1
    row = R
    if row not in df_MUNDEMG["index"].tolist():
        if row not in missing_MUNDEMG_rows:
            # print("Warning: row " + row + " is not in table MUNDEMG, return 0.0")
            missing_MUNDEMG_rows.append(row)
        return 0.0
    if col not in df_MUNDEMG.columns:
        if col not in missing_MUNDEMG_cols:
            # print("Warning: column " + col + " is not in table MUNDEMG, return 0.0")
            missing_MUNDEMG_cols.append(col)
        return 0.0
    value = df_MUNDEMG[col][df_MUNDEMG["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_MUNDEMG[col][df_MUNDEMG["index"].tolist().index(row)]
def table_MUNDEMG(R, IMP_MUNDEMG_1):
    return table_MUNDEMG_0(R, IMP_MUNDEMG_1)

# Table: regional desalination (BCM)

df_DESALR = pd.read_excel("tables/DESALR.xlsx")
for col in df_DESALR.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table DESALR is a float, cast it to an int before casting it to a str, rename it.")
            df_DESALR.rename(columns={col: int(col)}, inplace=True)
df_DESALR.columns = df_DESALR.columns.astype(str)

missing_DESALR_rows = []
missing_DESALR_cols = []

def table_DESALR_0(R, IMP_DESALR_1):
    col = IMP_DESALR_1
    row = R
    if row not in df_DESALR["index"].tolist():
        if row not in missing_DESALR_rows:
            # print("Warning: row " + row + " is not in table DESALR, return 0.0")
            missing_DESALR_rows.append(row)
        return 0.0
    if col not in df_DESALR.columns:
        if col not in missing_DESALR_cols:
            # print("Warning: column " + col + " is not in table DESALR, return 0.0")
            missing_DESALR_cols.append(col)
        return 0.0
    value = df_DESALR[col][df_DESALR["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_DESALR[col][df_DESALR["index"].tolist().index(row)]
def table_DESALR(R, IMP_DESALR_1):
    return table_DESALR_0(R, IMP_DESALR_1)

# Table: regional industrial Nile and deep groundwater abstraction (BCM)

df_INDDEMTAB = pd.read_excel("tables/INDDEMTAB.xlsx")
for col in df_INDDEMTAB.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table INDDEMTAB is a float, cast it to an int before casting it to a str, rename it.")
            df_INDDEMTAB.rename(columns={col: int(col)}, inplace=True)
df_INDDEMTAB.columns = df_INDDEMTAB.columns.astype(str)

missing_INDDEMTAB_rows = []
missing_INDDEMTAB_cols = []

def table_INDDEMTAB_0(R, IMP_INDDEMTAB_1):
    col = IMP_INDDEMTAB_1
    row = R
    if row not in df_INDDEMTAB["index"].tolist():
        if row not in missing_INDDEMTAB_rows:
            # print("Warning: row " + row + " is not in table INDDEMTAB, return 0.0")
            missing_INDDEMTAB_rows.append(row)
        return 0.0
    if col not in df_INDDEMTAB.columns:
        if col not in missing_INDDEMTAB_cols:
            # print("Warning: column " + col + " is not in table INDDEMTAB, return 0.0")
            missing_INDDEMTAB_cols.append(col)
        return 0.0
    value = df_INDDEMTAB[col][df_INDDEMTAB["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_INDDEMTAB[col][df_INDDEMTAB["index"].tolist().index(row)]
def table_INDDEMTAB(R, IMP_INDDEMTAB_1):
    return table_INDDEMTAB_0(R, IMP_INDDEMTAB_1)

# Table: fertilizer input by crop (kg nutrient per feddan)

df_FERTPUT = pd.read_excel("tables/FERTPUT.xlsx")
for col in df_FERTPUT.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table FERTPUT is a float, cast it to an int before casting it to a str, rename it.")
            df_FERTPUT.rename(columns={col: int(col)}, inplace=True)
df_FERTPUT.columns = df_FERTPUT.columns.astype(str)

missing_FERTPUT_rows = []
missing_FERTPUT_cols = []

def table_FERTPUT_0(XC, R, FERT):
    col = FERT
    row = XC + "." + R
    if row not in df_FERTPUT["index"].tolist():
        if row not in missing_FERTPUT_rows:
            # print("Warning: row " + row + " is not in table FERTPUT, return 0.0")
            missing_FERTPUT_rows.append(row)
        return 0.0
    if col not in df_FERTPUT.columns:
        if col not in missing_FERTPUT_cols:
            # print("Warning: column " + col + " is not in table FERTPUT, return 0.0")
            missing_FERTPUT_cols.append(col)
        return 0.0
    value = df_FERTPUT[col][df_FERTPUT["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_FERTPUT[col][df_FERTPUT["index"].tolist().index(row)]
def table_FERTPUT_1(XC, R, FERT):
    if R == "ALEX":
        return table_FERTPUT_0(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_0(XC, R, FERT)

def table_FERTPUT_2(XC, R, FERT):
    if R == "BEHAIRA":
        return table_FERTPUT_1(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_1(XC, R, FERT)

def table_FERTPUT_3(XC, R, FERT):
    if R == "NUBARIA":
        return table_FERTPUT_2(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_2(XC, R, FERT)

def table_FERTPUT_4(XC, R, FERT):
    if R == "GHARBIA":
        return table_FERTPUT_3(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_3(XC, R, FERT)

def table_FERTPUT_5(XC, R, FERT):
    if R == "KFRSHIK":
        return table_FERTPUT_4(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_4(XC, R, FERT)

def table_FERTPUT_6(XC, R, FERT):
    if R == "DAMIETA":
        return table_FERTPUT_5(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_5(XC, R, FERT)

def table_FERTPUT_7(XC, R, FERT):
    if R == "SHARKIA":
        return table_FERTPUT_6(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_6(XC, R, FERT)

def table_FERTPUT_8(XC, R, FERT):
    if R == "ISMALIA":
        return table_FERTPUT_7(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_7(XC, R, FERT)

def table_FERTPUT_9(XC, R, FERT):
    if R == "PRTSAID":
        return table_FERTPUT_8(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_8(XC, R, FERT)

def table_FERTPUT_10(XC, R, FERT):
    if R == "SUEZ":
        return table_FERTPUT_9(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_9(XC, R, FERT)

def table_FERTPUT_11(XC, R, FERT):
    if R == "MENUFIA":
        return table_FERTPUT_10(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_10(XC, R, FERT)

def table_FERTPUT_12(XC, R, FERT):
    if R == "QLYUBIA":
        return table_FERTPUT_11(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_11(XC, R, FERT)

def table_FERTPUT_13(XC, R, FERT):
    if R == "CAIRO":
        return table_FERTPUT_12(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_12(XC, R, FERT)

def table_FERTPUT_14(XC, R, FERT):
    if R == "MATRUH":
        return table_FERTPUT_13(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_13(XC, R, FERT)

def table_FERTPUT_15(XC, R, FERT):
    if R == "REDSEA":
        return table_FERTPUT_14(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_14(XC, R, FERT)

def table_FERTPUT_16(XC, R, FERT):
    if R == "NSINAI":
        return table_FERTPUT_15(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_15(XC, R, FERT)

def table_FERTPUT_17(XC, R, FERT):
    if R == "SSINAI":
        return table_FERTPUT_16(XC, "DAKHLIA", FERT)
    else:
        return table_FERTPUT_16(XC, R, FERT)

def table_FERTPUT_18(XC, R, FERT):
    if R == "GIZA":
        return table_FERTPUT_17(XC, "FAYOUM", FERT)
    else:
        return table_FERTPUT_17(XC, R, FERT)

def table_FERTPUT_19(XC, R, FERT):
    if R == "BNISUEF":
        return table_FERTPUT_18(XC, "FAYOUM", FERT)
    else:
        return table_FERTPUT_18(XC, R, FERT)

def table_FERTPUT_20(XC, R, FERT):
    if R == "MENIA":
        return table_FERTPUT_19(XC, "FAYOUM", FERT)
    else:
        return table_FERTPUT_19(XC, R, FERT)

def table_FERTPUT_21(XC, R, FERT):
    if R == "ASSUIT":
        return table_FERTPUT_20(XC, "ASWAN", FERT)
    else:
        return table_FERTPUT_20(XC, R, FERT)

def table_FERTPUT_22(XC, R, FERT):
    if R == "SUHAG":
        return table_FERTPUT_21(XC, "ASWAN", FERT)
    else:
        return table_FERTPUT_21(XC, R, FERT)

def table_FERTPUT_23(XC, R, FERT):
    if R == "QENA":
        return table_FERTPUT_22(XC, "ASWAN", FERT)
    else:
        return table_FERTPUT_22(XC, R, FERT)

def table_FERTPUT_24(XC, R, FERT):
    if R == "LUXOR":
        return table_FERTPUT_23(XC, "ASWAN", FERT)
    else:
        return table_FERTPUT_23(XC, R, FERT)

def table_FERTPUT_25(XC, R, FERT):
    if R == "NVALLEY":
        return table_FERTPUT_24(XC, "ASWAN", FERT)
    else:
        return table_FERTPUT_24(XC, R, FERT)

def table_FERTPUT_26(XC, R, FERT):
    if R == "TOSHKA":
        return table_FERTPUT_25(XC, "ASWAN", FERT)
    else:
        return table_FERTPUT_25(XC, R, FERT)

def table_FERTPUT(XC, R, FERT):
    return table_FERTPUT_26(XC, R, FERT)

# Table: distance from fertilizer supplier to region (km)

df_FERTDIST = pd.read_excel("tables/FERTDIST.xlsx")
for col in df_FERTDIST.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table FERTDIST is a float, cast it to an int before casting it to a str, rename it.")
            df_FERTDIST.rename(columns={col: int(col)}, inplace=True)
df_FERTDIST.columns = df_FERTDIST.columns.astype(str)

missing_FERTDIST_rows = []
missing_FERTDIST_cols = []

def table_FERTDIST_0(R, FERT):
    col = FERT
    row = R
    if row not in df_FERTDIST["index"].tolist():
        if row not in missing_FERTDIST_rows:
            # print("Warning: row " + row + " is not in table FERTDIST, return 0.0")
            missing_FERTDIST_rows.append(row)
        return 0.0
    if col not in df_FERTDIST.columns:
        if col not in missing_FERTDIST_cols:
            # print("Warning: column " + col + " is not in table FERTDIST, return 0.0")
            missing_FERTDIST_cols.append(col)
        return 0.0
    value = df_FERTDIST[col][df_FERTDIST["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_FERTDIST[col][df_FERTDIST["index"].tolist().index(row)]
def table_FERTDIST(R, FERT):
    return table_FERTDIST_0(R, FERT)

# Table: mechanization inputs (hour per feddan)

df_QMECH = pd.read_excel("tables/QMECH.xlsx")
for col in df_QMECH.columns:
    if isinstance(col, float):
        if col == col:
            # print("Warning: column " + str(col) + " in table QMECH is a float, cast it to an int before casting it to a str, rename it.")
            df_QMECH.rename(columns={col: int(col)}, inplace=True)
df_QMECH.columns = df_QMECH.columns.astype(str)

missing_QMECH_rows = []
missing_QMECH_cols = []

def table_QMECH_0(XC, R, MHP):
    col = MHP
    row = XC + "." + R
    if row not in df_QMECH["index"].tolist():
        if row not in missing_QMECH_rows:
            # print("Warning: row " + row + " is not in table QMECH, return 0.0")
            missing_QMECH_rows.append(row)
        return 0.0
    if col not in df_QMECH.columns:
        if col not in missing_QMECH_cols:
            # print("Warning: column " + col + " is not in table QMECH, return 0.0")
            missing_QMECH_cols.append(col)
        return 0.0
    value = df_QMECH[col][df_QMECH["index"].tolist().index(row)]
    if np.isnan(value):
        return 0.0
    else:
        return df_QMECH[col][df_QMECH["index"].tolist().index(row)]
def table_QMECH_1(XC, R, MHP):
    if R == "ALEX":
        return table_QMECH_0(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_0(XC, R, MHP)

def table_QMECH_2(XC, R, MHP):
    if R == "BEHAIRA":
        return table_QMECH_1(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_1(XC, R, MHP)

def table_QMECH_3(XC, R, MHP):
    if R == "NUBARIA":
        return table_QMECH_2(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_2(XC, R, MHP)

def table_QMECH_4(XC, R, MHP):
    if R == "GHARBIA":
        return table_QMECH_3(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_3(XC, R, MHP)

def table_QMECH_5(XC, R, MHP):
    if R == "KFRSHIK":
        return table_QMECH_4(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_4(XC, R, MHP)

def table_QMECH_6(XC, R, MHP):
    if R == "DAMIETA":
        return table_QMECH_5(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_5(XC, R, MHP)

def table_QMECH_7(XC, R, MHP):
    if R == "SHARKIA":
        return table_QMECH_6(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_6(XC, R, MHP)

def table_QMECH_8(XC, R, MHP):
    if R == "ISMALIA":
        return table_QMECH_7(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_7(XC, R, MHP)

def table_QMECH_9(XC, R, MHP):
    if R == "PRTSAID":
        return table_QMECH_8(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_8(XC, R, MHP)

def table_QMECH_10(XC, R, MHP):
    if R == "SUEZ":
        return table_QMECH_9(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_9(XC, R, MHP)

def table_QMECH_11(XC, R, MHP):
    if R == "MENUFIA":
        return table_QMECH_10(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_10(XC, R, MHP)

def table_QMECH_12(XC, R, MHP):
    if R == "QLYUBIA":
        return table_QMECH_11(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_11(XC, R, MHP)

def table_QMECH_13(XC, R, MHP):
    if R == "CAIRO":
        return table_QMECH_12(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_12(XC, R, MHP)

def table_QMECH_14(XC, R, MHP):
    if R == "MATRUH":
        return table_QMECH_13(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_13(XC, R, MHP)

def table_QMECH_15(XC, R, MHP):
    if R == "REDSEA":
        return table_QMECH_14(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_14(XC, R, MHP)

def table_QMECH_16(XC, R, MHP):
    if R == "NSINAI":
        return table_QMECH_15(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_15(XC, R, MHP)

def table_QMECH_17(XC, R, MHP):
    if R == "SSINAI":
        return table_QMECH_16(XC, "DAKHLIA", MHP)
    else:
        return table_QMECH_16(XC, R, MHP)

def table_QMECH_18(XC, R, MHP):
    if R == "GIZA":
        return table_QMECH_17(XC, "FAYOUM", MHP)
    else:
        return table_QMECH_17(XC, R, MHP)

def table_QMECH_19(XC, R, MHP):
    if R == "BNISUEF":
        return table_QMECH_18(XC, "FAYOUM", MHP)
    else:
        return table_QMECH_18(XC, R, MHP)

def table_QMECH_20(XC, R, MHP):
    if R == "MENIA":
        return table_QMECH_19(XC, "FAYOUM", MHP)
    else:
        return table_QMECH_19(XC, R, MHP)

def table_QMECH_21(XC, R, MHP):
    if R == "ASSUIT":
        return table_QMECH_20(XC, "ASWAN", MHP)
    else:
        return table_QMECH_20(XC, R, MHP)

def table_QMECH_22(XC, R, MHP):
    if R == "SUHAG":
        return table_QMECH_21(XC, "ASWAN", MHP)
    else:
        return table_QMECH_21(XC, R, MHP)

def table_QMECH_23(XC, R, MHP):
    if R == "QENA":
        return table_QMECH_22(XC, "ASWAN", MHP)
    else:
        return table_QMECH_22(XC, R, MHP)

def table_QMECH_24(XC, R, MHP):
    if R == "LUXOR":
        return table_QMECH_23(XC, "ASWAN", MHP)
    else:
        return table_QMECH_23(XC, R, MHP)

def table_QMECH_25(XC, R, MHP):
    if R == "NVALLEY":
        return table_QMECH_24(XC, "ASWAN", MHP)
    else:
        return table_QMECH_24(XC, R, MHP)

def table_QMECH_26(XC, R, MHP):
    if R == "TOSHKA":
        return table_QMECH_25(XC, "ASWAN", MHP)
    else:
        return table_QMECH_25(XC, R, MHP)

def table_QMECH(XC, R, MHP):
    return table_QMECH_26(XC, R, MHP)


# Parameter: crop yields at 2013-14 level (t p fed)
AVYIELD_data = helper.loadParameter("parameters/AVYIELD.xlsx")
def AVYIELD(model, XC, C):
    key = XC + "." + C
    if key in AVYIELD_data:
        return AVYIELD_data[key]
    return 0
# Parameter: slope of demand curve for crop commodity C rural
def BETACR(model, C):
    if ((C) in sets["CN"]):
        return (table_DEMDAT(C, "BASE-P") / table_DEMDAT(C, "HUMCONR") / table_DEMDAT(C, "PRIELASR"))
    return 0
# Parameter: slope of demand curve for crop commodity C urban
def BETACU(model, C):
    if ((C) in sets["CN"]):
        return (table_DEMDAT(C, "BASE-P") / table_DEMDAT(C, "HUMCONU") / table_DEMDAT(C, "PRIELASU"))
    return 0
# Parameter: correction factors for climate
CFC_data = helper.loadParameter("parameters/CFC.xlsx")
def CFC(model, R):
    key = R
    if key in CFC_data:
        return CFC_data[key]
    return 0
# Parameter: which FC can be used in which FEEDS based on FCMAX
def CFCTFMAP(model, C, FCTYPE, FEEDS):
    if table_FCMAX(C, FCTYPE, FEEDS):
        return 1.0
    return 0
# Parameter: crop water charges per crop-class (LE p m3)
CHRG_data = helper.loadParameter("parameters/CHRG.xlsx")
def CHRG(model, XCCROP):
    key = XCCROP
    if key in CHRG_data:
        return CHRG_data[key]
    return 0
# Parameter: consumer producer surplus (MLE)
def CPSUR(model, ):
    return (model.CPS.value * 1000.0)
# Parameter: CROPCHF(R)
CROPCHF_data = helper.loadParameter("parameters/CROPCHF.xlsx")
def CROPCHF(model, R):
    key = R
    if key in CROPCHF_data:
        return CROPCHF_data[key]
    return 0
# Parameter: marketing cost of dry commodity C (% of BASE-P)
def CSTMRKD(model, C):
    return (table_DEMDAT(C, "BASE-P") * scalars["MARKDRY"])
# Parameter: marketing cost of fresh commodity C (% of BASE-P)
def CSTMRKF(model, C):
    return (table_DEMDAT(C, "BASE-P") * scalars["MARKFRESH"])
# Parameter: cost of processing (LE p t processed input)
CSTPR_data = helper.loadParameter("parameters/CSTPR.xlsx")
def CSTPR(model, C):
    key = C
    if key in CSTPR_data:
        return CSTPR_data[key]
    return 0
# Parameter: cost of additional reclamation (LE p year p fed)
CSTRECL_data = helper.loadParameter("parameters/CSTRECL.xlsx")
def CSTRECL(model, R):
    key = R
    if key in CSTRECL_data:
        return CSTRECL_data[key]
    return 0
# Parameter: irrigation water salinity calculated by DELWAQ (ppm)
DELTASAL_data = helper.loadParameter("parameters/DELTASAL.xlsx")
def DELTASAL(model, R):
    key = R
    if key in DELTASAL_data:
        return DELTASAL_data[key]
    return 0
# Parameter: regional desalination (BCM)
def DESAL(model, R):
    return table_DESALR(R, "2021")
# Parameter: salinity of irrigation water (ppm)
ECW_data = helper.loadParameter("parameters/ECW.xlsx")
def ECW(model, R):
    key = R
    if key in ECW_data:
        return ECW_data[key]
    return 0
# Parameter: energy content of ferilizers (MJ per t)
EFERTCON_data = helper.loadParameter("parameters/EFERTCON.xlsx")
def EFERTCON(model, FERT):
    key = FERT
    if key in EFERTCON_data:
        return EFERTCON_data[key]
    return 0
# Parameter: energy for processing of commodities (MJ p t input)
EPROCESS_data = helper.loadParameter("parameters/EPROCESS.xlsx")
def EPROCESS(model, CIP):
    key = CIP
    if key in EPROCESS_data:
        return EPROCESS_data[key]
    return 0
# Parameter: farm family heads (000)
def FARMERS(model, R):
    return table_POPULATION(R, "FAR")
# Parameter: field efficiency of irrigation (fraction)
FEFF_data = helper.loadParameter("parameters/FEFF.xlsx")
def FEFF(model, R):
    key = R
    if key in FEFF_data:
        return FEFF_data[key]
    return 0
# Parameter: distribution of hisorical areas over WE ME ED VA DGW and TOT (ha);
def HAREASDI(model, XC, param_1):
    if param_1 == "TOTAL":
        return (HAREASDI(model, XC, "WESTDEL") + HAREASDI(model, XC, "MIDDEL") + HAREASDI(model, XC, "EASTDEL") + HAREASDI(model, XC, "VALLEY") + HAREASDI(model, XC, "DEEPGW"))
    if param_1 == "DEEPGW":
        return (sum([table_HAREAS(XC, R) for R in sets["R"] if ((R) in sets["DGW"])]) * 1000.0 * 0.42)
    if param_1 == "VALLEY":
        return (sum([table_HAREAS(XC, R) for R in sets["R"] if ((R) in sets["VAR"])]) * 1000.0 * 0.42)
    if param_1 == "EASTDEL":
        return (sum([table_HAREAS(XC, R) for R in sets["R"] if ((R) in sets["EDR"])]) * 1000.0 * 0.42)
    if param_1 == "MIDDEL":
        return (sum([table_HAREAS(XC, R) for R in sets["R"] if ((R) in sets["MDR"])]) * 1000.0 * 0.42)
    if param_1 == "WESTDEL":
        return (sum([table_HAREAS(XC, R) for R in sets["R"] if ((R) in sets["WDR"])]) * 1000.0 * 0.42)
    return 0
# Parameter: active rural plus urban human consumption;
def HCOM(model, C):
    return (table_DEMDAT(C, "HUMCONR") + table_DEMDAT(C, "HUMCONU"))
# Parameter: irrigation conveyance and distribution efficiency (fraction)
IEFF_data = helper.loadParameter("parameters/IEFF.xlsx")
def IEFF(model, R):
    key = R
    if key in IEFF_data:
        return IEFF_data[key]
    return 0
# Parameter: regional industrial water demand (BCM)
def INDDEM(model, R):
    return table_INDDEMTAB(R, "2021")
# Parameter: industrial return factors
INDRET_data = helper.loadParameter("parameters/INDRET.xlsx")
def INDRET(model, R):
    key = R
    if key in INDRET_data:
        return INDRET_data[key]
    return 0
# Parameter: Ky yield response to water factors
KY_data = helper.loadParameter("parameters/KY.xlsx")
def KY(model, XC):
    key = XC
    if key in KY_data:
        return KY_data[key]
    return 0
# Parameter: labor for processing or packaging(md p t processed input)
LABPR_data = helper.loadParameter("parameters/LABPR.xlsx")
def LABPR(model, CIP):
    key = CIP
    if key in LABPR_data:
        return LABPR_data[key]
    return 0
# Parameter: labor req of crop act XC and WI (md p fed)
def LABREQC(model, XC, PT, R, TM, WI):
    if WI == "RED30":
        return (table_LABREQC1(XC, PT, R, TM) * 0.78)
    if WI == "RED25":
        return (table_LABREQC1(XC, PT, R, TM) * 0.8)
    if WI == "RED20":
        return (table_LABREQC1(XC, PT, R, TM) * 0.83)
    if WI == "RED15":
        return (table_LABREQC1(XC, PT, R, TM) * 0.85)
    if WI == "RED10":
        return (table_LABREQC1(XC, PT, R, TM) * 0.9)
    if WI == "RED05":
        return (table_LABREQC1(XC, PT, R, TM) * 0.95)
    if WI == "HI":
        return (table_LABREQC1(XC, PT, R, TM) * 1.0)
    return 0
# Parameter: regional and monthly shadow prices of labour (LE p day)
def LABSHAD(model, R, TM):
    if ((R) in sets["RL"]):
        return (model.dual[model.LABBAL[R, TM]] * 1000000.0)
    return 0
# Parameter: regional shadow prices of land (LE p fed)
def LANDSHAD(model, R):
    if ((R) in sets["RL"]):
        return (max(model.dual[model.LANDCON[R, "JAN"]], model.dual[model.LANDCON[R, "FEB"]], model.dual[model.LANDCON[R, "MAR"]], model.dual[model.LANDCON[R, "APR"]], model.dual[model.LANDCON[R, "MAY"]], model.dual[model.LANDCON[R, "JUN"]], model.dual[model.LANDCON[R, "JUL"]], model.dual[model.LANDCON[R, "AUG"]], model.dual[model.LANDCON[R, "SEP"]], model.dual[model.LANDCON[R, "OCT"]], model.dual[model.LANDCON[R, "NOV"]], model.dual[model.LANDCON[R, "DEC"]]) * 1000000.0)
    return 0
# Parameter: potential area for reclamation (000fed)
def LNDRECL(model, R):
    return 0.0
# Parameter: land req of crop activity XC (fed p fed)
def LNDREQ(model, XC, PT, R, TM):
    return table_LNDREQ(XC, PT, R, TM)
# Parameter: regional municipal return factors
MUNRET_data = helper.loadParameter("parameters/MUNRET.xlsx")
def MUNRET(model, R):
    key = R
    if key in MUNRET_data:
        return MUNRET_data[key]
    return 0
# Parameter: export price of commodity C (LE p t)
def PEXPC(model, C):
    return table_DEMDAT(C, "EXP-P")
# Parameter: import price of commodity C (LE p t)
def PIMPC(model, C):
    return table_DEMDAT(C, "IMP-P")
# Parameter: proportion of water from HAD release used for agriculture per nile governorate
PROPDIVA_data = helper.loadParameter("parameters/PROPDIVA.xlsx")
def PROPDIVA(model, R):
    key = R
    if key in PROPDIVA_data:
        return PROPDIVA_data[key]
    return 0
# Parameter: agro processing effort by commodity and region (t)
def QAGPROCES(model, param_0, param_1):
    if param_0 == "EGYPT" and param_1 == "TOTAL":
        return sum([QAGPROCES(model, R, CIP) for R in sets["R"] for CIP in sets["CIP"]])
    R = param_0
    if param_1 == "TOTAL":
        return sum([QAGPROCES(model, R, CIP) for CIP in sets["CIP"]])
    CIP = param_1
    if param_0 == "EGYPT":
        return sum([QAGPROCES(model, R, CIP) for R in sets["R"]])
    R = param_0
    CIP = param_1
    if ((R) in sets["RL"]):
        return model.QPRDC[CIP, R].value
    return 0
# Parameter: fertilizer input by region and crop (t)
def QFERT(model, param_0, param_1, FERT):
    if param_0 == "EGYPT" and param_1 == "TOTAL":
        return sum([QFERT(model, R, XC, FERT) for R in sets["R"] for XC in sets["XC"]])
    R = param_0
    if param_1 == "TOTAL":
        return sum([QFERT(model, R, XC, FERT) for XC in sets["XC"]])
    XC = param_1
    if param_0 == "EGYPT":
        return sum([QFERT(model, R, XC, FERT) for R in sets["R"]])
    R = param_0
    XC = param_1
    if ((R) in sets["RL"]):
        return sum([(model.XCROP[XC, PT, WI, R].value * table_FERTPUT(XC, R, FERT)) for PT in sets["PT"] for WI in sets["WI"]])
    return 0
# Parameter: land supply in region R (000fed)
def QLNDSUP(model, R):
    return table_LAND(R, "MALR21")
# Parameter: total mechanization input by crop and region (000hour)
def QTMECH(model, param_0, param_1):
    if param_0 == "EGYPT" and param_1 == "TOTAL":
        return sum([QTMECH(model, R, XC) for R in sets["R"] for XC in sets["XC"]])
    R = param_0
    if param_1 == "TOTAL":
        return sum([QTMECH(model, R, XC) for XC in sets["XC"]])
    XC = param_1
    if param_0 == "EGYPT":
        return sum([QTMECH(model, R, XC) for R in sets["R"]])
    R = param_0
    XC = param_1
    if ((R) in sets["RL"]):
        return sum([(model.XCROP[XC, PT, WI, R].value * sum([table_QMECH(XC, R, MHP) for MHP in sets["MHP"]])) for PT in sets["PT"] for WI in sets["WI"]])
    return 0
# Parameter: effective rainfall for each crop and pl time (m3 per feddan)
def RAINFALL(model, XC, PT, R):
    return table_RAINFALL(XC, PT, R)
# Parameter: regional livestock activity (000 prod units)
def REPCAN(model, param_0, param_1):
    XA = param_0
    if param_1 == "EGYPT":
        return sum([REPCAN(model, XA, R) for R in sets["R"]])
    XA = param_0
    R = param_1
    return sum([model.XLIVE[XA, M, R].value for M in sets["M"]])
# Parameter: commodity exports (000t)
def REPEXP(model, C, param_1):
    if param_1 == "EGYPT":
        return sum([model.QEXPC[C, R].value for R in sets["R"]])
    return 0
# Parameter: feed availability (000t DM)
def REPFEED(model, FEEDS, param_1):
    if param_1 == "EGYPT":
        return sum([REPFEED(model, FEEDS, R) for R in sets["R"]])
    R = param_1
    return model.FEEDAV[FEEDS, R].value
# Parameter: feed availability per type (000t DM)
def REPFEED1(model, R, C, FCTYPE):
    return sum([model.FEEDCOMP[FEEDS, R, C, FCTYPE].value for FEEDS in sets["FEEDS"]])
# Parameter: commodity imports (000t)
def REPIMP(model, C, param_1):
    if param_1 == "EGYPT":
        return sum([model.QIMPC[C, R].value for R in sets["R"]])
    return 0
# Parameter: regional production of livestock commodities (000t)
def REPPRODA(model, C, param_1):
    if param_1 == "EGYPT":
        return sum([model.QPRDA[C, R].value for R in sets["R"]])
    R = param_1
    return model.QPRDA[C, R].value
# Parameter: regional production of crop commodities (000t)
def REPPRODC(model, param_0, param_1):
    C = param_0
    if param_1 == "EGYPT":
        return sum([model.QPRDC[C, R].value for R in sets["R"]])
    C = param_0
    R = param_1
    return model.QPRDC[C, R].value
# Parameter: water charges and pumping costs (MLE)
def REPWATCHAR(model, param_0):
    if param_0 == "EGYPT":
        return (model.TWATCOST.value * 1000.0)
    return 0
# Parameter: rural population in base year (000capita)
def RURPOPC(model, ):
    return sum([table_POPULATION(R, "RUR21") for R in sets["R"] if ((R) in sets["RL"])])
# Parameter: seed requirement of crop commodities (fraction)
SEED_data = helper.loadParameter("parameters/SEED.xlsx")
def SEED(model, C):
    key = C
    if key in SEED_data:
        return SEED_data[key]
    return 0
# Parameter: total regional population in base year (000capita)
def TOT21(model, R):
    return (table_POPULATION(R, "URB21") + table_POPULATION(R, "RUR21"))
# Parameter: total regional population in 2525 high (000capita)
def TOT25H(model, R):
    return (table_POPULATION(R, "URB25H") + table_POPULATION(R, "RUR25H"))
# Parameter: total regional population in 2525 medium (000capita)
def TOT25L(model, R):
    return (table_POPULATION(R, "URB25L") + table_POPULATION(R, "RUR25L"))
# Parameter: total regional population in 2525 medium (000capita)
def TOT25M(model, R):
    return (table_POPULATION(R, "URB25M") + table_POPULATION(R, "RUR25M"))
# Parameter: total regional population in 2030 high (000capita)
def TOT30H(model, R):
    return (table_POPULATION(R, "URB30H") + table_POPULATION(R, "RUR30H"))
# Parameter: total regional population in 2030 low (000capita)
def TOT30L(model, R):
    return (table_POPULATION(R, "URB30L") + table_POPULATION(R, "RUR30L"))
# Parameter: total regional population in 2030 medium (000capita)
def TOT30M(model, R):
    return (table_POPULATION(R, "URB30M") + table_POPULATION(R, "RUR30M"))
# Parameter: total regional population in 2035 high (000capita)
def TOT35H(model, R):
    return (table_POPULATION(R, "URB35H") + table_POPULATION(R, "RUR35H"))
# Parameter: total regional population in 2035 medium (000capita)
def TOT35M(model, R):
    return (table_POPULATION(R, "URB35M") + table_POPULATION(R, "RUR35M"))
# Parameter: total regional population in 2037 high (000capita)
def TOT37H(model, R):
    return (table_POPULATION(R, "URB37H") + table_POPULATION(R, "RUR37H"))
# Parameter: total regional population in 2037 low (000capita)
def TOT37L(model, R):
    return (table_POPULATION(R, "URB37L") + table_POPULATION(R, "RUR37L"))
# Parameter: total regional population in 2037 medium (000capita)
def TOT37M(model, R):
    return (table_POPULATION(R, "URB37M") + table_POPULATION(R, "RUR37M"))
# Parameter: urban population in base year (000capita)
def URBPOPC(model, ):
    return sum([table_POPULATION(R, "URB21") for R in sets["R"] if ((R) in sets["RL"])])
# Parameter: waste of crop commodities (fraction)
WASTE_data = helper.loadParameter("parameters/WASTE.xlsx")
def WASTE(model, C):
    key = C
    if key in WASTE_data:
        return WASTE_data[key]
    return 0
# Parameter: national shadow price for water (LE p m3)
def WATERSHAD(model, ):
    return model.dual[model.NILEBAL]
# Parameter: avg male wage by region & time TM (LE p day)
def WAVG(model, R, TM):
    return table_WAVG(R, TM)
# Parameter: water deficit
WDEF_data = helper.loadParameter("parameters/WDEF.xlsx")
def WDEF(model, WI):
    key = WI
    if key in WDEF_data:
        return WDEF_data[key]
    return 0
# Parameter: xx(r);
def XX(model, R):
    if ((R) in sets["RL"]):
        return (table_DRAINAGE(R, "TONILE") + table_DRAINAGE(R, "TODRAIN") + table_DRAINAGE(R, "TOSINK"))
    return 0
# Parameter: crop yields (t p fed)
def YIELD0(model, XC, C, R):
    if XC == "WHEAT1" and C == "BRAN":
        return (0.2 * YIELD0(model, "WHEAT1", "WHEAT", R))
    if XC == "WHEAT1" and C == "WHEATF":
        return (0.8 * YIELD0(model, "WHEAT1", "WHEAT", R))
    if XC == "SBEAN1" and C == "VEG-OIL":
        return (0.19 * YIELD0(model, "SBEAN1", "SOYACAKE", R))
    if XC == "SBEAN1" and C == "SOYACAKE":
        return (0.78 * YIELD0(model, "SBEAN1", "SOYBEAN", R))
    if XC == "SCANE1" and C == "SCANEMOL":
        return (0.04 * YIELD0(model, "SCANE1", "SGCANE", R))
    if XC == "SCANE1" and C == "SUGAR":
        return (0.11 * YIELD0(model, "SCANE1", "SGCANE", R))
    if XC == "SBEET1" and C == "SBEETPULP":
        return (0.05 * YIELD0(model, "SBEET1", "SGBEET", R))
    if XC == "SBEET1" and C == "SBEETMOL":
        return (0.02 * YIELD0(model, "SBEET1", "SGBEET", R))
    if XC == "SBEET1" and C == "SUGAR":
        return (0.14 * YIELD0(model, "SBEET1", "SGBEET", R))
    if XC == "SESAME1" and C == "VEG-OIL":
        return (0.315 * YIELD0(model, "SESAME1", "SESAME", R))
    if XC == "SESAME1" and C == "FLSECAKE":
        return (0.685 * YIELD0(model, "SESAME1", "SESAME", R))
    if XC == "SDELS1" and C == "COTSCAKE":
        return (0.4 * YIELD0(model, "SDELS1", "SEEDELS", R))
    if XC == "SDELS1" and C == "CTONELS":
        return (0.35 * YIELD0(model, "SDELS1", "SEEDELS", R))
    if XC == "SDELS1" and C == "VEG-OIL":
        return (0.1 * YIELD0(model, "SDELS1", "SEEDELS", R))
    if XC == "SDLS1" and C == "COTSCAKE":
        return (0.4 * YIELD0(model, "SDLS1", "SEEDLS", R))
    if XC == "SDLS1" and C == "CTONLS":
        return (0.35 * YIELD0(model, "SDLS1", "SEEDLS", R))
    if XC == "SDLS1" and C == "VEG-OIL":
        return (0.1 * YIELD0(model, "SDLS1", "SEEDLS", R))
    if XC == "PADDY1" and C == "HUSK":
        return (0.2 * YIELD0(model, "PADDY1", "PADDY", R))
    if XC == "PADDY1" and C == "BRAN":
        return (0.1 * YIELD0(model, "PADDY1", "PADDY", R))
    if XC == "PADDY1" and C == "RICE":
        return (0.7 * YIELD0(model, "PADDY1", "PADDY", R))
    if XC == "GNUT1" and C == "VEG-OIL":
        return (0.276 * YIELD0(model, "GNUT1", "GNUTCAKE", R))
    if XC == "GNUT1" and C == "GNUTCAKE":
        return (0.463 * YIELD0(model, "GNUT1", "GRDNUT", R))
    if XC == "FLAX1" and C == "VEG-OIL":
        return (0.051 * YIELD0(model, "FLAX1", "FLAX", R))
    if XC == "FLAX1" and C == "FLSECAKE":
        return (0.11 * YIELD0(model, "FLAX1", "FLAX", R))
    if XC == "FLAX1" and C == "FXFIB":
        return (0.2 * YIELD0(model, "FLAX1", "FLAX", R))
    if XC == "WHEAT1" and C == "BRAN":
        return (0.1 * YIELD0(model, "WHEAT1", "WHEAT", R))
    if XC == "WHEAT1" and C == "WHEATSTR":
        return (1.2 * YIELD0(model, "WHEAT1", "WHEAT", R))
    if XC == "SBEAN1" and C == "SOYAFOD":
        return (1.0 * YIELD0(model, "SBEAN1", "SOYBEAN", R))
    if XC == "SCANE1" and C == "SCANEFOD":
        return (0.09 * YIELD0(model, "SCANE1", "SGCANE", R))
    if XC == "SBEET1" and C == "SBEETFOD":
        return (0.5 * YIELD0(model, "SBEET1", "SGBEET", R))
    if XC == "SDELS1" and C == "COTSTA":
        return (0.4 * YIELD0(model, "SDELS1", "SEEDELS", R))
    if XC == "SDLS1" and C == "COTSTA":
        return (0.4 * YIELD0(model, "SDLS1", "SEEDLS", R))
    if XC == "PADDY1" and C == "BRAN":
        return (0.1 * YIELD0(model, "PADDY1", "PADDY", R))
    if XC == "PADDY1" and C == "RICESTR":
        return (0.95 * YIELD0(model, "PADDY1", "PADDY", R))
    if XC == "VEGETN1" and C == "VEGETFOD":
        return (0.3 * YIELD0(model, "VEGETN1", "VEGET", R))
    if XC == "VEGETW1" and C == "VEGETFOD":
        return (0.3 * YIELD0(model, "VEGETW1", "VEGET", R))
    if XC == "VEGETS1" and C == "VEGETFOD":
        return (0.3 * YIELD0(model, "VEGETS1", "VEGET", R))
    if XC == "MAIZES1" and C == "MAIZESTA":
        return (1.2 * YIELD0(model, "MAIZES1", "MAIZE", R))
    if XC == "MAIZEN1" and C == "MAIZESTA":
        return (1.2 * YIELD0(model, "MAIZEN1", "MAIZE", R))
    if XC == "LENTIL1" and C == "LENTILFOD":
        return (1.0 * YIELD0(model, "LENTIL1", "LENTIL", R))
    if XC == "GNUT1" and C == "GNUTSH":
        return (0.4 * YIELD0(model, "GNUT1", "GRDNUT", R))
    if XC == "GNUT1" and C == "GRDNUTFOD":
        return (1.0 * YIELD0(model, "GNUT1", "GRDNUT", R))
    if XC == "FBEAN1" and C == "FBEANFOD":
        return (1.3 * YIELD0(model, "FBEAN1", "FBEAN", R))
    if XC == "BARLEY1" and C == "BARLEYSTR":
        return (1.2 * YIELD0(model, "BARLEY1", "BARLEY", R))
    if (table_RXCMAP(R, XC)):
        return table_YIELD(XC, C, R)
    return 0
# Parameter: intercept of demand curve for crop commodity C rural
def ALPHACR(model, C):
    if ((C) in sets["CN"]):
        return (table_DEMDAT(C, "BASE-P") - (BETACR(model, C) * table_DEMDAT(C, "HUMCONR")))
    return 0
# Parameter: intercept of demand curve for crop commodity C urban
def ALPHACU(model, C):
    if ((C) in sets["CN"]):
        return (table_DEMDAT(C, "BASE-P") - (BETACU(model, C) * table_DEMDAT(C, "HUMCONU")))
    return 0
# Parameter: total agricultural area in base year (000fed)
def BASEAREA(model, ):
    return sum([QLNDSUP(model, R) for R in sets["R"]])
# Parameter: crop-based water charge (LE p m3);
def CROPCHXC(model, XC):
    if (("XC5001", XC) in sets["MAPXCCROP"]):
        return CHRG(model, "XC5001")
    if (("XC5000", XC) in sets["MAPXCCROP"]):
        return CHRG(model, "XC5000")
    if (("XC3500", XC) in sets["MAPXCCROP"]):
        return CHRG(model, "XC3500")
    if (("XC2000", XC) in sets["MAPXCCROP"]):
        return CHRG(model, "XC2000")
    return 0
# Parameter: cost of livestock farm manager (LE p y);
def CSTFRMMAN(model, R):
    return (sum([WAVG(model, R, TM) for TM in sets["TM"]]) / 12.0 * 3.0)
# Parameter: demand-supply balance of commodities (000t)
def DEMSUPBAL(model, C, param_1):
    if param_1 == "BALANCE" and ((C) in sets["CN"]):
        return round((DEMSUPBAL(model, C, "NETPROD") - DEMSUPBAL(model, C, "HCONSUMP") - DEMSUPBAL(model, C, "ACONSUMP") - DEMSUPBAL(model, C, "EXPORT") + DEMSUPBAL(model, C, "IMPORT") + DEMSUPBAL(model, C, "REGTRADE")))
    if param_1 == "REGTRADE" and ((C) in sets["CN"]):
        return round(sum([((model.REGTRADE[C, R].value) if (((C) in sets["CTR"])) else 0) for R in sets["R"]]))
    if param_1 == "ACONSUMP" and ((C) in sets["CN"]):
        return sum([((model.QCNSCL[C, R].value) if (((C) in sets["CHL"])) else 0) for R in sets["R"]])
    if param_1 == "HCONSUMP" and ((C) in sets["CN"]):
        return sum([((model.QCNSC[C, R].value) if (((C) in sets["CN"])) else 0) for R in sets["R"]])
    if param_1 == "EXPORT" and ((C) in sets["CN"]):
        return sum([((model.QEXPC[C, R].value) if (PEXPC(model, C)) else 0) for R in sets["R"]])
    if param_1 == "IMPORT" and ((C) in sets["CN"]):
        return sum([(((model.QIMPC[C, R].value) if (PIMPC(model, C)) else 0) * ((1.0 - WASTE(model, C)))) for R in sets["R"]])
    if param_1 == "NETPROD" and ((C) in sets["CN"]):
        return (sum([(((model.QPRDC[C, R].value) if ((((((C) in sets["CC"])) if (((R, C) in sets["RCMAP"])) else 0))) else 0) * ((1.0 - ((WASTE(model, C) + SEED(model, C)))))) for R in sets["R"]]) + sum([((model.QPRDA[C, R].value) if (((C) in sets["CA"])) else 0) for R in sets["R"]]))
    return 0
# Parameter: total desalination (BCM)
def DESALTOT(model, ):
    return sum([DESAL(model, R) for R in sets["R"]])
# Parameter: duration of crops (days);
def DURATION(model, XC, PT, R):
    if PT == "O" and table_RXCMAP(R, XC):
        return (sum([LNDREQ(model, XC, "O", R, TM) for TM in sets["TM"]]) * 30.42)
    return 0
# Parameter: energy use for agro processing by commodity and region (MJ)
def EAGPROCES(model, param_0, param_1):
    if param_0 == "EGYPT" and param_1 == "TOTAL":
        return sum([EAGPROCES(model, R, CIP) for R in sets["R"] for CIP in sets["CIP"]])
    R = param_0
    if param_1 == "TOTAL":
        return sum([EAGPROCES(model, R, CIP) for CIP in sets["CIP"]])
    CIP = param_1
    if param_0 == "EGYPT":
        return sum([EAGPROCES(model, R, CIP) for R in sets["R"]])
    R = param_0
    CIP = param_1
    if ((R) in sets["RL"]):
        return (QAGPROCES(model, R, CIP) * EPROCESS(model, CIP) * 1000.0)
    return 0
# Parameter: energy use to transport regionally traded commodities (MJ)
def ECOM(model, param_0, param_1):
    if param_0 == "EGYPT" and param_1 == "TOTAL":
        return sum([ECOM(model, R, C) for R in sets["R"] for C in sets["C"]])
    C = param_1
    if param_0 == "TOTAL":
        return sum([ECOM(model, R, C) for R in sets["R"]])
    R = param_0
    if param_1 == "TOTAL":
        return sum([ECOM(model, R, C) for C in sets["C"]])
    R = param_0
    C = param_1
    if ((C) in sets["CTR"]):
        return (REPPRODC(model, C, R) * 1000.0 * scalars["COMDIST"] * scalars["FUELEFF"])
    return 0
# Parameter: total effective rainfall deep groundwater regions (BCM)
def EFECTRAIND(model, ):
    return (sum([(model.XCROP[XC, PT, WI, R].value * RAINFALL(model, XC, PT, R)) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["DGW"])]) / 1000000.0)
# Parameter: total effective rainfall nile regions (BCM)
def EFECTRAINN(model, ):
    return (sum([(model.XCROP[XC, PT, WI, R].value * RAINFALL(model, XC, PT, R)) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["RSW"])]) / 1000000.0)
# Parameter: regional effective rainfall (BCM)
def EFECTRAINR(model, R):
    if ((R) in sets["RL"]):
        return (sum([(model.XCROP[XC, PT, WI, R].value * RAINFALL(model, XC, PT, R)) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"]]) / 1000000.0)
    return 0
# Parameter: energy content of fertilizer input by region and crop (MJ)
def EFERT(model, param_0, param_1, FERT):
    if param_0 == "EGYPT" and param_1 == "TOTAL":
        return sum([EFERT(model, R, XC, FERT) for R in sets["R"] for XC in sets["XC"]])
    R = param_0
    if param_1 == "TOTAL":
        return sum([EFERT(model, R, XC, FERT) for XC in sets["XC"]])
    XC = param_1
    if param_0 == "EGYPT":
        return sum([EFERT(model, R, XC, FERT) for R in sets["R"]])
    R = param_0
    XC = param_1
    if ((R) in sets["RL"]):
        return sum([(model.XCROP[XC, PT, WI, R].value * table_FERTPUT(XC, R, FERT) * EFERTCON(model, FERT)) for PT in sets["PT"] for WI in sets["WI"]])
    return 0
# Parameter: energy use of mechanization input by crop and region (MJ)
def ETMECH(model, param_0, param_1):
    if param_0 == "EGYPT" and param_1 == "TOTAL":
        return sum([ETMECH(model, R, XC) for R in sets["R"] for XC in sets["XC"]])
    XC = param_1
    if param_0 == "TOTAL":
        return sum([ETMECH(model, R, XC) for R in sets["R"]])
    R = param_0
    if param_1 == "TOTAL":
        return sum([ETMECH(model, R, XC) for XC in sets["XC"]])
    R = param_0
    XC = param_1
    if ((R) in sets["RL"]):
        return (QTMECH(model, R, XC) * scalars["FUELMECH"] * 1000.0)
    return 0
# Parameter: regional municipal water demand (BCM)
def MUNDEM(model, R):
    if ((R) in sets["RL"]):
        return (table_MUNDEMG(R, "2021") - DESAL(model, R))
    return table_MUNDEMG(R, "2021")
# Parameter: gross water distr. Egypt not corrected for climate and salinity (m3 p f)
def NONSCORE(model, ):
    return (sum([model.DIVA[R].value for R in sets["R"] if ((((QLNDSUP(model, R) + LNDRECL(model, R))) != 0.0))]) / sum([((QLNDSUP(model, R) + LNDRECL(model, R))) for R in sets["R"]]) * 1000000.0)
# Parameter: gross water distr. not corrected for climate and salinity (m3 p f)
def NONSCORR(model, R):
    if (((((R) in sets["RL"])) if (((((QLNDSUP(model, R) + LNDRECL(model, R))) != 0.0))) else 0)):
        return (model.DIVA[R].value / ((QLNDSUP(model, R) + LNDRECL(model, R))) * 1000000.0)
    return 0
# Parameter: monthly labor supply by region R (md)
def QLABSUP(model, R):
    return (FARMERS(model, R) * 1.25 * scalars["WDM"])
# Parameter: regional cropped area (000fed)
def REPCA(model, param_0, param_1):
    if param_0 == "TOTAL" and param_1 == "MALR":
        return sum([table_HAREAS(XC, "SEA") for XC in sets["XC"]])
    if param_0 == "INTENSNL" and param_1 == "EGYPT":
        return (((sum([REPCA(model, XC, R) for XC in sets["XC"] for R in sets["R"] if ((((not (((XC) in sets["PXC"])))) if ((((R) in sets["RSW"]))) else 0))]) + (sum([REPCA(model, XC, R) for XC in sets["XC"] for R in sets["R"] if (((((XC) in sets["PXC"])) if ((((R) in sets["RSW"]))) else 0))]) * 2.0))) / sum([(((QLNDSUP(model, R)) if ((((R) in sets["RSW"]))) else 0) + (((LNDRECL(model, R)) if ((((R) in sets["RSW"]))) else 0) * scalars["GROSNETLD"])) for R in sets["R"]]))
    R = param_1
    if param_0 == "INTENSNL" and (((((R) in sets["RSW"])) if (((((QLNDSUP(model, R) + LNDRECL(model, R))) != 0.0))) else 0)):
        return (((sum([REPCA(model, XC, R) for XC in sets["XC"] if ((not (((XC) in sets["PXC"]))))]) + (sum([REPCA(model, XC, R) for XC in sets["XC"] if ((XC) in sets["PXC"])]) * 2.0))) / ((QLNDSUP(model, R) + LNDRECL(model, R))) * scalars["GROSNETLD"])
    if param_0 == "INTENSTY" and param_1 == "EGYPT":
        return (((sum([REPCA(model, XC, R) for XC in sets["XC"] for R in sets["R"] if ((not (((XC) in sets["PXC"]))))]) + (sum([REPCA(model, XC, R) for XC in sets["XC"] for R in sets["R"] if ((XC) in sets["PXC"])]) * 2.0))) / sum([(QLNDSUP(model, R) + (LNDRECL(model, R) * scalars["GROSNETLD"])) for R in sets["R"]]))
    R = param_1
    if param_0 == "INTENSTY" and (((((R) in sets["RL"])) if (((((QLNDSUP(model, R) + LNDRECL(model, R))) != 0.0))) else 0)):
        return (((sum([REPCA(model, XC, R) for XC in sets["XC"] if ((not (((XC) in sets["PXC"]))))]) + (sum([REPCA(model, XC, R) for XC in sets["XC"] if ((XC) in sets["PXC"])]) * 2.0))) / ((QLNDSUP(model, R) + LNDRECL(model, R))) * scalars["GROSNETLD"])
    if param_0 == "TOTAL" and param_1 == "EGYPT":
        return sum([REPCA(model, "TOTAL", R) for R in sets["R"]])
    XC = param_0
    if param_1 == "MALR":
        return table_HAREAS(XC, "SEA")
    R = param_1
    if param_0 == "TOTAL" and ((R) in sets["RL"]):
        return sum([REPCA(model, XC, R) for XC in sets["XC"]])
    XC = param_0
    if param_1 == "EGYPT":
        return sum([REPCA(model, XC, R) for R in sets["R"]])
    XC = param_0
    R = param_1
    if ((R) in sets["RL"]):
        return sum([model.XCROP[XC, PT, WI, R].value for PT in sets["PT"] for WI in sets["WI"]])
    return 0
# Parameter: regional cropping per water level (000fed)
def REPCA1(model, R, param_1, param_2, WI):
    XC = param_1
    PT = param_2
    return sum([(((model.XCROP[XC, PT, WI, R].value) if (table_RXCMAP(R, XC)) else 0) * LNDREQ(model, XC, PT, R, TM)) for TM in sets["TM"]])
# Parameter: regional cropping per month (000fed)
def REPCA2(model, R, param_1, param_2, TM):
    if param_1 == "%FALLOW" and param_2 == "*" and ((REPCA2(model, R, "QLNDSUP", "*", TM) != 0.0)):
        return round(((REPCA2(model, R, "FALLOW", "*", TM)) / REPCA2(model, R, "QLNDSUP", "*", TM) * 100.0), int(1.0))
    if param_1 == "QLNDSUP" and param_2 == "*":
        return (QLNDSUP(model, R) + LNDRECL(model, R))
    if param_1 == "TOTAL" and param_2 == "*":
        return (REPCA2(model, R, "S-TOTAL", "*", TM) + REPCA2(model, R, "FALLOW", "*", TM))
    if param_1 == "FALLOW" and param_2 == "*":
        return model.FALLOW[R, TM].value
    if param_1 == "S-TOTAL" and param_2 == "*":
        return sum([(model.XCROP[XC, PT, WI, R].value * LNDREQ(model, XC, PT, R, TM)) for XC in sets["XC"] for WI in sets["WI"] for PT in sets["PT"]])
    XC = param_1
    PT = param_2
    return sum([(model.XCROP[XC, PT, WI, R].value * LNDREQ(model, XC, PT, R, TM)) for WI in sets["WI"]])
# Parameter: human consumption of commodities (000t)
def REPCONS(model, C, param_1):
    if param_1 == "TR39" and ((C) in sets["FCN"]):
        return HCOM(model, C)
    if param_1 == "EGYPT" and ((C) in sets["FCN"]):
        return sum([model.QCNSC[C, R].value for R in sets["R"]])
    return 0
# Parameter: regional employment (000md)
def REPEMPL(model, param_0, param_1):
    if param_0 == "EGYPT" and param_1 == "TOTAL":
        return sum([REPEMPL(model, R, "TOTAL") for R in sets["R"]])
    R = param_0
    if param_1 == "TOTAL" and ((R) in sets["RL"]):
        return (REPEMPL(model, R, "CROPS") + REPEMPL(model, R, "ANIMALS") + REPEMPL(model, R, "AGROPROCES"))
    if param_0 == "EGYPT" and param_1 == "AGROPROCES":
        return sum([REPEMPL(model, R, "AGROPROCES") for R in sets["R"]])
    R = param_0
    if param_1 == "AGROPROCES" and ((R) in sets["RL"]):
        return sum([((model.QPRDC[CIP, R].value * LABPR(model, CIP))) for CIP in sets["CIP"]])
    if param_0 == "EGYPT" and param_1 == "ANIMALS":
        return sum([REPEMPL(model, R, "ANIMALS") for R in sets["R"]])
    R = param_0
    if param_1 == "ANIMALS" and ((R) in sets["RL"]):
        return (sum([(model.XLIVE[XA, M, R].value * sum([table_LABREQLS(XA, M, LSLAB) for LSLAB in sets["LSLAB"]])) for XA in sets["XA"] for M in sets["M"]]))
    if param_0 == "EGYPT" and param_1 == "CROPS":
        return sum([REPEMPL(model, R, "CROPS") for R in sets["R"]])
    R = param_0
    if param_1 == "CROPS" and ((R) in sets["RL"]):
        return (sum([(model.XCROP[XC, PT, WI, R].value * LABREQC(model, XC, PT, R, TM, WI)) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] for TM in sets["TM"]]))
    return 0
# Parameter: agricultural import-export balance (%)
def REPIMPEXP(model, param_0):
    if param_0 == "IMPEXPBAL" and ((sum([(model.QEXPC[C, R].value * PEXPC(model, C)) for C in sets["C"] for R in sets["R"]]) != 0.0)):
        return (sum([(model.QIMPC[C, R].value * PIMPC(model, C)) for C in sets["C"] for R in sets["R"]]) / sum([(model.QEXPC[C, R].value * PEXPC(model, C)) for C in sets["C"] for R in sets["R"]]) * 100.0)
    return 0
# Parameter: labour use per crop (md per feddan)
def REPLABUSE(model, XC):
    return (sum([(model.XCROP[XC, PT, WI, R].value * LABREQC(model, XC, PT, R, TM, WI)) for PT in sets["PT"] for WI in sets["WI"] for TM in sets["TM"] for R in sets["R"]]) / sum([model.XCROP[XC, PT, WI, R].value for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]]))
# Parameter: net commodity imports (000t)
def REPNIMP(model, C, param_1):
    if param_1 == "EGYPT":
        return (REPIMP(model, C, "EGYPT") - REPEXP(model, C, "EGYPT"))
    return 0
# Parameter: reuse of drainage water (BCM)
def REPREUSE(model, R):
    if ((R) in sets["ADR"]):
        return ((((model.DIVA[R].value * ((1.0 - (IEFF(model, R) * FEFF(model, R))))) + model.DIVARICE[R].value)) * table_DRAINAGE(R, "TONILE"))
    return 0
# Parameter: value of exports (BLE)
def REPVALEXP(model, ):
    return (sum([(REPEXP(model, C, "EGYPT") * table_DEMDAT(C, "EXP-P")) for C in sets["C"]]) / 1000000.0)
# Parameter: value of imports (BLE)
def REPVALIMP(model, ):
    return (sum([(REPIMP(model, C, "EGYPT") * table_DEMDAT(C, "IMP-P")) for C in sets["C"]]) / 1000000.0)
# Parameter: yield reduction due to salinity (fraction)
def SALRED(model, R, XC):
    if ((DELTASAL(model, R) < table_SALTOL(XC, "100"))):
        return 1.0
    if ((DELTASAL(model, R) > table_SALTOL(XC, "100"))):
        return (0.25 - ((0.25 * ((DELTASAL(model, R) - table_SALTOL(XC, "100"))) / ((table_SALTOL(XC, "75") - table_SALTOL(XC, "100"))))) + 0.75)
    return 0
# Parameter: gross water distr. corrected for climate and salinity (m3 p f)
def SCORR(model, R):
    if (((((R) in sets["RL"])) if (((((QLNDSUP(model, R) + LNDRECL(model, R))) != 0.0))) else 0)):
        return (((model.DIVA[R].value * CFC(model, R) * ((1.0 - (ECW(model, R) / 2500.0))))) / ((QLNDSUP(model, R) + LNDRECL(model, R))) * 1000000.0)
    return 0
# Parameter: transport effort for regionally traded commodities (000t.km)
def TCOM(model, param_0, param_1):
    if param_0 == "EGYPT" and param_1 == "TOTAL":
        return sum([TCOM(model, R, C) for R in sets["R"] for C in sets["C"]])
    C = param_1
    if param_0 == "TOTAL":
        return sum([TCOM(model, R, C) for R in sets["R"]])
    R = param_0
    if param_1 == "TOTAL":
        return sum([TCOM(model, R, C) for C in sets["C"]])
    R = param_0
    C = param_1
    if ((C) in sets["CTR"]):
        return (REPPRODC(model, C, R) * 1000.0 * scalars["COMDIST"])
    return 0
# Parameter: transport effort for fertilizers by region and crop (t.km)
def TFERT(model, param_0, param_1):
    if param_0 == "EGYPT" and param_1 == "TOTAL":
        return sum([TFERT(model, R, XC) for R in sets["R"] for XC in sets["XC"]])
    XC = param_1
    if param_0 == "TOTAL":
        return sum([TFERT(model, R, XC) for R in sets["R"]])
    R = param_0
    if param_1 == "TOTAL":
        return sum([TFERT(model, R, XC) for XC in sets["XC"]])
    R = param_0
    XC = param_1
    if ((R) in sets["RL"]):
        return sum([(QFERT(model, R, XC, FERT) * table_FERTDIST(R, FERT)) for FERT in sets["FERT"]])
    return 0
# Parameter: total agricultural area (000fed)
def TOTAREA(model, ):
    return sum([(QLNDSUP(model, R) + LNDRECL(model, R)) for R in sets["R"]])
    return sum([(QLNDSUP(model, R) + LNDRECL(model, R)) for R in sets["R"]])
    return (sum([QLNDSUP(model, R) for R in sets["R"]]) + sum([LNDRECL(model, R) for R in sets["R"]]))
# Parameter: total agricultural area using nile water (000fed)
def TOTNAREA(model, ):
    return (sum([QLNDSUP(model, R) for R in sets["R"] if ((not (((R) in sets["DGW"]))))]) + sum([LNDRECL(model, R) for R in sets["R"] if ((not (((R) in sets["DGW"]))))]))
# Parameter: population in the base year (000capita)
def TOTPOPC(model, ):
    return sum([TOT21(model, R) for R in sets["R"] if ((R) in sets["RL"])])
# Parameter: future population in the planning year (000capita)
def TOTPOPF(model, ):
    return sum([TOT21(model, R) for R in sets["R"] if ((R) in sets["RL"])])
# Parameter: reg water req incl rain by pdate by crop (m3 p fed)
def WATER1(model, XC, PT, R):
    return (table_WATER0(XC, PT, R) - RAINFALL(model, XC, PT, R))
# Parameter: crop yields depending on planting time (t p fed)
def YIELD1(model, XC, PT, C, R):
    if PT == "L" and ((XC) in sets["PXC"]):
        return 0.0
    if PT == "O" and ((XC) in sets["PXC"]):
        return 0.0
    if PT == "L" and ((not (((XC) in sets["VP"])))):
        return (YIELD0(model, XC, C, R) * 0.95)
    return YIELD0(model, XC, C, R)
# Parameter: yield reduction corresponding to water deficit;
def YRED(model, XC, WI):
    return (1.0 - (KY(model, XC) * WDEF(model, WI)))
# Parameter: annual average per capita consumption (kg p capita)
def CAPCONS(model, C):
    return (REPCONS(model, C, "EGYPT") / TOTPOPF(model) * 1000.0)
# Parameter: total energy value of produced commodities (MJ)
def COMENERGYV(model, param_0, param_1):
    C = param_0
    if param_1 == "MJ":
        return (REPCONS(model, C, "EGYPT") * table_NUTRITION(C, "KCAL") * 1000.0 * 0.0041868)
    return 0
# Parameter: crop category dependant water charge (LE p m3)
def CROPCHARGE(model, XC, R):
    return (CROPCHXC(model, XC) * CROPCHF(model, R))
# Parameter: energy use for fertilizer transport by region and crop (MJ)
def ETFERT(model, param_0, param_1):
    if param_0 == "EGYPT" and param_1 == "TOTAL":
        return sum([ETFERT(model, R, XC) for R in sets["R"] for XC in sets["XC"]])
    XC = param_1
    if param_0 == "TOTAL":
        return sum([ETFERT(model, R, XC) for R in sets["R"]])
    R = param_0
    if param_1 == "TOTAL":
        return sum([ETFERT(model, R, XC) for XC in sets["XC"]])
    R = param_0
    XC = param_1
    if ((R) in sets["RL"]):
        return (TFERT(model, R, XC) * scalars["FUELEFF"])
    return 0
# Parameter: evaporation from wetted surfaces nile by R (BCM)
def EVAP(model, R):
    if ((not (((R) in sets["DGW"])))):
        return (((QLNDSUP(model, R) + LNDRECL(model, R))) * scalars["AVAP"] / TOTNAREA(model))
    return 0
# Parameter: regional municipal and industrial diversions and returns
def MI(model, R, MIXX):
    if MIXX == "MUN-NET":
        return (MI(model, R, "MUN-DIV") - MI(model, R, "MUN-RET"))
    if MIXX == "IND-NET":
        return (MI(model, R, "IND-DIV") - MI(model, R, "IND-RET"))
    if MIXX == "IND-RET":
        return (INDDEM(model, R) * INDRET(model, R))
    if MIXX == "IND-DIV":
        return INDDEM(model, R)
    if MIXX == "MUN-RET":
        return (MUNDEM(model, R) * MUNRET(model, R))
    if MIXX == "MUN-DIV":
        return MUNDEM(model, R)
    return 0
# Parameter: total municipal water demand (BCM)
def MUNDEMTOT(model, ):
    return sum([MUNDEM(model, R) for R in sets["R"]])
# Parameter: calculated quantities (000t) market price (LE p t) and elast.
def REPCRP(model, C, param_1):
    CN = C
    if param_1 == "PRIELASU":
        return table_DEMDAT(CN, "PRIELASU")
    CN = C
    if param_1 == "PRIELASR":
        return table_DEMDAT(CN, "PRIELASR")
    CN = C
    if param_1 == "ELASTU" and (((((BETACU(model, CN) != 0.0))) if (((sum([model.QCNSCU[CN, R].value for R in sets["R"]]) != 0.0))) else 0)):
        return (((1.0 / BETACU(model, CN))) * REPCRP(model, CN, "MKT-PRICEU") / sum([model.QCNSCU[CN, R].value for R in sets["R"]]))
    CN = C
    if param_1 == "ELASTR" and (((((BETACR(model, CN) != 0.0))) if (((sum([model.QCNSCR[CN, R].value for R in sets["R"]]) != 0.0))) else 0)):
        return (((1.0 / BETACR(model, CN))) * REPCRP(model, CN, "MKT-PRICER") / sum([model.QCNSCR[CN, R].value for R in sets["R"]]))
    CN = C
    if param_1 == "MKT-PRICEU":
        return (ALPHACU(model, CN) + ((BETACU(model, CN) * sum([model.QCNSCU[CN, R].value for R in sets["R"]]))))
    CN = C
    if param_1 == "MKT-PRICER":
        return (ALPHACR(model, CN) + ((BETACR(model, CN) * sum([model.QCNSCR[CN, R].value for R in sets["R"]]))))
    CN = C
    if param_1 == "FGP":
        return table_DEMDAT(CN, "BASE-P")
    CN = C
    if param_1 == "TR39":
        return (table_DEMDAT(CN, "HUMCONR") + table_DEMDAT(CN, "HUMCONU"))
    CN = C
    if param_1 == "CONSUMP":
        return sum([model.QCNSC[CN, R].value for R in sets["R"]])
    return 0
# Parameter: agr. diversions incl. for rice percolation municipal and industrial (BCM)
def REPDIV(model, param_0):
    if param_0 == "TOTAL":
        return (REPDIV(model, "TOTAL-AG") + REPDIV(model, "MUN") + REPDIV(model, "IND"))
    if param_0 == "IND":
        return sum([INDDEM(model, R) for R in sets["R"] if ((not (((R) in sets["DGW"]))))])
    if param_0 == "MUN":
        return sum([MUNDEM(model, R) for R in sets["R"] if ((not (((R) in sets["DGW"]))))])
    if param_0 == "TOTAL-AG":
        return sum([REPDIV(model, R) for R in sets["R"] if ((not (((R) in sets["DGW"]))))])
    if param_0 == "NSINAI":
        return (model.DIVA["NSINAI"].value + model.DIVARICE["NSINAI"].value)
    if param_0 == "TOSHKA":
        return (model.DIVA["TOSHKA"].value + model.DIVARICE["TOSHKA"].value)
    if param_0 == "OLDLANDS":
        return sum([REPDIV(model, R) for R in sets["R"] if ((R) in sets["OLN"])])
    R = param_0
    if ((not (((R) in sets["DGW"])))):
        return (model.DIVA[R].value + model.DIVARICE[R].value)
    return 0
# Parameter: reuse of drainage water in deltas (BCM)
def REPREUSED(model, param_0):
    if param_0 == "TOTDELTA":
        return sum([REPREUSE(model, R) for R in sets["R"]])
    if param_0 == "WESTDELTA":
        return sum([REPREUSE(model, R) for R in sets["R"] if ((R) in sets["WDR"])])
    if param_0 == "MIDLDELTA":
        return sum([REPREUSE(model, R) for R in sets["R"] if ((R) in sets["MDR"])])
    if param_0 == "EASTDELTA":
        return sum([REPREUSE(model, R) for R in sets["R"] if ((R) in sets["EDR"])])
    return 0
# Parameter: food self sufficiency (%)
def SELFFOOD(model, param_0):
    if param_0 == "CEREALS":
        return (((DEMSUPBAL(model, "WHEATF", "NETPROD") + DEMSUPBAL(model, "MAIZE", "NETPROD") + DEMSUPBAL(model, "RICE", "NETPROD"))) / ((DEMSUPBAL(model, "WHEATF", "HCONSUMP") + DEMSUPBAL(model, "MAIZE", "HCONSUMP") + DEMSUPBAL(model, "MAIZE", "ACONSUMP") + DEMSUPBAL(model, "RICE", "HCONSUMP"))) * 100.0)
    if param_0 == "VEG-OIL":
        return (DEMSUPBAL(model, "VEG-OIL", "NETPROD") / DEMSUPBAL(model, "VEG-OIL", "HCONSUMP") * 100.0)
    if param_0 == "MILK":
        return (((DEMSUPBAL(model, "BMILK", "NETPROD") + DEMSUPBAL(model, "CMILK", "NETPROD") + DEMSUPBAL(model, "IMILK", "NETPROD"))) / ((DEMSUPBAL(model, "BMILK", "HCONSUMP") + DEMSUPBAL(model, "CMILK", "HCONSUMP") + DEMSUPBAL(model, "IMILK", "HCONSUMP"))) * 100.0)
    if param_0 == "MEAT":
        return (((DEMSUPBAL(model, "CBEEF", "NETPROD") + DEMSUPBAL(model, "FBEEF", "NETPROD") + DEMSUPBAL(model, "VEAL", "NETPROD") + DEMSUPBAL(model, "SGMT", "NETPROD") + DEMSUPBAL(model, "PMEAT", "NETPROD"))) / ((DEMSUPBAL(model, "CBEEF", "HCONSUMP") + DEMSUPBAL(model, "FBEEF", "HCONSUMP") + DEMSUPBAL(model, "VEAL", "HCONSUMP") + DEMSUPBAL(model, "SGMT", "HCONSUMP") + DEMSUPBAL(model, "PMEAT", "HCONSUMP"))) * 100.0)
    if param_0 == "SUGAR":
        return (DEMSUPBAL(model, "SUGAR", "NETPROD") / DEMSUPBAL(model, "SUGAR", "HCONSUMP") * 100.0)
    if param_0 == "RICE":
        return (DEMSUPBAL(model, "RICE", "NETPROD") / DEMSUPBAL(model, "RICE", "HCONSUMP") * 100.0)
    if param_0 == "MAIZE":
        return (DEMSUPBAL(model, "MAIZE", "NETPROD") / ((DEMSUPBAL(model, "MAIZE", "HCONSUMP") + DEMSUPBAL(model, "MAIZE", "ACONSUMP"))) * 100.0)
    if param_0 == "WHEAT":
        return (DEMSUPBAL(model, "WHEATF", "NETPROD") / DEMSUPBAL(model, "WHEATF", "HCONSUMP") * 100.0)
    return 0
# Parameter: water req of crop act XC incl rain (m3 p fed)
def WATREQ(model, XC, PT, WI, R):
    return (WATER1(model, XC, PT, R) * ((1.0 - WDEF(model, WI))))
# Parameter: yield of commodity C of crop act XC (t p fed)
def YLDC1(model, XC, PT, WI, C, R):
    return (YIELD1(model, XC, PT, C, R) * YRED(model, XC, WI))
# Parameter: daily calori fat protein intake (kcal and gram p capita p day)
def CAPCAL(model, param_0):
    if param_0 == "PROTEIN":
        return (sum([(CAPCONS(model, C) * table_NUTRITION(C, "PROT")) for C in sets["C"]]) / 365.0 * 0.797)
    if param_0 == "FAT":
        return (sum([(CAPCONS(model, C) * table_NUTRITION(C, "FAT")) for C in sets["C"]]) / 365.0 * 0.459)
    if param_0 == "CALORI":
        return (sum([(CAPCONS(model, C) * table_NUTRITION(C, "KCAL")) for C in sets["C"]]) / 365.0 * 0.761)
    return 0
# Parameter: non-labour input cost of crop XC per WI and PT (LE p fed)
def CSTOINP(model, XC, PT, WI, C, R):
    if ((AVYIELD(model, XC, C) > 0.0)):
        return (YLDC1(model, XC, PT, WI, C, R) / AVYIELD(model, XC, C) * 0.9 * sum([table_INPUT(XC, INP) for INP in sets["INP"]]))
    return 0
# Parameter: production value (MLE) based on consumption
def PRODVAL(model, ):
    return (((sum([(REPCRP(model, CN, "MKT-PRICER") * sum([model.QCNSCR[CN, R].value for R in sets["R"]])) for CN in sets["CN"]]) + sum([(REPCRP(model, CN, "MKT-PRICEU") * sum([model.QCNSCU[CN, R].value for R in sets["R"]])) for CN in sets["CN"]]) + sum([(model.QEXPC[CN, R].value * PEXPC(model, CN)) for CN in sets["CN"] for R in sets["R"]]))) / 1000.0)
# Parameter: production value (MLE) based on production
def PRODVAL2(model, ):
    return (((sum([(REPCRP(model, CN, "MKT-PRICER") * sum([model.QPRDA[CN, R].value for R in sets["R"]])) for CN in sets["CN"]]) + sum([(REPCRP(model, CN, "MKT-PRICEU") * sum([model.QPRDA[CN, R].value for R in sets["R"]])) for CN in sets["CN"]]) + sum([(REPCRP(model, CN, "MKT-PRICER") * sum([model.QPRDC[CN, R].value for R in sets["R"]])) for CN in sets["CN"]]) + sum([(REPCRP(model, CN, "MKT-PRICEU") * sum([model.QPRDC[CN, R].value for R in sets["R"]])) for CN in sets["CN"]]) + sum([(model.QEXPC[CN, R].value * PEXPC(model, CN)) for CN in sets["CN"] for R in sets["R"]]))) / 1000.0)
# Parameter: producer surplus (MLE)
def PSUR(model, ):
    return (((sum([(REPCRP(model, CN, "MKT-PRICER") * sum([model.QCNSCR[CN, R].value for R in sets["R"]])) for CN in sets["CN"]]) + sum([(REPCRP(model, CN, "MKT-PRICEU") * sum([model.QCNSCU[CN, R].value for R in sets["R"]])) for CN in sets["CN"]]) + sum([(model.QEXPC[CN, R].value * PEXPC(model, CN)) for CN in sets["CN"] for R in sets["R"]]) - sum([(model.QIMPC[CN, R].value * PIMPC(model, CN)) for CN in sets["CN"] for R in sets["R"]]) - model.LABCOST.value - model.OINPCOST.value - model.PMCOST.value - model.LRECCOST.value)) / 1000.0)
# Parameter: relative diversions including for rice percolation all R (fraction)
def REPDIV2(model, param_0):
    if param_0 == "NSINAI":
        return (((model.DIVA["NSINAI"].value + model.DIVARICE["NSINAI"].value)) / REPDIV(model, "TOTAL-AG"))
    if param_0 == "TOSHKA":
        return (((model.DIVA["TOSHKA"].value + model.DIVARICE["TOSHKA"].value)) / REPDIV(model, "TOTAL-AG"))
    if param_0 == "OLDLANDS":
        return (sum([REPDIV(model, R) for R in sets["R"] if ((R) in sets["OLN"])]) / REPDIV(model, "TOTAL-AG"))
    R = param_0
    if ((not (((R) in sets["DGW"])))):
        return (((model.DIVA[R].value + model.DIVARICE[R].value)) / REPDIV(model, "TOTAL-AG"))
    return 0
# Parameter: relative diversions including for rice percolation OLD and OLDNEW (fraction)
def REPDIV3(model, param_0):
    if param_0 == "OLDLANDS":
        return (sum([REPDIV(model, R) for R in sets["R"] if ((R) in sets["OLN"])]) / REPDIV(model, "OLDLANDS"))
    R = param_0
    if ((R) in sets["OLN"]):
        return (REPDIV(model, R) / REPDIV(model, "OLDLANDS"))
    return 0
# Parameter: total ET incl rain (BCM)
def REPET(model, param_0, param_1):
    if param_0 == "TOTAL" and param_1 == "EGYPT":
        return sum([REPET(model, "TOTAL", R) for R in sets["R"]])
    R = param_1
    if param_0 == "TOTAL":
        return sum([REPET(model, XC, R) for XC in sets["XC"]])
    XC = param_0
    if param_1 == "EGYPT":
        return sum([REPET(model, XC, R) for R in sets["R"]])
    XC = param_0
    R = param_1
    if table_RXCMAP(R, XC):
        return (sum([(model.XCROP[XC, PT, WI, R].value * WATREQ(model, XC, PT, WI, R)) for PT in sets["PT"] for WI in sets["WI"]]) / 1000000.0)
    return 0
# Parameter: total potential ET incl rain (BCM)
def REPPET(model, param_0, param_1):
    if param_0 == "TOTAL" and param_1 == "EGYPT":
        return sum([REPPET(model, "TOTAL", R) for R in sets["R"]])
    R = param_1
    if param_0 == "TOTAL":
        return sum([REPPET(model, XC, R) for XC in sets["XC"]])
    XC = param_0
    if param_1 == "EGYPT":
        return sum([REPPET(model, XC, R) for R in sets["R"]])
    XC = param_0
    R = param_1
    if table_RXCMAP(R, XC):
        return (sum([(model.XCROP[XC, PT, WI, R].value * WATREQ(model, XC, PT, "HI", R)) for PT in sets["PT"] for WI in sets["WI"]]) / 1000000.0)
    return 0
# Parameter: ET water distribution (m3 p f)
def WATDIST(model, R):
    if (((((R) in sets["RL"])) if (((((QLNDSUP(model, R) + LNDRECL(model, R))) != 0.0))) else 0)):
        return (sum([(model.XCROP[XC, PT, WI, R].value * WATREQ(model, XC, PT, WI, R)) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, XC)]) / ((QLNDSUP(model, R) + LNDRECL(model, R))))
    return 0
# Parameter: ET water distribution Egypt (m3 p f)
def WATDISTE(model, ):
    return (sum([sum([(model.XCROP[XC, PT, WI, R].value * WATREQ(model, XC, PT, WI, R)) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, XC)]) for R in sets["R"]]) / sum([((QLNDSUP(model, R) + LNDRECL(model, R))) for R in sets["R"]]))
# Parameter: water pumped from mesqa to field by region and crop (1000 m3)
def WATPUMP(model, param_0, param_1):
    if param_0 == "EGYPT" and param_1 == "TOTAL":
        return sum([WATPUMP(model, R, XC) for R in sets["R"] for XC in sets["XC"]])
    XC = param_1
    if param_0 == "TOTAL":
        return sum([WATPUMP(model, R, XC) for R in sets["R"]])
    R = param_0
    if param_1 == "TOTAL":
        return sum([WATPUMP(model, R, XC) for XC in sets["XC"]])
    R = param_0
    XC = param_1
    if ((R) in sets["RL"]):
        return ((sum([(model.XCROP[XC, PT, WI, R].value * WATREQ(model, XC, PT, WI, R)) for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, XC)])) / FEFF(model, R))
    return 0
# Parameter: yield of C of crop act XC adjusted for salinity and YLDINC (t p fed)
def YLDC(model, XC, PT, WI, C, R):
    if ((DELTASAL(model, R) > table_SALTOL(XC, "100"))):
        return (YLDC1(model, XC, PT, WI, C, R) * SALRED(model, R, XC))
    return YLDC1(model, XC, PT, WI, C, R)
# Parameter:
def AVWATDIST(model, ):
    return (sum([WATDIST(model, R) for R in sets["R"] if ((R) in sets["RL"])]) / (len(sets["RL"])))
# Parameter: regional average production per feddan and commodity (t per fed)
def CROPFEDR1(model, XC, C, R):
    if (((((XC, C) in sets["XCPCMAP"])) if (((REPCA(model, XC, R) != 0.0))) else 0)):
        return (sum([(YLDC(model, XC, PT, WI, C, R) * ((model.XCROP[XC, PT, WI, R].value) if (table_RXCMAP(R, XC)) else 0)) for PT in sets["PT"] for WI in sets["WI"]]) / REPCA(model, XC, R))
    return 0
# Parameter: overview of crop commodities
def CROPVIEW(model, XC, C, param_2):
    if param_2 == "NPV/m3" and (((((XC, C) in sets["XCCMAP"])) if (((CROPVIEW(model, XC, C, "WATUSE") != 0.0))) else 0)):
        return (CROPVIEW(model, XC, C, "NPV") / CROPVIEW(model, XC, C, "WATUSE"))
    if param_2 == "NPV-FGP" and ((XC, C) in sets["XCCMAP"]):
        return ((CROPVIEW(model, XC, C, "PROD/FED") * CROPVIEW(model, XC, C, "FGP-PRICE")) - CROPVIEW(model, XC, C, "PRODCST") - ((CROPVIEW(model, XC, C, "PPRCCST")) if (((C) in sets["CIP"])) else 0))
    if param_2 == "PPRCCST" and (((((XC, C) in sets["XCCMAP"])) if (((C) in sets["CIP"]) and ((CROPVIEW(model, XC, C, "AREA") != 0.0))) else 0)):
        return (sum([(model.QPRDC[C, R].value * CSTPR(model, C)) for R in sets["R"]]) / CROPVIEW(model, XC, C, "AREA"))
    if param_2 == "MARKCST" and (((((XC, C) in sets["XCCMAP"])) if (((C) in sets["CND"])) else 0)):
        return CSTMRKD(model, C)
    if param_2 == "MARKCST" and (((((XC, C) in sets["XCCMAP"])) if (((C) in sets["CNF"])) else 0)):
        return CSTMRKF(model, C)
    if param_2 == "PRODCST":
        return (CROPVIEW(model, XC, C, "LABCST") + CROPVIEW(model, XC, C, "OIPCST"))
    if param_2 == "OIPCST" and (((((XC, C) in sets["XCCMAP"])) if (((XC, C) in sets["XCPCMAP"]) and ((CROPVIEW(model, XC, C, "AREA") != 0.0))) else 0)):
        return (sum([(CSTOINP(model, XC, PT, WI, C, R) * model.XCROP[XC, PT, WI, R].value) for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if table_RXCMAP(R, XC)]) / CROPVIEW(model, XC, C, "AREA"))
    if param_2 == "LABCST" and (((((XC, C) in sets["XCCMAP"])) if (((XC, C) in sets["XCPCMAP"]) and ((CROPVIEW(model, XC, C, "AREA") != 0.0))) else 0)):
        return (sum([(LABREQC(model, XC, PT, R, TM, WI) * WAVG(model, R, TM) * model.XCROP[XC, PT, WI, R].value) for PT in sets["PT"] for R in sets["R"] for TM in sets["TM"] for WI in sets["WI"]]) / CROPVIEW(model, XC, C, "AREA"))
    if param_2 == "WATUSE" and (((((XC, C) in sets["XCCMAP"])) if (((XC) in sets["XCRICE"]) and ((XC, C) in sets["XCPCMAP"])) else 0)):
        return (sum([(model.XCROP[XC, PT, WI, R].value * (((((((((WATREQ(model, XC, PT, WI, R)) if (((XC, C) in sets["XCCMAP"])) else 0) / IEFF(model, R) / FEFF(model, R))) + scalars["RICEPER"])) / IEFF(model, R)) - ((((((WATREQ(model, XC, PT, WI, R)) if (((XC, C) in sets["XCCMAP"])) else 0) / IEFF(model, R) / FEFF(model, R) * ((1.0 - (IEFF(model, R) * FEFF(model, R))))) + (scalars["RICEPER"] / IEFF(model, R)))) * table_DRAINAGE(R, "TONILE"))))) for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["RL"])]) / 1000000.0)
    if param_2 == "WATUSE" and (((((XC, C) in sets["XCCMAP"])) if (((not (((XC) in sets["XCRICE"])))) and ((XC, C) in sets["XCPCMAP"])) else 0)):
        return (sum([(model.XCROP[XC, PT, WI, R].value * ((((WATREQ(model, XC, PT, WI, R) / IEFF(model, R) / FEFF(model, R))) - (((WATREQ(model, XC, PT, WI, R) / IEFF(model, R) / FEFF(model, R) * ((1.0 - (IEFF(model, R) * FEFF(model, R)))))) * table_DRAINAGE(R, "TONILE"))))) for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["RL"])]) / 1000000.0)
    if param_2 == "WATREQ" and (((((XC, C) in sets["XCCMAP"])) if (((XC, C) in sets["XCPCMAP"])) else 0)):
        return (sum([(model.XCROP[XC, PT, WI, R].value * WATREQ(model, XC, PT, WI, R)) for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]]) / 1000000.0)
    if param_2 == "FGP-PRICE" and ((XC, C) in sets["XCCMAP"]):
        return table_DEMDAT(C, "BASE-P")
    if param_2 == "MKT-PRICE" and ((XC, C) in sets["XCCMAP"]):
        return REPCRP(model, C, "MKT-PRICE")
    if param_2 == "PROD/FED" and (((((XC, C) in sets["XCCMAP"])) if (((REPCA(model, XC, "EGYPT") != 0.0))) else 0)):
        return (CROPVIEW(model, XC, C, "PROD") / REPCA(model, XC, "EGYPT"))
    if param_2 == "PROD" and ((XC, C) in sets["XCCMAP"]):
        return sum([(YLDC(model, XC, PT, WI, C, R) * ((model.XCROP[XC, PT, WI, R].value) if (table_RXCMAP(R, XC)) else 0)) for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]])
    if param_2 == "AREA" and (((((XC, C) in sets["XCCMAP"])) if (((XC, C) in sets["XCPCMAP"])) else 0)):
        return REPCA(model, XC, "EGYPT")
    return 0
# Parameter: consumer surplus (MLE)
def CSUR(model, ):
    return (CPSUR(model) - PSUR(model))
# Parameter: regional drop per crop annual non rice crops (m3 per ton)
def DROPCROPA(model, XC, C, PT, WI, R):
    if (((((XC, C) in sets["XCPCMAP"])) if (((R) in sets["RL"]) and table_RXCMAP(R, XC) and (((((XC) in sets["AXC"])) if (((not (((XC) in sets["XCRICE"]))))) else 0))) else 0)):
        return (((((((WATREQ(model, XC, PT, WI, R)) if (((XC, C) in sets["XCCMAP"])) else 0) / IEFF(model, R) / FEFF(model, R))) - (((((WATREQ(model, XC, PT, WI, R)) if (((XC, C) in sets["XCCMAP"])) else 0) / IEFF(model, R) / FEFF(model, R) * ((1.0 - (IEFF(model, R) * FEFF(model, R)))))) * table_DRAINAGE(R, "TONILE")))) / ((((YLDC(model, XC, PT, WI, C, R)) if (((YLDC(model, XC, PT, WI, C, R) != 0.0))) else 0) + 1e-09)))
    return 0
# Parameter: regional drop per crop perrenial crops (m3 per ton)
def DROPCROPP(model, XC, C, PT, WI, R):
    if PT == "E" and (((((XC, C) in sets["XCPCMAP"])) if (((R) in sets["RL"]) and table_RXCMAP(R, XC) and ((XC) in sets["PXC"])) else 0)):
        return (((((((WATREQ(model, XC, "E", WI, R)) if (((XC, C) in sets["XCCMAP"])) else 0) / IEFF(model, R) / FEFF(model, R))) - (((((WATREQ(model, XC, "E", WI, R)) if (((XC, C) in sets["XCCMAP"])) else 0) / IEFF(model, R) / FEFF(model, R) * ((1.0 - (IEFF(model, R) * FEFF(model, R)))))) * table_DRAINAGE(R, "TONILE")))) / ((((YLDC(model, XC, "E", WI, C, R)) if (((YLDC(model, XC, "E", WI, C, R) != 0.0))) else 0) + 1e-09)))
    return 0
# Parameter: regional drop per crop rice crops (m3 per ton)
def DROPCROPR(model, XC, C, PT, WI, R):
    if (((((XC, C) in sets["XCPCMAP"])) if (((R) in sets["RL"]) and table_RXCMAP(R, XC) and ((XC) in sets["XCRICE"])) else 0)):
        return ((((((((((WATREQ(model, XC, PT, WI, R)) if (((XC, C) in sets["XCCMAP"])) else 0) / IEFF(model, R) / FEFF(model, R))) + scalars["RICEPER"])) / IEFF(model, R)) - ((((((WATREQ(model, XC, PT, WI, R)) if (((XC, C) in sets["XCCMAP"])) else 0) / IEFF(model, R) / FEFF(model, R) * ((1.0 - (IEFF(model, R) * FEFF(model, R))))) + (scalars["RICEPER"] / IEFF(model, R)))) * table_DRAINAGE(R, "TONILE")))) / ((((YLDC(model, XC, PT, WI, C, R)) if (((YLDC(model, XC, PT, WI, C, R) != 0.0))) else 0) + 1e-09)))
    return 0
# Parameter: energy use water pumped to field by region and crop (MJ)
def EWATPUMP(model, param_0, param_1):
    if param_0 == "EGYPT" and param_1 == "TOTAL":
        return sum([EWATPUMP(model, R, XC) for R in sets["R"] for XC in sets["XC"]])
    XC = param_1
    if param_0 == "TOTAL":
        return sum([EWATPUMP(model, R, XC) for R in sets["R"]])
    R = param_0
    if param_1 == "TOTAL":
        return sum([EWATPUMP(model, R, XC) for XC in sets["XC"]])
    R = param_0
    XC = param_1
    if ((R) in sets["DGW"]):
        return (WATPUMP(model, R, XC) * 1000.0 * 9.81 * scalars["TOTLIFTD"] / ((3.6 * 1000000.0)) / scalars["PUMPEFF"] * 3.6 * 1000.0)
    R = param_0
    XC = param_1
    if ((R) in sets["RSW"]):
        return (WATPUMP(model, R, XC) * 1000.0 * 9.81 * scalars["TOTLIFTN"] / ((3.6 * 1000000.0)) / scalars["PUMPEFF"] * 3.6 * 1000.0)
    return 0
# Parameter: diversion and consumption deep groundwater (BCM)
def REPDIVCOND(model, param_0, S10):
    if param_0 == "EGYPT":
        return sum([REPDIVCOND(model, R, S10) for R in sets["R"]])
    R = param_0
    if S10 == "TO-SINK" and ((R) in sets["DGW"]):
        return ((((model.DIVA[R].value * ((1.0 - (IEFF(model, R) * FEFF(model, R))))) + model.DIVARICE[R].value + (MUNDEM(model, R) * MUNRET(model, R)) + (INDDEM(model, R) * INDRET(model, R)))) * table_DRAINAGE(R, "TOSINK"))
    R = param_0
    if S10 == "CON-TOT" and ((R) in sets["DGW"]):
        return (REPDIVCOND(model, R, "CON-AGR") + REPDIVCOND(model, R, "CON-MUN") + REPDIVCOND(model, R, "CON-IND"))
    R = param_0
    if S10 == "CON-IND" and ((R) in sets["DGW"]):
        return (INDDEM(model, R) * ((1.0 - INDRET(model, R))))
    R = param_0
    if S10 == "CON-MUN" and ((R) in sets["DGW"]):
        return (MUNDEM(model, R) * ((1.0 - MUNRET(model, R))))
    R = param_0
    if S10 == "CON-AGR" and ((R) in sets["DGW"]):
        return REPET(model, "TOTAL", R)
    R = param_0
    if S10 == "DIV-TOT" and ((R) in sets["DGW"]):
        return (REPDIVCOND(model, R, "DIV-AG+RI") + REPDIVCOND(model, R, "DIV-MUN") + REPDIVCOND(model, R, "DIV-IND"))
    R = param_0
    if S10 == "DIV-IND" and ((R) in sets["DGW"]):
        return INDDEM(model, R)
    R = param_0
    if S10 == "DIV-MUN" and ((R) in sets["DGW"]):
        return MUNDEM(model, R)
    R = param_0
    if S10 == "DIV-AG+RI" and ((R) in sets["DGW"]):
        return (model.DIVA[R].value + model.DIVARICE[R].value)
    return 0
# Parameter: regional diversions and consumption nile (BCM)
def REPDIVCONN(model, param_0, S10A):
    if param_0 == "EGYPT" and S10A == "FISH-SEA":
        return scalars["SEAFLOWFP"]
    if param_0 == "EGYPT" and S10A == "FRESH-SEA":
        return model.SEAFLOW.value
    if param_0 == "EGYPT":
        return sum([REPDIVCONN(model, R, S10A) for R in sets["R"]])
    R = param_0
    if S10A == "TOSINK-T" and ((R) in sets["RSW"]):
        return (REPDIVCONN(model, R, "TOSINK-A") + REPDIVCONN(model, R, "TOSINK-MI"))
    R = param_0
    if S10A == "TOSINK-MI" and ((R) in sets["RSW"]):
        return ((((MUNDEM(model, R) * MUNRET(model, R)) + (INDDEM(model, R) * INDRET(model, R)))) * table_DRAINAGE(R, "TOSINK"))
    R = param_0
    if S10A == "TOSINK-A" and ((R) in sets["RSW"]):
        return ((((model.DIVA[R].value * ((1.0 - (IEFF(model, R) * FEFF(model, R))))) + model.DIVARICE[R].value)) * table_DRAINAGE(R, "TOSINK"))
    R = param_0
    if S10A == "TODRAIN-T" and ((R) in sets["RSW"]):
        return (REPDIVCONN(model, R, "TODRAIN-A") + REPDIVCONN(model, R, "TODRAIN-MI"))
    R = param_0
    if S10A == "TODRAIN-MI" and ((R) in sets["RSW"]):
        return ((((MUNDEM(model, R) * MUNRET(model, R)) + (INDDEM(model, R) * INDRET(model, R)))) * table_DRAINAGE(R, "TODRAIN"))
    R = param_0
    if S10A == "TODRAIN-A" and ((R) in sets["RSW"]):
        return ((((model.DIVA[R].value * ((1.0 - (IEFF(model, R) * FEFF(model, R))))) + model.DIVARICE[R].value)) * table_DRAINAGE(R, "TODRAIN"))
    R = param_0
    if S10A == "TONILE-T" and ((R) in sets["RSW"]):
        return (REPDIVCONN(model, R, "TONILE-A") + REPDIVCONN(model, R, "TONILE-MI"))
    R = param_0
    if S10A == "TONILE-MI" and ((R) in sets["RSW"]):
        return ((((MUNDEM(model, R) * MUNRET(model, R)) + (INDDEM(model, R) * INDRET(model, R)))) * table_DRAINAGE(R, "TONILE"))
    R = param_0
    if S10A == "TONILE-A" and ((R) in sets["RSW"]):
        return ((((model.DIVA[R].value * ((1.0 - (IEFF(model, R) * FEFF(model, R))))) + model.DIVARICE[R].value)) * table_DRAINAGE(R, "TONILE"))
    R = param_0
    if S10A == "WETSURF" and ((R) in sets["RSW"]):
        return EVAP(model, R)
    R = param_0
    if S10A == "NETNILTOT" and ((R) in sets["RSW"]):
        return (REPDIVCONN(model, R, "NETNILAGR") + REPDIVCONN(model, R, "NETNILMUN") + REPDIVCONN(model, R, "NETNILIND"))
    R = param_0
    if S10A == "NETNILIND" and ((R) in sets["RSW"]):
        return (REPDIVCONN(model, R, "CON-IND") + (INDDEM(model, R) * INDRET(model, R) * ((table_DRAINAGE(R, "TODRAIN") + table_DRAINAGE(R, "TOSINK")))))
    R = param_0
    if S10A == "NETNILMUN" and ((R) in sets["RSW"]):
        return (REPDIVCONN(model, R, "CON-MUN") + (MUNDEM(model, R) * MUNRET(model, R) * ((table_DRAINAGE(R, "TODRAIN") + table_DRAINAGE(R, "TOSINK")))))
    R = param_0
    if S10A == "NETNILAGR" and ((R) in sets["RSW"]):
        return (REPDIVCONN(model, R, "CON-AGR") + ((((model.DIVA[R].value * ((1.0 - (IEFF(model, R) * FEFF(model, R))))) + model.DIVARICE[R].value)) * ((table_DRAINAGE(R, "TODRAIN") + table_DRAINAGE(R, "TOSINK")))))
    R = param_0
    if S10A == "CON-TOT" and ((R) in sets["RSW"]):
        return (REPDIVCONN(model, R, "CON-AGR") + REPDIVCONN(model, R, "CON-MUN") + REPDIVCONN(model, R, "CON-IND"))
    R = param_0
    if S10A == "CON-IND" and ((R) in sets["RSW"]):
        return (INDDEM(model, R) * ((1.0 - INDRET(model, R))))
    R = param_0
    if S10A == "CON-MUN" and ((R) in sets["RSW"]):
        return (MUNDEM(model, R) * ((1.0 - MUNRET(model, R))))
    R = param_0
    if S10A == "CON-AGR" and ((R) in sets["RSW"]):
        return REPET(model, "TOTAL", R)
    R = param_0
    if S10A == "DIV-TOT" and ((R) in sets["RSW"]):
        return (REPDIVCONN(model, R, "DIV-AGR") + ((REPDIVCONN(model, R, "DIV-RIC")) if (((R) in sets["RICEMAP"])) else 0) + REPDIVCONN(model, R, "DIV-MUN") + REPDIVCONN(model, R, "DIV-IND"))
    R = param_0
    if S10A == "DIV-IND" and ((R) in sets["RSW"]):
        return INDDEM(model, R)
    R = param_0
    if S10A == "DIV-MUN" and ((R) in sets["RSW"]):
        return MUNDEM(model, R)
    R = param_0
    if S10A == "DIV-RIC" and ((R) in sets["RICEMAP"]):
        return model.DIVARICE[R].value
    R = param_0
    if S10A == "DIV-AGR" and ((R) in sets["RSW"]):
        return model.DIVA[R].value
    return 0
# Parameter: water use per commodity (BCM)
def REPETC1(model, C, param_1):
    if param_1 == "BCM" and ((C) in sets["CN"]):
        return sum([REPET(model, XC, "EGYPT") for XC in sets["XC"] if ((XC, C) in sets["XCCMAP"])])
    return 0
# Parameter: relative ET to ETm incl rain (%)
def REPRELET(model, param_0, param_1):
    if param_0 == "AVERAGE" and param_1 == "EGYPT" and ((REPPET(model, "TOTAL", "EGYPT") != 0.0)):
        return (REPET(model, "TOTAL", "EGYPT") / REPPET(model, "TOTAL", "EGYPT") * 100.0)
    R = param_1
    if param_0 == "AVERAGE" and ((REPPET(model, "TOTAL", R) != 0.0)):
        return (REPET(model, "TOTAL", R) / REPPET(model, "TOTAL", R) * 100.0)
    XC = param_0
    if param_1 == "EGYPT" and ((REPPET(model, XC, "EGYPT") != 0.0)):
        return (REPET(model, XC, "EGYPT") / REPPET(model, XC, "EGYPT") * 100.0)
    XC = param_0
    R = param_1
    if (REPPET(model, XC, R)):
        return (REPET(model, XC, R) / REPPET(model, XC, R) * 100.0)
    return 0
# Parameter: gross and net revenues at market prices (MLE)
def REPREV(model, param_0, param_1):
    R = param_0
    if param_1 == "FCOSTSP":
        return ((sum([(model.QPRDC[CIP, R].value * CSTPR(model, CIP)) for CIP in sets["CIP"]])) / 1000.0)
    R = param_0
    if param_1 == "FCOSTSC":
        return ((sum([(CSTOINP(model, XC, PT, WI, C, R) * model.XCROP[XC, PT, WI, R].value) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] for C in sets["C"]])) / 1000.0)
    R = param_0
    if param_1 == "FCOSTSA":
        return ((sum([(model.XLIVE[XA, M, R].value * table_LSOICST(XA, M, LSOINP)) for XA in sets["XA"] for M in sets["M"] for LSOINP in sets["LSOINP"]])) / 1000.0)
    if param_0 == "EGYPT" and param_1 == "NPV":
        return sum([REPREV(model, R, "NPV") for R in sets["R"]])
    R = param_0
    if param_1 == "NPV":
        return (REPREV(model, R, "GPV") - REPREV(model, R, "FCOSTS"))
    if param_0 == "EGYPT" and param_1 == "FCOSTS":
        return sum([REPREV(model, R, "FCOSTS") for R in sets["R"]])
    R = param_0
    if param_1 == "FCOSTS":
        return (((sum([(model.XLIVE[XA, M, R].value * table_LSOICST(XA, M, LSOINP)) for XA in sets["XA"] for M in sets["M"] for LSOINP in sets["LSOINP"]]) + sum([(CSTOINP(model, XC, PT, WI, C, R) * model.XCROP[XC, PT, WI, R].value) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] for C in sets["C"]]) + sum([(model.QPRDC[CIP, R].value * CSTPR(model, CIP)) for CIP in sets["CIP"]]))) / 1000.0)
    if param_0 == "EGYPT" and param_1 == "GPV":
        return sum([REPREV(model, R, "GPV") for R in sets["R"]])
    R = param_0
    if param_1 == "GPV":
        return (((sum([((REPCRP(model, CN, "MKT-PRICER") * model.QPRDC[CN, R].value)) for CN in sets["CN"]]) + sum([((REPCRP(model, CN, "MKT-PRICEU") * model.QPRDC[CN, R].value)) for CN in sets["CN"]]))) / 1000.0)
    return 0
# Parameter: gross and net revenues at farm gate prices (MLE)
def REPREVFG(model, param_0, param_1):
    R = param_0
    if param_1 == "FCOSTSP":
        return ((sum([(model.QPRDC[CIP, R].value * CSTPR(model, CIP)) for CIP in sets["CIP"]])) / 1000.0)
    R = param_0
    if param_1 == "FCOSTSC":
        return ((sum([(CSTOINP(model, XC, PT, WI, C, R) * model.XCROP[XC, PT, WI, R].value) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] for C in sets["C"]])) / 1000.0)
    R = param_0
    if param_1 == "FCOSTSA":
        return ((sum([(model.XLIVE[XA, M, R].value * table_LSOICST(XA, M, LSOINP)) for XA in sets["XA"] for M in sets["M"] for LSOINP in sets["LSOINP"]])) / 1000.0)
    if param_0 == "EGYPT" and param_1 == "NPV":
        return sum([REPREVFG(model, R, "NPV") for R in sets["R"]])
    R = param_0
    if param_1 == "NPV":
        return (REPREVFG(model, R, "GPV") - REPREVFG(model, R, "FCOSTS"))
    if param_0 == "EGYPT" and param_1 == "FCOSTS":
        return sum([REPREVFG(model, R, "FCOSTS") for R in sets["R"]])
    R = param_0
    if param_1 == "FCOSTS":
        return (((sum([(model.XLIVE[XA, M, R].value * table_LSOICST(XA, M, LSOINP)) for XA in sets["XA"] for M in sets["M"] for LSOINP in sets["LSOINP"]]) + sum([(CSTOINP(model, XC, PT, WI, C, R) * model.XCROP[XC, PT, WI, R].value) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] for C in sets["C"]]) + sum([(model.QPRDC[CIP, R].value * CSTPR(model, CIP)) for CIP in sets["CIP"]]))) / 1000.0)
    if param_0 == "EGYPT" and param_1 == "GPV":
        return sum([REPREVFG(model, R, "GPV") for R in sets["R"]])
    R = param_0
    if param_1 == "GPV":
        return (((sum([((REPCRP(model, CN, "FGP") * model.QPRDC[CN, R].value)) for CN in sets["CN"]]) + sum([((REPCRP(model, CN, "FGP") * model.QPRDC[CN, R].value)) for CN in sets["CN"]]))) / 1000.0)
    return 0
# Parameter: average drop per crop annual non rice crops ADR (m3 per ton)
def ADRPCROPAL(model, XC, param_1):
    if param_1 == "m3/t" and (((XC) in sets["ANRXC"])):
        return (sum([DROPCROPA(model, XC, C, PT, WI, R) for C in sets["C"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["ADR"])]) / ((sum([((table_RXCMAP(R, XC)) if ((((R) in sets["ADR"]))) else 0) for R in sets["R"]]) + 1e-09)) / ((len(sets["PT"]) * len(sets["WI"]))))
    return 0
# Parameter: average drop per crop annual non rice crops MER (m3 per ton)
def ADRPCROPAM(model, XC, param_1):
    if param_1 == "m3/t" and (((XC) in sets["ANRXC"])):
        return (sum([DROPCROPA(model, XC, C, PT, WI, R) for C in sets["C"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["MER"])]) / ((sum([((table_RXCMAP(R, XC)) if ((((R) in sets["MER"]))) else 0) for R in sets["R"]]) + 1e-09)) / ((len(sets["PT"]) * len(sets["WI"]))))
    return 0
# Parameter: average drop per crop annual non rice crops UER (m3 per ton)
def ADRPCROPAU(model, XC, param_1):
    if param_1 == "m3/t" and (((XC) in sets["ANRXC"])):
        return (sum([DROPCROPA(model, XC, C, PT, WI, R) for C in sets["C"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["UER"])]) / ((sum([((table_RXCMAP(R, XC)) if ((((R) in sets["UER"]))) else 0) for R in sets["R"]]) + 1e-09)) / ((len(sets["PT"]) * len(sets["WI"]))))
    return 0
# Parameter: average drop per crop perrenial crops ADR (m3 per ton)
def ADRPCROPPL(model, XC, param_1):
    if param_1 == "m3/t" and ((XC) in sets["PXC"]):
        return (sum([DROPCROPP(model, XC, C, PT, WI, R) for C in sets["C"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["ADR"])]) / ((sum([((table_RXCMAP(R, XC)) if ((((R) in sets["ADR"]))) else 0) for R in sets["R"]]) + 1e-09)))
    return 0
# Parameter: average drop per crop perrenial crops MER (m3 per ton)
def ADRPCROPPM(model, XC, param_1):
    if param_1 == "m3/t" and ((XC) in sets["PXC"]):
        return (sum([DROPCROPP(model, XC, C, PT, WI, R) for C in sets["C"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["MER"])]) / ((sum([((table_RXCMAP(R, XC)) if ((((R) in sets["MER"]))) else 0) for R in sets["R"]]) + 1e-09)))
    return 0
# Parameter: average drop per crop perrenial crops UER (m3 per ton)
def ADRPCROPPU(model, XC, param_1):
    if param_1 == "m3/t" and ((XC) in sets["PXC"]):
        return (sum([DROPCROPP(model, XC, C, PT, WI, R) for C in sets["C"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["UER"])]) / ((sum([((table_RXCMAP(R, XC)) if ((((R) in sets["UER"]))) else 0) for R in sets["R"]]) + 1e-09)))
    return 0
# Parameter: average drop per crop rice crops LE (m3 per ton)
def ADRPCROPRL(model, XC, param_1):
    if param_1 == "m3/t" and ((XC) in sets["XCRICE"]):
        return (sum([DROPCROPR(model, XC, C, PT, WI, R) for C in sets["C"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["ADR"])]) / ((sum([((table_RXCMAP(R, XC)) if ((((R) in sets["ADR"]))) else 0) for R in sets["R"]]) + 1e-09)) / ((len(sets["PT"]) * len(sets["WI"]))))
    return 0
# Parameter: regional crop per drop annual non rice crops (kg per m3)
def CROPDROPA(model, XC, C, PT, WI, R):
    if (((((XC, C) in sets["XCPCMAP"])) if (((R) in sets["RL"]) and table_RXCMAP(R, XC) and (((((XC) in sets["AXC"])) if (((not (((XC) in sets["XCRICE"]))))) else 0))) else 0)):
        return (1000.0 / DROPCROPA(model, XC, C, PT, WI, R))
    return 0
# Parameter: regional crop per drop perrenial crops (kg per m3)
def CROPDROPP(model, XC, C, PT, WI, R):
    if PT == "E" and (((((XC, C) in sets["XCPCMAP"])) if (((R) in sets["RL"]) and table_RXCMAP(R, XC) and ((XC) in sets["PXC"])) else 0)):
        return (1000.0 / DROPCROPP(model, XC, C, "E", WI, R))
    return 0
# Parameter: regional crop per drop rice crops (kg per m3)
def CROPDROPR(model, XC, C, PT, WI, R):
    if (((((XC, C) in sets["XCPCMAP"])) if (((R) in sets["RL"]) and table_RXCMAP(R, XC) and ((XC) in sets["XCRICE"])) else 0)):
        return (1000.0 / DROPCROPR(model, XC, C, PT, WI, R))
    return 0
# Parameter: average production per feddan and commodity (t per fed)
def CROPFED1(model, XC, C):
    if (((((XC, C) in sets["XCPCMAP"])) if (((REPCA(model, XC, "EGYPT") != 0.0))) else 0)):
        return CROPVIEW(model, XC, C, "PROD/FED")
    return 0
# Parameter: regional average production per feddan primary commodity (t per fed)
def CROPFEDR(model, XC, R):
    return sum([CROPFEDR1(model, XC, C, R) for C in sets["C"]])
# Parameter: energy use Deep ground water pumped to field by gov. and crop (MJ per feddan)
def EWATPPXCD(model, param_0, param_1):
    if param_0 == "AVERAGE" and param_1 == "AVERAGE" and (sum([(((model.XCROP[XC, PT, WI, R].value) if ((((R) in sets["DGW"]))) else 0) != 0.0) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]])):
        return (sum([((EWATPUMP(model, R, XC)) if ((((R) in sets["DGW"]))) else 0) for R in sets["R"] for XC in sets["XC"]]) / sum([((model.XCROP[XC, PT, WI, R].value) if ((((R) in sets["DGW"]))) else 0) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]]))
    XC = param_0
    if param_1 == "AVERAGE" and (sum([(((model.XCROP[XC, PT, WI, R].value) if ((((R) in sets["DGW"]))) else 0) != 0.0) for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]])):
        return (sum([((EWATPUMP(model, R, XC)) if ((((R) in sets["DGW"]))) else 0) for R in sets["R"]]) / sum([((model.XCROP[XC, PT, WI, R].value) if ((((R) in sets["DGW"]))) else 0) for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]]))
    R = param_1
    if param_0 == "AVERAGE" and (((((R) in sets["DGW"])) if (((((sum([model.XCROP[XC, PT, WI, R].value for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"]])) if ((((R) in sets["DGW"]))) else 0) != 0.0))) else 0)):
        return (sum([EWATPUMP(model, R, XC) for XC in sets["XC"]]) / sum([model.XCROP[XC, PT, WI, R].value for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"]]))
    XC = param_0
    R = param_1
    if (((((R) in sets["DGW"])) if (((sum([model.XCROP[XC, PT, WI, R].value for WI in sets["WI"] for PT in sets["PT"]]) != 0.0))) else 0)):
        return (EWATPUMP(model, R, XC) / sum([model.XCROP[XC, PT, WI, R].value for WI in sets["WI"] for PT in sets["PT"]]))
    return 0
# Parameter: average energy use Deep ground water pumped to field by crop (MJ per feddan)
def EWATPPXCDA(model, param_0, param_1):
    XC = param_0
    if param_1 == "AVERAGE" and (sum([(((model.XCROP[XC, PT, WI, R].value) if ((((R) in sets["DGW"]))) else 0) != 0.0) for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]])):
        return (sum([((EWATPUMP(model, R, XC)) if ((((R) in sets["DGW"]))) else 0) for R in sets["R"]]) / sum([((model.XCROP[XC, PT, WI, R].value) if ((((R) in sets["DGW"]))) else 0) for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]]))
    return 0
# Parameter: energy use Nile water pumped from mesqa to field by gov. and crop (MJ per feddan)
def EWATPPXCN(model, param_0, param_1):
    if param_0 == "AVERAGE" and param_1 == "AVERAGE" and (sum([(((model.XCROP[XC, PT, WI, R].value) if ((((R) in sets["RSW"]))) else 0) != 0.0) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]])):
        return (sum([((EWATPUMP(model, R, XC)) if ((((R) in sets["RSW"]))) else 0) for R in sets["R"] for XC in sets["XC"]]) / sum([((model.XCROP[XC, PT, WI, R].value) if ((((R) in sets["RSW"]))) else 0) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]]))
    XC = param_0
    if param_1 == "AVERAGE" and (sum([(((model.XCROP[XC, PT, WI, R].value) if ((((R) in sets["RSW"]))) else 0) != 0.0) for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]])):
        return (sum([((EWATPUMP(model, R, XC)) if ((((R) in sets["RSW"]))) else 0) for R in sets["R"]]) / sum([((model.XCROP[XC, PT, WI, R].value) if ((((R) in sets["RSW"]))) else 0) for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]]))
    R = param_1
    if param_0 == "AVERAGE" and (((((R) in sets["RSW"])) if (((sum([model.XCROP[XC, PT, WI, R].value for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"]]) != 0.0))) else 0)):
        return (sum([EWATPUMP(model, R, XC) for XC in sets["XC"]]) / sum([model.XCROP[XC, PT, WI, R].value for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"]]))
    XC = param_0
    R = param_1
    if (((((R) in sets["RSW"])) if (((sum([model.XCROP[XC, PT, WI, R].value for WI in sets["WI"] for PT in sets["PT"]]) != 0.0))) else 0)):
        return (EWATPUMP(model, R, XC) / sum([model.XCROP[XC, PT, WI, R].value for WI in sets["WI"] for PT in sets["PT"]]))
    return 0
# Parameter: average energy use Nile water pumped from mesqa to field by crop (MJ per feddan)
def EWATPPXCNA(model, param_0, param_1):
    XC = param_0
    if param_1 == "AVERAGE" and (sum([(((model.XCROP[XC, PT, WI, R].value) if ((((R) in sets["RSW"]))) else 0) != 0.0) for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]])):
        return (sum([((EWATPUMP(model, R, XC)) if ((((R) in sets["RSW"]))) else 0) for R in sets["R"]]) / sum([((model.XCROP[XC, PT, WI, R].value) if ((((R) in sets["RSW"]))) else 0) for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]]))
    return 0
# Parameter: total diversions nile to deltas (BCM)
def REPDIVDELT(model, param_0):
    if param_0 == "TOTDELTA":
        return (REPDIVDELT(model, "EASTDELTA") + REPDIVDELT(model, "MIDLDELTA") + REPDIVDELT(model, "WESTDELTA"))
    if param_0 == "WESTDELTA":
        return (REPDIVCONN(model, "ALEX", "DIV-TOT") + REPDIVCONN(model, "BEHAIRA", "DIV-TOT") + REPDIVCONN(model, "NUBARIA", "DIV-TOT"))
    if param_0 == "MIDLDELTA":
        return (REPDIVCONN(model, "GHARBIA", "DIV-TOT") + REPDIVCONN(model, "KFRSHIK", "DIV-TOT") + REPDIVCONN(model, "DAKHLIA", "DIV-TOT") + REPDIVCONN(model, "DAMIETA", "DIV-TOT") + REPDIVCONN(model, "MENUFIA", "DIV-TOT"))
    if param_0 == "EASTDELTA":
        return (REPDIVCONN(model, "SHARKIA", "DIV-TOT") + REPDIVCONN(model, "ISMALIA", "DIV-TOT") + REPDIVCONN(model, "PRTSAID", "DIV-TOT") + REPDIVCONN(model, "SUEZ", "DIV-TOT") + REPDIVCONN(model, "NSINAI", "DIV-TOT") + REPDIVCONN(model, "QLYUBIA", "DIV-TOT"))
    return 0
# Parameter: drainge flow to sea from deltas (BCM)
def REPDRASEAD(model, param_0):
    if param_0 == "TOTDELTA":
        return (REPDRASEAD(model, "EASTDELTA") + REPDRASEAD(model, "MIDLDELTA") + REPDRASEAD(model, "WESTDELTA"))
    if param_0 == "WESTDELTA":
        return sum([REPDIVCONN(model, R, "TODRAIN-T") for R in sets["R"] if ((R) in sets["WDR"])])
    if param_0 == "MIDLDELTA":
        return sum([REPDIVCONN(model, R, "TODRAIN-T") for R in sets["R"] if ((R) in sets["MDR"])])
    if param_0 == "EASTDELTA":
        return sum([REPDIVCONN(model, R, "TODRAIN-T") for R in sets["R"] if ((R) in sets["EDR"])])
    return 0
# Parameter: water use per commodity (m3 p t)
def REPETC2(model, C, param_1):
    if param_1 == "m3/t" and (((((C) in sets["TRADE"])) if (((REPETC1(model, C, "BCM") != 0.0))) else 0)):
        return (REPETC1(model, C, "BCM") / ((REPPRODC(model, C, "EGYPT") + 1e-09)) * 1000000.0)
    return 0
# Parameter: net production value at farm gate prices per fed m3 farm and manday(LE)
def REPREVFFG(model, param_0, param_1):
    if param_0 == "EGYPT" and param_1 == "NPVPWONL":
        return (sum([REPREVFG(model, R, "NPV") for R in sets["R"] if ((R) in sets["NL"])]) / sum([REPEMPL(model, R, "TOTAL") for R in sets["R"] if ((R) in sets["NL"])]) * 1000.0)
    R = param_0
    if param_1 == "NPVPWONL" and (((((R) in sets["NL"])) if (((REPEMPL(model, R, "TOTAL") != 0.0))) else 0)):
        return (REPREVFG(model, R, "NPV") / REPEMPL(model, R, "TOTAL") * 1000.0)
    if param_0 == "EGYPT" and param_1 == "NPVPWOOL":
        return (sum([REPREVFG(model, R, "NPV") for R in sets["R"] if ((R) in sets["OLC"])]) / sum([REPEMPL(model, R, "TOTAL") for R in sets["R"] if ((R) in sets["OLC"])]) * 1000.0)
    R = param_0
    if param_1 == "NPVPWOOL" and (((((R) in sets["OLC"])) if (((REPEMPL(model, R, "TOTAL") != 0.0))) else 0)):
        return (REPREVFG(model, R, "NPV") / REPEMPL(model, R, "TOTAL") * 1000.0)
    if param_0 == "EGYPT" and param_1 == "NPVPWORK":
        return (REPREVFG(model, "EGYPT", "NPV") / sum([REPEMPL(model, R, "TOTAL") for R in sets["R"]]) * 1000.0)
    R = param_0
    if param_1 == "NPVPWORK" and (((((R) in sets["RL"])) if (((REPEMPL(model, R, "TOTAL") != 0.0))) else 0)):
        return (REPREVFG(model, R, "NPV") / REPEMPL(model, R, "TOTAL") * 1000.0)
    if param_0 == "EGYPT" and param_1 == "NPVPFARM":
        return (REPREVFG(model, "EGYPT", "NPV") / sum([FARMERS(model, R) for R in sets["R"]]) * 1000.0)
    R = param_0
    if param_1 == "NPVPFARM" and ((R) in sets["RL"]):
        return (REPREVFG(model, R, "NPV") / FARMERS(model, R) * 1000.0)
    if param_0 == "EGYPT" and param_1 == "NPVPM3":
        return (REPREVFG(model, "EGYPT", "NPV") / ((sum([REPDIVCONN(model, R, "CON-AGR") for R in sets["R"]]) + sum([REPDIVCOND(model, R, "CON-AGR") for R in sets["R"]]))) / 1000.0)
    R = param_0
    if param_1 == "NPVPM3" and (((((R) in sets["RL"])) if (((R) in sets["DGW"]) and ((REPDIVCOND(model, R, "CON-AGR") != 0.0))) else 0)):
        return (REPREVFG(model, R, "NPV") / REPDIVCOND(model, R, "CON-AGR") / 1000.0)
    R = param_0
    if param_1 == "NPVPM3" and (((((R) in sets["RL"])) if (((not (((R) in sets["DGW"])))) and ((REPDIVCONN(model, R, "CON-AGR") != 0.0))) else 0)):
        return (REPREVFG(model, R, "NPV") / REPDIVCONN(model, R, "CON-AGR") / 1000.0)
    if param_0 == "EGYPT" and param_1 == "NPVPFED":
        return (REPREVFG(model, "EGYPT", "NPV") / TOTAREA(model) * 1000.0)
    R = param_0
    if param_1 == "NPVPFED" and (((((R) in sets["RL"])) if (((((QLNDSUP(model, R) + LNDRECL(model, R))) != 0.0))) else 0)):
        return (REPREVFG(model, R, "NPV") / ((QLNDSUP(model, R) + LNDRECL(model, R))) * 1000.0)
    return 0
# Parameter: nile water balance (BCM)
def REPWATBAL(model, param_0, param_1):
    if param_0 == "REUSE_DELTA" and param_1 == " ":
        return REPREUSED(model, "TOTDELTA")
    if param_0 == "IND_CONSUM_VAR" and param_1 == " ":
        return (-(sum([REPDIVCONN(model, R, "CON-IND") for R in sets["R"] if ((R) in sets["VAR"])])))
    if param_0 == "IND_CONSUM_EDR" and param_1 == " ":
        return (-(sum([REPDIVCONN(model, R, "CON-IND") for R in sets["R"] if ((R) in sets["EDR"])])))
    if param_0 == "IND_CONSUM_MDR" and param_1 == " ":
        return (-(sum([REPDIVCONN(model, R, "CON-IND") for R in sets["R"] if ((R) in sets["MDR"])])))
    if param_0 == "IND_CONSUM_WDR" and param_1 == " ":
        return (-(sum([REPDIVCONN(model, R, "CON-IND") for R in sets["R"] if ((R) in sets["WDR"])])))
    if param_0 == "MUN_CONSUM_EX-DESIL_VAR" and param_1 == " ":
        return (-(sum([REPDIVCONN(model, R, "CON-MUN") for R in sets["R"] if ((R) in sets["VAR"])])))
    if param_0 == "MUN_CONSUM_EX-DESIL_EDR" and param_1 == " ":
        return (-(sum([REPDIVCONN(model, R, "CON-MUN") for R in sets["R"] if ((R) in sets["EDR"])])))
    if param_0 == "MUN_CONSUM_EX-DESIL_MDR" and param_1 == " ":
        return (-(sum([REPDIVCONN(model, R, "CON-MUN") for R in sets["R"] if ((R) in sets["MDR"])])))
    if param_0 == "MUN_CONSUM_EX-DESIL_WDR" and param_1 == " ":
        return (-(sum([REPDIVCONN(model, R, "CON-MUN") for R in sets["R"] if ((R) in sets["WDR"])])))
    if param_0 == "AGR_CONSUM_VAR" and param_1 == " ":
        return ((-(sum([REPDIVCONN(model, R, "CON-AGR") for R in sets["R"] if ((R) in sets["VAR"])]))) + sum([EFECTRAINR(model, R) for R in sets["R"] if ((R) in sets["VAR"])]))
    if param_0 == "AGR_CONSUM_EDR" and param_1 == " ":
        return ((-(sum([REPDIVCONN(model, R, "CON-AGR") for R in sets["R"] if ((R) in sets["EDR"])]))) + sum([EFECTRAINR(model, R) for R in sets["R"] if ((R) in sets["EDR"])]))
    if param_0 == "AGR_CONSUM_MDR" and param_1 == " ":
        return ((-(sum([REPDIVCONN(model, R, "CON-AGR") for R in sets["R"] if ((R) in sets["MDR"])]))) + sum([EFECTRAINR(model, R) for R in sets["R"] if ((R) in sets["MDR"])]))
    if param_0 == "AGR_CONSUM_WDR" and param_1 == " ":
        return ((-(sum([REPDIVCONN(model, R, "CON-AGR") for R in sets["R"] if ((R) in sets["WDR"])]))) + sum([EFECTRAINR(model, R) for R in sets["R"] if ((R) in sets["WDR"])]))
    if param_0 == "RESIDUAL" and param_1 == " ":
        return (REPWATBAL(model, "HAD_RELEASE", " ") + REPWATBAL(model, "EFFECT_RAIN", " ") + REPWATBAL(model, "ENV_FLOW_TO_SEA", " ") + REPWATBAL(model, "ADD_FLOW_TO_SEA", " ") + REPWATBAL(model, "DRAIN_TO_SEA", " ") + REPWATBAL(model, "FISH_POND_TO_SEA", " ") + REPWATBAL(model, "DRAIN_TO_SINK", " ") + REPWATBAL(model, "AGR_CONSUM_GCCU", " ") + REPWATBAL(model, "MUN_CONSUM_EX-DESIL", " ") + REPWATBAL(model, "IND_CONSUM", " ") + REPWATBAL(model, "FALLOW_EVAP", " ") + REPWATBAL(model, "WET_SURF_EVAP", " "))
    if param_0 == "WET_SURF_EVAP" and param_1 == " ":
        return (-(sum([EVAP(model, R) for R in sets["R"] if ((R) in sets["RSW"])])))
    if param_0 == "FALLOW_EVAP" and param_1 == " ":
        return ((-(sum([(model.FALLOW[R, TM].value * table_FALET(R, TM)) for R in sets["R"] for TM in sets["TM"] if ((R) in sets["RSW"])]))) / 1000000.0)
    if param_0 == "IND_CONSUM" and param_1 == " ":
        return (-(REPDIVCONN(model, "EGYPT", "CON-IND")))
    if param_0 == "MUN_CONSUM_EX-DESIL" and param_1 == " ":
        return (-(REPDIVCONN(model, "EGYPT", "CON-MUN")))
    if param_0 == "AGR_CONSUM_GCCU" and param_1 == " ":
        return (-(((REPDIVCONN(model, "EGYPT", "CON-AGR") + EFECTRAINN(model)))))
    if param_0 == "DRAIN_TO_SINK" and param_1 == " ":
        return (-(sum([REPDIVCONN(model, R, "TOSINK-T") for R in sets["R"] if ((R) in sets["RSW"])])))
    if param_0 == "FISH_POND_TO_SEA" and param_1 == " ":
        return (-(scalars["SEAFLOWFP"]))
    if param_0 == "DRAIN_TO_SEA" and param_1 == " ":
        return (-(sum([REPDIVCONN(model, R, "TODRAIN-T") for R in sets["R"] if ((R) in sets["RSW"])])))
    if param_0 == "ADD_FLOW_TO_SEA" and param_1 == " ":
        return (-(((model.SEAFLOW.value - 0.7))))
    if param_0 == "ENV_FLOW_TO_SEA" and param_1 == " ":
        return (-(0.7))
    if param_0 == "EFFECT_RAIN" and param_1 == " ":
        return EFECTRAINN(model)
    if param_0 == "HAD_RELEASE" and param_1 == " ":
        return scalars["MAXREL"]
    return 0
# Parameter: deep groundwater balance (BCM)
def REPWATBALD(model, param_0, param_1):
    if param_0 == "UNUSED" and param_1 == " ":
        return (REPWATBALD(model, "MAX_DEEPGW", " ") + REPWATBALD(model, "EFFECT_RAIN", " ") + REPWATBALD(model, "TO_SINK", " ") + REPWATBALD(model, "AGR_CONSUM_GCCU", " ") + REPWATBALD(model, "MUN_CONSUM_EX-DESIL", " ") + REPWATBALD(model, "IND_CONSUM", " ") + REPWATBALD(model, "FALLOW_EVAP", " "))
    if param_0 == "FALLOW_EVAP" and param_1 == " ":
        return ((-(sum([(model.FALLOW[R, TM].value * table_FALET(R, TM)) for R in sets["R"] for TM in sets["TM"] if ((R) in sets["DGW"])]))) / 1000000.0)
    if param_0 == "IND_CONSUM" and param_1 == " ":
        return (-(REPDIVCOND(model, "EGYPT", "CON-IND")))
    if param_0 == "MUN_CONSUM_EX-DESIL" and param_1 == " ":
        return (-(REPDIVCOND(model, "EGYPT", "CON-MUN")))
    if param_0 == "AGR_CONSUM_GCCU" and param_1 == " ":
        return (-(((REPDIVCOND(model, "EGYPT", "CON-AGR") + EFECTRAIND(model)))))
    if param_0 == "TO_SINK" and param_1 == " ":
        return (-(REPDIVCOND(model, "EGYPT", "TO-SINK")))
    if param_0 == "EFFECT_RAIN" and param_1 == " ":
        return EFECTRAIND(model)
    if param_0 == "MAX_DEEPGW" and param_1 == " ":
        return scalars["MAXDGW"]
    return 0
# Parameter: total energy used for crop production (MJ)
def TOTENERGY(model, param_0, param_1):
    if param_0 == "EGYPT" and param_1 == "TOTAL":
        return sum([TOTENERGY(model, R, XC) for R in sets["R"] for XC in sets["XC"]])
    XC = param_1
    if param_0 == "TOTAL":
        return sum([TOTENERGY(model, R, XC) for R in sets["R"]])
    R = param_0
    if param_1 == "TOTAL":
        return sum([TOTENERGY(model, R, XC) for XC in sets["XC"]])
    R = param_0
    XC = param_1
    if ((R) in sets["RL"]):
        return (sum([EFERT(model, R, XC, FERT) for FERT in sets["FERT"]]) + ETFERT(model, R, XC) + EWATPUMP(model, R, XC) + ECOM(model, R, XC) + ETMECH(model, R, XC))
    return 0
# Parameter:
def VARREGF(model, ):
    return np.sqrt(sum([((np.square((WATDIST(model, R) - AVWATDIST(model)))) / (len(sets["RL"]))) for R in sets["R"] if ((R) in sets["RL"])]))
# Parameter: water used by production (BCM)
def WATPRO(model, ):
    return (sum([REPETC1(model, C, "BCM") for C in sets["C"] if ((C) in sets["TRADE2"])]) + (((((REPPRODA(model, "CMILK", "EGYPT") + REPPRODA(model, "BMILK", "EGYPT") + (REPPRODA(model, "IMILK", "EGYPT") * 500.0))) + (((REPPRODA(model, "VEAL", "EGYPT") + REPPRODA(model, "CBEEF", "EGYPT") + REPPRODA(model, "FBEEF", "EGYPT") + REPPRODA(model, "SGMT", "EGYPT") + REPPRODA(model, "PMEAT", "EGYPT") + REPPRODA(model, "EGGS", "EGYPT"))) * 4500.0))) / 1000000.0))
# Parameter: average crop per drop annual non rice crops ADR (kg per m3)
def ACRODROPAL(model, XC, param_1):
    if param_1 == "kg/m3" and (((XC) in sets["ANRXC"])):
        return (1.0 / ((ADRPCROPAL(model, XC, "m3/t") + 1e-09)) * 1000.0)
    return 0
# Parameter: average crop per drop annual non rice crops MER (kg per m3)
def ACRODROPAM(model, XC, param_1):
    if param_1 == "kg/m3" and (((XC) in sets["ANRXC"])):
        return (1.0 / ((ADRPCROPAM(model, XC, "m3/t") + 1e-09)) * 1000.0)
    return 0
# Parameter: average crop per drop annual non rice crops UER (kg per m3)
def ACRODROPAU(model, XC, param_1):
    if param_1 == "kg/m3" and (((XC) in sets["ANRXC"])):
        return (1.0 / ((ADRPCROPAU(model, XC, "m3/t") + 1e-09)) * 1000.0)
    return 0
# Parameter: average crop per drop perrenial crops ADR (kg per m3)
def ACRODROPPL(model, XC, param_1):
    if param_1 == "m3/t" and ((XC) in sets["PXC"]):
        return (1.0 / ((ADRPCROPPL(model, XC, "m3/t") + 1e-09)) * 1000.0)
    return 0
# Parameter: average crop per drop perrenial crops MER (kg per m3)
def ACRODROPPM(model, XC, param_1):
    if param_1 == "m3/t" and ((XC) in sets["PXC"]):
        return (1.0 / ((ADRPCROPPM(model, XC, "m3/t") + 1e-09)) * 1000.0)
    return 0
# Parameter: average crop per drop perrenial crops UER (kg per m3)
def ACRODROPPU(model, XC, param_1):
    if param_1 == "m3/t" and ((XC) in sets["PXC"]):
        return (1.0 / ((ADRPCROPPU(model, XC, "m3/t") + 1e-09)) * 1000.0)
    return 0
# Parameter: average crop per drop rice crops LE (kg per m3)
def ACRODROPRL(model, XC, param_1):
    if param_1 == "kg/m3" and ((XC) in sets["XCRICE"]):
        return (1.0 / ((ADRPCROPRL(model, XC, "m3/t") + 1e-09)) * 1000.0)
    return 0
# Parameter: regional LE per drop annual non rice crops (LE per m3)
def BUCKDROPA(model, XC, C, PT, WI, R):
    return (CROPDROPA(model, XC, C, PT, WI, R) * table_DEMDAT(C, "2021FGP") / 1000.0)
# Parameter: regional LE per drop perrenial crops (LE per m3)
def BUCKDROPP(model, XC, C, PT, WI, R):
    if PT == "E" and WI == "HI":
        return (CROPDROPP(model, XC, C, "E", "HI", R) * table_DEMDAT(C, "2021FGP") / 1000.0)
    return 0
# Parameter: regional LE per drop rice crops (LE per m3)
def BUCKDROPR(model, XC, C, PT, WI, R):
    return (CROPDROPR(model, XC, C, PT, WI, R) * table_DEMDAT(C, "2021FGP") / 1000.0)
# Parameter: total energy used per commodity for production and processing (MJ)
def COMENERGY(model, param_0, param_1):
    if param_0 == "TOTAL" and param_1 == "MJ":
        return sum([COMENERGY(model, C, "MJ") for C in sets["C"]])
    C = param_0
    if param_1 == "MJ" and ((C) in sets["CN"]):
        return (sum([TOTENERGY(model, "TOTAL", XC) for XC in sets["XC"] if ((XC, C) in sets["XCCMAP"])]) + sum([EAGPROCES(model, R, C) for R in sets["R"]]))
    return 0
# Parameter: average production per feddan primary commodity (t per fed)
def CROPFED(model, XC):
    return sum([CROPFED1(model, XC, C) for C in sets["C"]])
# Parameter: overall Nile system efficiency (%)
def SYSTEMEF(model, ):
    return (-(((((REPWATBAL(model, "MUN_CONSUM_EX-DESIL", " ") + REPWATBAL(model, "IND_CONSUM", " ") + REPWATBAL(model, "AGR_CONSUM_GCCU", " ") + REPWATBAL(model, "ENV_FLOW_TO_SEA", " "))) / ((REPWATBAL(model, "HAD_RELEASE", " ") + REPWATBALD(model, "EFFECT_RAIN", " "))) * 100.0))))
# Parameter: virtual water export ET only (BCM)
def VIRWATEXP(model, ):
    return (((sum([(REPEXP(model, C, "EGYPT") * REPETC2(model, C, "m3/t")) for C in sets["C"] if ((C) in sets["FCN"])]) + (REPEXP(model, "IMILK", "EGYPT") * 1020.0) + (REPIMP(model, "BMILK", "EGYPT") * 1020.0) + (REPIMP(model, "CMILK", "EGYPT") * 1020.0) + (REPEXP(model, "VEAL", "EGYPT") * 15415.0) + (REPEXP(model, "CBEEF", "EGYPT") * 15415.0) + (REPEXP(model, "FBEEF", "EGYPT") * 15415.0) + (REPEXP(model, "SGMT", "EGYPT") * 8763.0) + (REPEXP(model, "EGGS", "EGYPT") * 3265.0) + (REPEXP(model, "PMEAT", "EGYPT") * 4325.0))) / 1000000.0)
# Parameter: virtual water import ET only (BCM)
def VIRWATIMP(model, ):
    return (((sum([(REPIMP(model, C, "EGYPT") * REPETC2(model, C, "m3/t")) for C in sets["C"] if ((C) in sets["FCN"])]) + (((REPIMP(model, "IMILK", "EGYPT") * 1020.0) + (REPIMP(model, "BMILK", "EGYPT") * 1020.0) + (REPIMP(model, "CMILK", "EGYPT") * 1020.0) + (REPIMP(model, "VEAL", "EGYPT") * 15415.0) + (REPIMP(model, "CBEEF", "EGYPT") * 15415.0) + (REPIMP(model, "FBEEF", "EGYPT") * 15415.0) + (REPIMP(model, "SGMT", "EGYPT") * 8763.0) + (REPIMP(model, "EGGS", "EGYPT") * 3265.0) + (REPIMP(model, "PMEAT", "EGYPT") * 4325.0))))) / 1000000.0)
# Parameter: virtual water net import per commodity net Nile abstraction (Mm3)
def VIRWATNINC(model, C, param_1):
    if C == "PMEAT" and param_1 == "Mm3":
        return (((REPNIMP(model, "PMEAT", "EGYPT") * 4325.0)) / 1000.0 * REPDIVCONN(model, "EGYPT", "NETNILAGR") / REPWATBAL(model, "AGR_CONSUM_GCCU", " "))
    if C == "EGGS" and param_1 == "Mm3":
        return (((REPNIMP(model, "EGGS", "EGYPT") * 3265.0)) / 1000000.0 * REPDIVCONN(model, "EGYPT", "NETNILAGR") / REPWATBAL(model, "AGR_CONSUM_GCCU", " "))
    if C == "SGMT" and param_1 == "Mm3":
        return (((REPNIMP(model, "SGMT", "EGYPT") * 8763.0)) / 1000000.0 * REPDIVCONN(model, "EGYPT", "NETNILAGR") / REPWATBAL(model, "AGR_CONSUM_GCCU", " "))
    if C == "FBEEF" and param_1 == "Mm3":
        return (((REPNIMP(model, "FBEEF", "EGYPT") * 15415.0)) / 1000.0 * REPDIVCONN(model, "EGYPT", "NETNILAGR") / REPWATBAL(model, "AGR_CONSUM_GCCU", " "))
    if C == "CBEEF" and param_1 == "Mm3":
        return (((REPNIMP(model, "CBEEF", "EGYPT") * 15415.0)) / 1000.0 * REPDIVCONN(model, "EGYPT", "NETNILAGR") / REPWATBAL(model, "AGR_CONSUM_GCCU", " "))
    if C == "VEAL" and param_1 == "Mm3":
        return (((REPNIMP(model, "VEAL", "EGYPT") * 15415.0)) / 1000.0 * REPDIVCONN(model, "EGYPT", "NETNILAGR") / REPWATBAL(model, "AGR_CONSUM_GCCU", " "))
    if C == "CMILK" and param_1 == "Mm3":
        return (((REPNIMP(model, "CMILK", "EGYPT") * 1020.0)) / 1000.0 * REPDIVCONN(model, "EGYPT", "NETNILAGR") / REPWATBAL(model, "AGR_CONSUM_GCCU", " "))
    if C == "BMILK" and param_1 == "Mm3":
        return (((REPNIMP(model, "BMILK", "EGYPT") * 1020.0)) / 1000.0 * REPDIVCONN(model, "EGYPT", "NETNILAGR") / REPWATBAL(model, "AGR_CONSUM_GCCU", " "))
    if C == "IMILK" and param_1 == "Mm3":
        return (((REPNIMP(model, "IMILK", "EGYPT") * 1020.0)) / 1000.0 * REPDIVCONN(model, "EGYPT", "NETNILAGR") / REPWATBAL(model, "AGR_CONSUM_GCCU", " "))
    if param_1 == "Mm3" and ((C) in sets["FCN"]):
        return (REPNIMP(model, C, "EGYPT") * REPETC2(model, C, "m3/t") / 1000.0 * REPDIVCONN(model, "EGYPT", "NETNILAGR") / REPWATBAL(model, "AGR_CONSUM_GCCU", " "))
    return 0
# Parameter: average buck per drop annual non rice crops ADR (LE per m3)
def ABUCKDRPAL(model, XC, param_1):
    if param_1 == "LE/m3" and ((not (((XC) in sets["XCRICE"])))):
        return (sum([(BUCKDROPA(model, XC, C, PT, WI, R)) for C in sets["C"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["ADR"])]) / ((sum([((table_RXCMAP(R, XC)) if ((((R) in sets["ADR"]))) else 0) for R in sets["R"]]) + 1e-09)) / ((len(sets["PT"]) * len(sets["WI"]))))
    return 0
# Parameter: average buck per drop annual non rice crops MER (LE per m3)
def ABUCKDRPAM(model, XC, param_1):
    if param_1 == "LE/m3" and ((not (((XC) in sets["XCRICE"])))):
        return (sum([(BUCKDROPA(model, XC, C, PT, WI, R)) for C in sets["C"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["MER"])]) / ((sum([((table_RXCMAP(R, XC)) if ((((R) in sets["MER"]))) else 0) for R in sets["R"]]) + 1e-09)) / ((len(sets["PT"]) * len(sets["WI"]))))
    return 0
# Parameter: average buck per drop annual non rice crops UER (LE per m3)
def ABUCKDRPAU(model, XC, param_1):
    if param_1 == "LE/m3" and ((not (((XC) in sets["XCRICE"])))):
        return (sum([(BUCKDROPA(model, XC, C, PT, WI, R)) for C in sets["C"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["UER"])]) / ((sum([((table_RXCMAP(R, XC)) if ((((R) in sets["UER"]))) else 0) for R in sets["R"]]) + 1e-09)) / ((len(sets["PT"]) * len(sets["WI"]))))
    return 0
# Parameter: average buck per drop perrenial crops ADR (LE per m3)
def ABUCKDRPPL(model, XC, param_1):
    if param_1 == "LE/m3" and ((XC) in sets["PXC"]):
        return (sum([BUCKDROPP(model, XC, C, PT, WI, R) for C in sets["C"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["ADR"])]) / ((sum([((table_RXCMAP(R, XC)) if ((((R) in sets["ADR"]))) else 0) for R in sets["R"]]) + 1e-09)))
    return 0
# Parameter: average buck per drop perrenial crops MER (LE per m3)
def ABUCKDRPPM(model, XC, param_1):
    if param_1 == "LE/m3" and ((XC) in sets["PXC"]):
        return (sum([BUCKDROPP(model, XC, C, PT, WI, R) for C in sets["C"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["MER"])]) / ((sum([((table_RXCMAP(R, XC)) if ((((R) in sets["MER"]))) else 0) for R in sets["R"]]) + 1e-09)))
    return 0
# Parameter: average buck per drop perrenial crops UER (LE per m3)
def ABUCKDRPPU(model, XC, param_1):
    if param_1 == "LE/m3" and ((XC) in sets["PXC"]):
        return (sum([BUCKDROPP(model, XC, C, PT, WI, R) for C in sets["C"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["UER"])]) / ((sum([((table_RXCMAP(R, XC)) if ((((R) in sets["UER"]))) else 0) for R in sets["R"]]) + 1e-09)))
    return 0
# Parameter: average buck per drop rice crops LE (LE per m3)
def ABUCKDRPRL(model, XC, param_1):
    if param_1 == "LE/m3" and ((XC) in sets["XCRICE"]):
        return (sum([(BUCKDROPR(model, XC, C, PT, WI, R)) for C in sets["C"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if ((R) in sets["ADR"])]) / ((sum([((table_RXCMAP(R, XC)) if ((((R) in sets["ADR"]))) else 0) for R in sets["R"]]) + 1e-09)) / ((len(sets["PT"]) * len(sets["WI"]))))
    return 0
# Parameter: total commodity production per energy unit for production and processing (kg per TJ)
def COMENERGYJ(model, param_0, param_1):
    C = param_0
    if param_1 == "kg/TJ" and (((((C) in sets["CN"])) if (((COMENERGY(model, C, "MJ") != 0.0))) else 0)):
        return (((REPPRODC(model, C, "EGYPT") / 1000.0)) / COMENERGY(model, C, "MJ") * 1000000.0)
    return 0
# Parameter: relation of total energy used to produce commodities and their energy value (fraction)
def COMENERGYR(model, param_0, param_1):
    C = param_0
    if param_1 == "EU/EV" and (((((C) in sets["CN"])) if (((COMENERGYV(model, C, "MJ") != 0.0))) else 0)):
        return (COMENERGY(model, C, "MJ") / COMENERGYV(model, C, "MJ"))
    return 0
# Parameter: total energy used per ton of commodity production and processing (MJ per t)
def COMENERGYT(model, param_0, param_1):
    C = param_0
    if param_1 == "MJ/t" and (((((C) in sets["CN"])) if (((REPPRODC(model, C, "EGYPT") != 0.0))) else 0)):
        return (COMENERGY(model, C, "MJ") / REPPRODC(model, C, "EGYPT"))
    return 0
# Parameter: virtual water net import ET only (BCM)
def VIRWATNIN(model, ):
    return (VIRWATIMP(model) - VIRWATEXP(model))
# Parameter: virtual energy export per commodity (MJ)
def VIRTENEXP(model, param_0, param_1):
    if param_0 == "EGGS" and param_1 == "MJ":
        return (REPEXP(model, "EGGS", "EGYPT") * 31747000.0 * 1000.0)
    if param_0 == "SGMT" and param_1 == "MJ":
        return (REPEXP(model, "SGMT", "EGYPT") * 1000000.0 * 1000.0)
    if param_0 == "FBEEF" and param_1 == "MJ":
        return (REPEXP(model, "FBEEF", "EGYPT") * 25000000.0 * 1000.0)
    if param_0 == "CBEEF" and param_1 == "MJ":
        return (REPEXP(model, "CBEEF", "EGYPT") * 25000000.0 * 1000.0)
    if param_0 == "VEAL" and param_1 == "MJ":
        return (REPEXP(model, "VEAL", "EGYPT") * 25000000.0 * 1000.0)
    if param_0 == "CMILK" and param_1 == "MJ":
        return (REPEXP(model, "CMILK", "EGYPT") * 595200.0 * 1000.0)
    if param_0 == "BMILK" and param_1 == "MJ":
        return (REPEXP(model, "BMILK", "EGYPT") * 595200.0 * 1000.0)
    if param_0 == "IMILK" and param_1 == "MJ":
        return (REPEXP(model, "IMILK", "EGYPT") * 595200.0 * 1000.0)
    C = param_0
    if param_1 == "MJ" and ((C) in sets["FCN"]):
        return (REPEXP(model, C, "EGYPT") * COMENERGYT(model, C, "MJ/t") * 1000.0)
    return 0
# Parameter: virtual energy import per commodity (MJ)
def VIRTENIMP(model, param_0, param_1):
    if param_0 == "EGGS" and param_1 == "MJ":
        return (REPIMP(model, "EGGS", "EGYPT") * 31747000.0 * 1000.0)
    if param_0 == "SGMT" and param_1 == "MJ":
        return (REPIMP(model, "SGMT", "EGYPT") * 10000000.0 * 1000.0)
    if param_0 == "FBEEF" and param_1 == "MJ":
        return (REPIMP(model, "FBEEF", "EGYPT") * 25000000.0 * 1000.0)
    if param_0 == "CBEEF" and param_1 == "MJ":
        return (REPIMP(model, "CBEEF", "EGYPT") * 2500000.0 * 1000.0)
    if param_0 == "VEAL" and param_1 == "MJ":
        return (REPIMP(model, "VEAL", "EGYPT") * 2500000.0 * 1000.0)
    if param_0 == "CMILK" and param_1 == "MJ":
        return (REPIMP(model, "CMILK", "EGYPT") * 595200.0 * 1000.0)
    if param_0 == "BMILK" and param_1 == "MJ":
        return (REPIMP(model, "BMILK", "EGYPT") * 595200.0 * 1000.0)
    if param_0 == "IMILK" and param_1 == "MJ":
        return (REPIMP(model, "IMILK", "EGYPT") * 595200.0 * 1000.0)
    C = param_0
    if param_1 == "MJ" and ((C) in sets["FCN"]):
        return (REPIMP(model, C, "EGYPT") * COMENERGYT(model, C, "MJ/t") * 1000.0)
    return 0
# Parameter: net virtual energy import per commodity (MJ);
def VIRTENNIMP(model, param_0, param_1):
    C = param_0
    if param_1 == "MJ":
        return (VIRTENIMP(model, C, "MJ") - VIRTENEXP(model, C, "MJ"))
    return 0

def make_CC_set():
    newSet = set()
    # Original: CC(C)=C(C) -CA(C)
    newSet = newSet.union(set(sets["C"]).difference(set(sets["CA"]).intersection(set(sets["C"]))))
    return list(newSet)

sets["CC"] = make_CC_set()
def make_NL_set():
    newSet = set()
    # Original: NL(R)=R(R) -OL(R)
    newSet = newSet.union(set(sets["R"]).difference(set(sets["OL"]).intersection(set(sets["R"]))))
    return list(newSet)

sets["NL"] = make_NL_set()
def make_CHL_set():
    newSet = set()
    # Original: CHL(C)=CN(C) * CF(C)
    newSet = newSet.union(set(sets["CN"]).intersection(set(sets["C"])).intersection(set(sets["CF"]).intersection(set(sets["C"]))))
    return list(newSet)

sets["CHL"] = make_CHL_set()
def make_RICEMAP_set():
    newSet = set()
    # Original: RICEMAP(R) = NO
    # Original: RICEMAP(R) = YES$(SUM(XC, RXCMAP(R, "PADDY1")))
    for R in sets["R"]:
        if sum([table_RXCMAP(R, "PADDY1") for XC in sets["XC"]]):
            newSet.add((R))
    return list(newSet)

sets["RICEMAP"] = make_RICEMAP_set()
def make_RCMAP_set():
    newSet = set()
    # Original: RCMAP(R, C) = NO
    # Original: RCMAP(R, C) = YES$(SUM(XC, (XCCMAP(XC, C) * RXCMAP(R, XC))))
    for R in sets["R"]:
        for C in sets["C"]:
            if sum([((((XC, C) in sets["XCCMAP"]) * table_RXCMAP(R, XC))) for XC in sets["XC"]]):
                newSet.add((R, C))
    return list(newSet)

sets["RCMAP"] = make_RCMAP_set()
def make_CHECK0_set():
    newSet = set()
    # Original: CHECK0(XC, PT, R, TM)=YES$(LNDREQ(XC, PT, R, TM)LT 0 OR LNDREQ(XC, PT, R, TM)GT 1)
    for XC in sets["XC"]:
        for PT in sets["PT"]:
            for R in sets["R"]:
                for TM in sets["TM"]:
                    if (((LNDREQ(model, XC, PT, R, TM) < 0.0)) or ((LNDREQ(model, XC, PT, R, TM) > 1.0))):
                        newSet.add((XC, PT, R, TM))
    return list(newSet)

sets["CHECK0"] = make_CHECK0_set()
def make_CHECK0AA_set():
    newSet = set()
    # Original: CHECK0AA(XC, PT, R)$(RL(R)$RXCMAP(R, XC)$AXC(XC))=     YES$(SUM(TM, LNDREQ(XC, PT, R, TM))LT 2.7 OR SUM(TM, LNDREQ(XC, PT, R, TM))GT 7)
    for XC in sets["XC"]:
        for PT in sets["PT"]:
            for R in sets["R"]:
                if (((((R) in sets["RL"])) if (table_RXCMAP(R, XC) and ((XC) in sets["AXC"])) else 0)):
                    if (((sum([LNDREQ(model, XC, PT, R, TM) for TM in sets["TM"]]) < 2.7)) or ((sum([LNDREQ(model, XC, PT, R, TM) for TM in sets["TM"]]) > 7.0))):
                        newSet.add((XC, PT, R))
    # Original: CHECK0AA(XC, "E", R)$(RL(R)$RXCMAP(R, XC)$PXC(XC))=                                  YES$(SUM(TM, LNDREQ(XC, "E", R, TM))NE 12)
    for XC in sets["XC"]:
        for R in sets["R"]:
            if (((((R) in sets["RL"])) if (table_RXCMAP(R, XC) and ((XC) in sets["PXC"])) else 0)):
                if (sum([LNDREQ(model, XC, "E", R, TM) for TM in sets["TM"]]) != 12.0):
                    newSet.add((XC, "E", R))
    return list(newSet)

sets["CHECK0AA"] = make_CHECK0AA_set()
def make_CHECK0A_set():
    newSet = set()
    # Original: CHECK0A(XC, PT, R)$AXC(XC) = (abs(SUM(TM, LNDREQ(XC, "O", R, TM)) -SUM(TM, LNDREQ(XC, "E", R, TM))) > 1e-12) OR (abs(SUM(TM, LNDREQ(XC, "O", R, TM)) -SUM(TM, LNDREQ(XC, "L", R, TM))) > 1e-12)
    for XC in sets["XC"]:
        for PT in sets["PT"]:
            for R in sets["R"]:
                if ((((abs((sum([LNDREQ(model, XC, "O", R, TM) for TM in sets["TM"]]) - sum([LNDREQ(model, XC, "E", R, TM) for TM in sets["TM"]]))) > 1e-12))) or (((abs((sum([LNDREQ(model, XC, "O", R, TM) for TM in sets["TM"]]) - sum([LNDREQ(model, XC, "L", R, TM) for TM in sets["TM"]]))) > 1e-12)))):
                    newSet.add((XC, PT, R))
    return list(newSet)

sets["CHECK0A"] = make_CHECK0A_set()
def make_CHECK1_set():
    newSet = set()
    # Original: CHECK1(XC, PT, R, TM)$(RXCMAP(R, XC)$RL(R))=YES$(LNDREQ(XC, PT, R, TM)GT 0AND LABREQC1(XC, PT, R, TM)LE 0)
    for XC in sets["XC"]:
        for PT in sets["PT"]:
            for R in sets["R"]:
                for TM in sets["TM"]:
                    if (((table_RXCMAP(R, XC)) if (((R) in sets["RL"])) else 0)):
                        if (((LNDREQ(model, XC, PT, R, TM) > 0.0)) and ((table_LABREQC1(XC, PT, R, TM) <= 0.0))):
                            newSet.add((XC, PT, R, TM))
    return list(newSet)

sets["CHECK1"] = make_CHECK1_set()
def make_CHECK1A_set():
    newSet = set()
    # Original: CHECK1A(XC, PT, R)$AXC(XC) = (abs(SUM(TM, LABREQC1(XC, "O", R, TM)) -SUM(TM, LABREQC1(XC, "E", R, TM))) > 1e-12) OR (abs(SUM(TM, LABREQC1(XC, "O", R, TM)) -SUM(TM, LABREQC1(XC, "L", R, TM))) > 1e-12)
    for XC in sets["XC"]:
        for PT in sets["PT"]:
            for R in sets["R"]:
                if ((((abs((sum([table_LABREQC1(XC, "O", R, TM) for TM in sets["TM"]]) - sum([table_LABREQC1(XC, "E", R, TM) for TM in sets["TM"]]))) > 1e-12))) or (((abs((sum([table_LABREQC1(XC, "O", R, TM) for TM in sets["TM"]]) - sum([table_LABREQC1(XC, "L", R, TM) for TM in sets["TM"]]))) > 1e-12)))):
                    newSet.add((XC, PT, R))
    return list(newSet)

sets["CHECK1A"] = make_CHECK1A_set()
def make_CHECK2A_set():
    newSet = set()
    # Original: CHECK2A(XC, PT, R, TM)=YES$(LABREQC1(XC, PT, R, TM)LT 0 OR LABREQC1(XC, PT, R, TM)GT 45)
    for XC in sets["XC"]:
        for PT in sets["PT"]:
            for R in sets["R"]:
                for TM in sets["TM"]:
                    if (((table_LABREQC1(XC, PT, R, TM) < 0.0)) or ((table_LABREQC1(XC, PT, R, TM) > 45.0))):
                        newSet.add((XC, PT, R, TM))
    return list(newSet)

sets["CHECK2A"] = make_CHECK2A_set()
def make_CHECK2_set():
    newSet = set()
    # Original: CHECK2(XC, PT, R, TM)=YES$(LABREQC1(XC, PT, R, TM)GT 0 AND LNDREQ(XC, PT, R, TM)LE 0)
    for XC in sets["XC"]:
        for PT in sets["PT"]:
            for R in sets["R"]:
                for TM in sets["TM"]:
                    if (((table_LABREQC1(XC, PT, R, TM) > 0.0)) and ((LNDREQ(model, XC, PT, R, TM) <= 0.0))):
                        newSet.add((XC, PT, R, TM))
    return list(newSet)

sets["CHECK2"] = make_CHECK2_set()
def make_CHECK3_set():
    newSet = set()
    # Original: CHECK3(R, TM)$RL(R)=YES$(WAVG(R, TM)LE 10 OR WAVG(R, TM)GT 300)
    for R in sets["R"]:
        for TM in sets["TM"]:
            if ((R) in sets["RL"]):
                if (((WAVG(model, R, TM) <= 10.0)) or ((WAVG(model, R, TM) > 300.0))):
                    newSet.add((R, TM))
    return list(newSet)

sets["CHECK3"] = make_CHECK3_set()
def make_CHECK6_set():
    newSet = set()
    # Original: CHECK6(XC, PT, R)$(RXCMAP(R, XC)$RL(R))= YES$(WATER0(XC, PT, R)LE 560 OR WATER0(XC, PT, R)GT 12000)
    for XC in sets["XC"]:
        for PT in sets["PT"]:
            for R in sets["R"]:
                if (((table_RXCMAP(R, XC)) if (((R) in sets["RL"])) else 0)):
                    if (((table_WATER0(XC, PT, R) <= 560.0)) or ((table_WATER0(XC, PT, R) > 12000.0))):
                        newSet.add((XC, PT, R))
    return list(newSet)

sets["CHECK6"] = make_CHECK6_set()
def make_CHECK6A_set():
    newSet = set()
    # Original: CHECK6A(XC, PT, R)$(RXCMAP(R, XC)$RL(R))=                     YES$(WATER0(XC, PT, R)LE 340)
    for XC in sets["XC"]:
        for PT in sets["PT"]:
            for R in sets["R"]:
                if (((table_RXCMAP(R, XC)) if (((R) in sets["RL"])) else 0)):
                    if (table_WATER0(XC, PT, R) <= 340.0):
                        newSet.add((XC, PT, R))
    return list(newSet)

sets["CHECK6A"] = make_CHECK6A_set()
def make_CHECK12_set():
    newSet = set()
    # Original: CHECK12(XC, C, R)$(RXCMAP(R, XC)$RL(R)$XCPCMAP(XC, C))=YES$(YIELD0(XC, C, R)LE 0OR YIELD0(XC, C, R)GT 110)
    for XC in sets["XC"]:
        for C in sets["C"]:
            for R in sets["R"]:
                if (((table_RXCMAP(R, XC)) if (((R) in sets["RL"]) and ((XC, C) in sets["XCPCMAP"])) else 0)):
                    if (((YIELD0(model, XC, C, R) <= 0.0)) or ((YIELD0(model, XC, C, R) > 110.0))):
                        newSet.add((XC, C, R))
    return list(newSet)

sets["CHECK12"] = make_CHECK12_set()
def make_CHECK12H_set():
    newSet = set()
    # Original: CHECK12H(XC, C, R)$(RXCMAP(R, XC)$RL(R)$XCCMAP(XC, C))=YES$(YIELD0(XC, C, R)LE 0)
    for XC in sets["XC"]:
        for C in sets["C"]:
            for R in sets["R"]:
                if (((table_RXCMAP(R, XC)) if (((R) in sets["RL"]) and ((XC, C) in sets["XCCMAP"])) else 0)):
                    if (YIELD0(model, XC, C, R) <= 0.0):
                        newSet.add((XC, C, R))
    return list(newSet)

sets["CHECK12H"] = make_CHECK12H_set()
def make_CHECK12A_set():
    newSet = set()
    # Original: CHECK12A(XC, C, "2017")$XCPCMAP(XC, C)=YES$(YLDINC(XC, C, "2017")LE 0 OR YLDINC(XC, C, "2017")GT 1.5)
    for XC in sets["XC"]:
        for C in sets["C"]:
            if ((XC, C) in sets["XCPCMAP"]):
                if (((table_YLDINC(XC, C, "2017") <= 0.0)) or ((table_YLDINC(XC, C, "2017") > 1.5))):
                    newSet.add((XC, C, "2017"))
    return list(newSet)

sets["CHECK12A"] = make_CHECK12A_set()
def make_CHECK12AA_set():
    newSet = set()
    # Original: CHECK12AA(XC, C, "2030")$XCPCMAP(XC, C)=YES$(YLDINC(XC, C, "2030")LE 0 OR YLDINC(XC, C, "2030")GT 2.2)
    for XC in sets["XC"]:
        for C in sets["C"]:
            if ((XC, C) in sets["XCPCMAP"]):
                if (((table_YLDINC(XC, C, "2030") <= 0.0)) or ((table_YLDINC(XC, C, "2030") > 2.2))):
                    newSet.add((XC, C, "2030"))
    return list(newSet)

sets["CHECK12AA"] = make_CHECK12AA_set()
def make_CHECK12B_set():
    newSet = set()
    # Original: CHECK12B(XC, C)$XCPCMAP(XC, C)=YES$(AVYIELD(XC, C)LE 0 OR AVYIELD(XC, C)GT 55)
    for XC in sets["XC"]:
        for C in sets["C"]:
            if ((XC, C) in sets["XCPCMAP"]):
                if (((AVYIELD(model, XC, C) <= 0.0)) or ((AVYIELD(model, XC, C) > 55.0))):
                    newSet.add((XC, C))
    return list(newSet)

sets["CHECK12B"] = make_CHECK12B_set()
def make_CHECK48_set():
    newSet = set()
    # Original: CHECK48(WI)=YES$(WDEF(WI)LT 0 OR WDEF(WI)GT 0.5)
    for WI in sets["WI"]:
        if (((WDEF(model, WI) < 0.0)) or ((WDEF(model, WI) > 0.5))):
            newSet.add((WI))
    return list(newSet)

sets["CHECK48"] = make_CHECK48_set()
def make_CHECK12C_set():
    newSet = set()
    # Original: CHECK12C(XC)=YES$(KY(XC)LE 0 OR KY(XC)GT 2)
    for XC in sets["XC"]:
        if (((KY(model, XC) <= 0.0)) or ((KY(model, XC) > 2.0))):
            newSet.add((XC))
    return list(newSet)

sets["CHECK12C"] = make_CHECK12C_set()
def make_CHECK12D_set():
    newSet = set()
    # Original: CHECK12D(XC, "NLINCST")=YES$(INPUT(XC, "NLINCST")LE 150)
    for XC in sets["XC"]:
        if (table_INPUT(XC, "NLINCST") <= 150.0):
            newSet.add((XC, "NLINCST"))
    return list(newSet)

sets["CHECK12D"] = make_CHECK12D_set()
def make_CHECK12F_set():
    newSet = set()
    # Original: CHECK12F(XC, "IRRICST")=YES$(INPUT(XC, "IRRICST")LE 50)
    for XC in sets["XC"]:
        if (table_INPUT(XC, "IRRICST") <= 50.0):
            newSet.add((XC, "IRRICST"))
    return list(newSet)

sets["CHECK12F"] = make_CHECK12F_set()
def make_CHECK12E_set():
    newSet = set()
    # Original: CHECK12E(XC, "RENT")=YES$(INPUT(XC, "RENT")LE 0)
    for XC in sets["XC"]:
        if (table_INPUT(XC, "RENT") <= 0.0):
            newSet.add((XC, "RENT"))
    return list(newSet)

sets["CHECK12E"] = make_CHECK12E_set()
def make_CHECK13_set():
    newSet = set()
    # Original: CHECK13(CIP)=YES$(CSTPR(CIP)LE 0)
    for CIP in sets["CIP"]:
        if (CSTPR(model, CIP) <= 0.0):
            newSet.add((CIP))
    return list(newSet)

sets["CHECK13"] = make_CHECK13_set()
def make_CHECK14_set():
    newSet = set()
    # Original: CHECK14(CIP)=YES$(LABPR(CIP)LE 0)
    for CIP in sets["CIP"]:
        if (LABPR(model, CIP) <= 0.0):
            newSet.add((CIP))
    return list(newSet)

sets["CHECK14"] = make_CHECK14_set()
def make_CHECK15_set():
    newSet = set()
    # Original: CHECK15(C, "BASE-P")$(CN(C))=YES$(DEMDAT(C, "BASE-P")LE 0)
    for C in sets["C"]:
        if (((C) in sets["CN"])):
            if (table_DEMDAT(C, "BASE-P") <= 0.0):
                newSet.add((C, "BASE-P"))
    return list(newSet)

sets["CHECK15"] = make_CHECK15_set()
def make_CHECK15D_set():
    newSet = set()
    # Original: CHECK15D(C, "EXP-P")$(DEMDAT(C, "EXP-P")GT 0 AND DEMDAT(C, "IMP-P")GT 0)=                        YES$(DEMDAT(C, "EXP-P")GT DEMDAT(C, "IMP-P"))
    for C in sets["C"]:
        if ((((table_DEMDAT(C, "EXP-P") > 0.0)) and ((table_DEMDAT(C, "IMP-P") > 0.0)))):
            if (table_DEMDAT(C, "EXP-P") > table_DEMDAT(C, "IMP-P")):
                newSet.add((C, "EXP-P"))
    return list(newSet)

sets["CHECK15D"] = make_CHECK15D_set()
def make_CHECK16A_set():
    newSet = set()
    # Original: CHECK16A(C, "HUMCONR")$(CN(C))=YES$(DEMDAT(C, "HUMCONR")LE 0)
    for C in sets["C"]:
        if (((C) in sets["CN"])):
            if (table_DEMDAT(C, "HUMCONR") <= 0.0):
                newSet.add((C, "HUMCONR"))
    return list(newSet)

sets["CHECK16A"] = make_CHECK16A_set()
def make_CHECK16B_set():
    newSet = set()
    # Original: CHECK16B(C, "HUMCONU")$(CN(C))=YES$(DEMDAT(C, "HUMCONU")LE 0)
    for C in sets["C"]:
        if (((C) in sets["CN"])):
            if (table_DEMDAT(C, "HUMCONU") <= 0.0):
                newSet.add((C, "HUMCONU"))
    return list(newSet)

sets["CHECK16B"] = make_CHECK16B_set()
def make_CHECK17A_set():
    newSet = set()
    # Original: CHECK17A(C, "PRIELASR")$(CN(C))=YES$(DEMDAT(C, "PRIELASR")LE -4 OR DEMDAT(C, "PRIELASR")GE 0)
    for C in sets["C"]:
        if (((C) in sets["CN"])):
            if (((table_DEMDAT(C, "PRIELASR") <= (-(4.0)))) or ((table_DEMDAT(C, "PRIELASR") >= 0.0))):
                newSet.add((C, "PRIELASR"))
    return list(newSet)

sets["CHECK17A"] = make_CHECK17A_set()
def make_CHECK17B_set():
    newSet = set()
    # Original: CHECK17B(C, "PRIELASU")$(CN(C))=YES$(DEMDAT(C, "PRIELASU")LE -4 OR DEMDAT(C, "PRIELASU")GE 0)
    for C in sets["C"]:
        if (((C) in sets["CN"])):
            if (((table_DEMDAT(C, "PRIELASU") <= (-(4.0)))) or ((table_DEMDAT(C, "PRIELASU") >= 0.0))):
                newSet.add((C, "PRIELASU"))
    return list(newSet)

sets["CHECK17B"] = make_CHECK17B_set()
def make_CHECK17C_set():
    newSet = set()
    # Original: CHECK17C(C, "PRIER05")$(CN(C))=YES$(DEMDAT(C, "PRIER05")LE -4 OR DEMDAT(C, "PRIER05")GE 1)
    for C in sets["C"]:
        if (((C) in sets["CN"])):
            if (((table_DEMDAT(C, "PRIER05") <= (-(4.0)))) or ((table_DEMDAT(C, "PRIER05") >= 1.0))):
                newSet.add((C, "PRIER05"))
    return list(newSet)

sets["CHECK17C"] = make_CHECK17C_set()
def make_CHECK17D_set():
    newSet = set()
    # Original: CHECK17D(C, "PRIEU05")$(CN(C))=YES$(DEMDAT(C, "PRIEU05")LE -4 OR DEMDAT(C, "PRIEU05")GE 1)
    for C in sets["C"]:
        if (((C) in sets["CN"])):
            if (((table_DEMDAT(C, "PRIEU05") <= (-(4.0)))) or ((table_DEMDAT(C, "PRIEU05") >= 1.0))):
                newSet.add((C, "PRIEU05"))
    return list(newSet)

sets["CHECK17D"] = make_CHECK17D_set()
def make_CHECK17E_set():
    newSet = set()
    # Original: CHECK17E(C, "PELAR05")$(CN(C))=YES$(DEMDAT(C, "PELAR05")EQ 0)
    for C in sets["C"]:
        if (((C) in sets["CN"])):
            if (table_DEMDAT(C, "PELAR05") == 0.0):
                newSet.add((C, "PELAR05"))
    return list(newSet)

sets["CHECK17E"] = make_CHECK17E_set()
def make_CHECK12K_set():
    newSet = set()
    # Original: CHECK12K(XC, "75")=YES$(SALTOL(XC, "75")LE 1200)
    for XC in sets["XC"]:
        if (table_SALTOL(XC, "75") <= 1200.0):
            newSet.add((XC, "75"))
    return list(newSet)

sets["CHECK12K"] = make_CHECK12K_set()
def make_CHECK12G_set():
    newSet = set()
    # Original: CHECK12G(XC, "100")=YES$(SALTOL(XC, "100")LE 500)
    for XC in sets["XC"]:
        if (table_SALTOL(XC, "100") <= 500.0):
            newSet.add((XC, "100"))
    return list(newSet)

sets["CHECK12G"] = make_CHECK12G_set()
def make_CHECK40_set():
    newSet = set()
    # Original: CHECK40(XC, "SEA")=YES$(HAREAS(XC, "SEA")LE 0)
    for XC in sets["XC"]:
        if (table_HAREAS(XC, "SEA") <= 0.0):
            newSet.add((XC, "SEA"))
    return list(newSet)

sets["CHECK40"] = make_CHECK40_set()
def make_CHECK18_set():
    newSet = set()
    # Original: CHECK18(XA, M)$XAMMAP(XA, M)=YES$(SUM(FEEDS, FEEDREQ(XA, M, FEEDS))LE 0)
    for XA in sets["XA"]:
        for M in sets["M"]:
            if ((XA, M) in sets["XAMMAP"]):
                if (sum([table_FEEDREQ(XA, M, FEEDS) for FEEDS in sets["FEEDS"]]) <= 0.0):
                    newSet.add((XA, M))
    return list(newSet)

sets["CHECK18"] = make_CHECK18_set()
def make_CHECK22_set():
    newSet = set()
    # Original: CHECK22(XA, M, LSLAB)$XAMMAP(XA, M)=YES$(LABREQLS(XA, M, LSLAB)LE 0                         OR LABREQLS(XA, M, LSLAB)GT 12000)
    for XA in sets["XA"]:
        for M in sets["M"]:
            for LSLAB in sets["LSLAB"]:
                if ((XA, M) in sets["XAMMAP"]):
                    if (((table_LABREQLS(XA, M, LSLAB) <= 0.0)) or ((table_LABREQLS(XA, M, LSLAB) > 12000.0))):
                        newSet.add((XA, M, LSLAB))
    return list(newSet)

sets["CHECK22"] = make_CHECK22_set()
def make_CHECK23_set():
    newSet = set()
    # Original: CHECK23(XA, M)$XAMMAP(XA, M)=YES$(SUM(LSOINP,LSOICST(XA, M, LSOINP))LE 0)
    for XA in sets["XA"]:
        for M in sets["M"]:
            if ((XA, M) in sets["XAMMAP"]):
                if (sum([table_LSOICST(XA, M, LSOINP) for LSOINP in sets["LSOINP"]]) <= 0.0):
                    newSet.add((XA, M))
    return list(newSet)

sets["CHECK23"] = make_CHECK23_set()
def make_CHECK24_set():
    newSet = set()
    # Original: CHECK24(XA, M)$XAMMAP(XA, M)=YES$(SUM(C, YLDA(XA, M, C))LE 0)
    for XA in sets["XA"]:
        for M in sets["M"]:
            if ((XA, M) in sets["XAMMAP"]):
                if (sum([table_YLDA(XA, M, C) for C in sets["C"]]) <= 0.0):
                    newSet.add((XA, M))
    return list(newSet)

sets["CHECK24"] = make_CHECK24_set()
def make_CHECK43_set():
    newSet = set()
    # Original: CHECK43(R)$(NOT SEA(R))=YES$(IEFF(R)LE 0 OR IEFF(R)GT 1)
    for R in sets["R"]:
        if ((not (((R) in sets["SEA"])))):
            if (((IEFF(model, R) <= 0.0)) or ((IEFF(model, R) > 1.0))):
                newSet.add((R))
    return list(newSet)

sets["CHECK43"] = make_CHECK43_set()
def make_CHECK43B_set():
    newSet = set()
    # Original: CHECK43B(R)$(NOT SEA(R))=YES$(FEFF(R)LE 0 OR FEFF(R)GT 1)
    for R in sets["R"]:
        if ((not (((R) in sets["SEA"])))):
            if (((FEFF(model, R) <= 0.0)) or ((FEFF(model, R) > 1.0))):
                newSet.add((R))
    return list(newSet)

sets["CHECK43B"] = make_CHECK43B_set()
def make_CHECK44A_set():
    newSet = set()
    # Original: CHECK44A(R)$(RL(R))=YES$(MUNDEM(R)LE 0)
    for R in sets["R"]:
        if (((R) in sets["RL"])):
            if (MUNDEM(model, R) <= 0.0):
                newSet.add((R))
    return list(newSet)

sets["CHECK44A"] = make_CHECK44A_set()
def make_CHECK45_set():
    newSet = set()
    # Original: CHECK45(R)$RL(R)=YES$(INDDEM(R)LE 0)
    for R in sets["R"]:
        if ((R) in sets["RL"]):
            if (INDDEM(model, R) <= 0.0):
                newSet.add((R))
    return list(newSet)

sets["CHECK45"] = make_CHECK45_set()
def make_CHECK46_set():
    newSet = set()
    # Original: CHECK46(R)$RL(R)=YES$(MUNRET(R)LT 0 OR MUNRET(R)GT 1)
    for R in sets["R"]:
        if ((R) in sets["RL"]):
            if (((MUNRET(model, R) < 0.0)) or ((MUNRET(model, R) > 1.0))):
                newSet.add((R))
    return list(newSet)

sets["CHECK46"] = make_CHECK46_set()

if (len(sets["CHECK0"]) > 0.0):
    print("Error: CHECK0;")
    print("  Elements that generate errors:", sets["CHECK0"])
if (len(sets["CHECK0AA"]) > 0.0):
    print("Error: CHECK0AA;")
    print("  Elements that generate errors:", sets["CHECK0AA"])
if (len(sets["CHECK0A"]) > 0.0):
    print("Error: CHECK0A;")
    print("  Elements that generate errors:", sets["CHECK0A"])
if (len(sets["CHECK1"]) > 0.0):
    print("Error: CHECK1;")
    print("  Elements that generate errors:", sets["CHECK1"])
if (len(sets["CHECK1A"]) > 0.0):
    print("Error: CHECK1A;")
    print("  Elements that generate errors:", sets["CHECK1A"])
if (len(sets["CHECK2A"]) > 0.0):
    print("Error: CHECK2A;")
    print("  Elements that generate errors:", sets["CHECK2A"])
if (len(sets["CHECK2"]) > 0.0):
    print("Error: CHECK2;")
    print("  Elements that generate errors:", sets["CHECK2"])
if (len(sets["CHECK3"]) > 0.0):
    print("Error: CHECK3;")
    print("  This check is not applicable anymore, continue...")
if (len(sets["CHECK6"]) > 0.0):
    print("Error: CHECK6;")
    print("  Elements that generate errors:", sets["CHECK6"])
if (len(sets["CHECK6"]) > 0.0):
    print("Error: CHECK6A;")
    print("  Elements that generate errors:", sets["CHECK6A"])
if (len(sets["CHECK12"]) > 0.0):
    print("Error: CHECK12;")
    print("  Elements that generate errors:", sets["CHECK12"])
if (len(sets["CHECK12H"]) > 0.0):
    print("Error: CHECK12H;")
    print("  Elements that generate errors:", sets["CHECK12H"])
if (len(sets["CHECK12AA"]) > 0.0):
    print("Error: CHECK12AA;")
    print("  Elements that generate errors:", sets["CHECK12AA"])
if (len(sets["CHECK12B"]) > 0.0):
    print("Error: CHECK12B;")
    print("  Elements that generate errors:", sets["CHECK12B"])
if (len(sets["CHECK48"]) > 0.0):
    print("Error: CHECK48;")
    print("  Elements that generate errors:", sets["CHECK48"])
if (len(sets["CHECK12C"]) > 0.0):
    print("Error: CHECK12C;")
    print("  Elements that generate errors:", sets["CHECK12C"])
if (len(sets["CHECK12D"]) > 0.0):
    print("Error: CHECK12D;")
    print("  Elements that generate errors:", sets["CHECK12D"])
if (len(sets["CHECK12F"]) > 0.0):
    print("Error: CHECK12F;")
    print("  Elements that generate errors:", sets["CHECK12F"])
if (len(sets["CHECK12E"]) > 0.0):
    print("Error: CHECK12E;")
    print("  Elements that generate errors:", sets["CHECK12E"])
if (len(sets["CHECK13"]) > 0.0):
    print("Error: CHECK13;")
    print("  Elements that generate errors:", sets["CHECK13"])
if (len(sets["CHECK14"]) > 0.0):
    print("Error: CHECK14;")
    print("  Elements that generate errors:", sets["CHECK14"])
if (len(sets["CHECK15"]) > 0.0):
    print("Error: CHECK15;")
    print("  Elements that generate errors:", sets["CHECK15"])
if (len(sets["CHECK15D"]) > 0.0):
    print("Error: CHECK15D;")
    print("  Elements that generate errors:", sets["CHECK15D"])
if (len(sets["CHECK16A"]) > 0.0):
    print("Error: CHECK16A;")
    print("  Elements that generate errors:", sets["CHECK16A"])
if (len(sets["CHECK16B"]) > 0.0):
    print("Error: CHECK16B;")
    print("  Elements that generate errors:", sets["CHECK16B"])
if (len(sets["CHECK17A"]) > 0.0):
    print("Error: CHECK17A;")
    print("  Elements that generate errors:", sets["CHECK17A"])
if (len(sets["CHECK17B"]) > 0.0):
    print("Error: CHECK17B;")
    print("  Elements that generate errors:", sets["CHECK17B"])
if (len(sets["CHECK17C"]) > 0.0):
    print("Error: CHECK17C;")
    print("  Elements that generate errors:", sets["CHECK17C"])
if (len(sets["CHECK17D"]) > 0.0):
    print("Error: CHECK17D;")
    print("  Elements that generate errors:", sets["CHECK17D"])
if (len(sets["CHECK17E"]) > 0.0):
    print("Error: CHECK17E;")
    print("  Elements that generate errors:", sets["CHECK17E"])
if (len(sets["CHECK12K"]) > 0.0):
    print("Error: CHECK12K;")
    print("  Elements that generate errors:", sets["CHECK12K"])
if (len(sets["CHECK12G"]) > 0.0):
    print("Error: CHECK12G;")
    print("  Elements that generate errors:", sets["CHECK12G"])
if (len(sets["CHECK40"]) > 0.0):
    print("Error: CHECK40;")
    print("  Elements that generate errors:", sets["CHECK40"])
if (len(sets["CHECK18"]) > 0.0):
    print("Error: CHECK18;")
    print("  Elements that generate errors:", sets["CHECK18"])
if (len(sets["CHECK22"]) > 0.0):
    print("Error: CHECK22;")
    print("  Elements that generate errors:", sets["CHECK22"])
if (len(sets["CHECK23"]) > 0.0):
    print("Error: CHECK23;")
    print("  Elements that generate errors:", sets["CHECK23"])
if (len(sets["CHECK24"]) > 0.0):
    print("Error: CHECK24;")
    print("  Elements that generate errors:", sets["CHECK24"])
if (scalars["MAXREL"] <= 0.0):
    print("Error: max HAD release not specified in MAXREL ;")
if (scalars["MAXDGW"] <= 0.0):
    print("Error: max deep groundwater abstraction not specified in MAXDGW ;")
if (scalars["SOCCOM"] <= 0.0):
    print("Error: social & commercial water needs not specified in SOCCOM ;")
if (scalars["PHYSEF"] <= 0.0):
    print("Error: physical efficiency of municipal networks not specified in PHYSEF;")
if (scalars["OPEREF"] <= 0.0):
    print("Error: operational efficiency of purification plants not specified in OPEREF;")
if (scalars["AVAP"] <= 0.0):
    print("Error: annual evaporation from wetted surfaces not specified in AVAP;")
if (scalars["SEAFLOWFP"] <= 0.0):
    print("Error: flow to sea from fish ponds not specified in SEAFLOWFP;")
if (len(sets["CHECK43"]) > 0.0):
    print("Error: CHECK43;")
    print("  Elements that generate errors:", sets["CHECK43"])
if (len(sets["CHECK43B"]) > 0.0):
    print("Error: CHECK43B;")
    print("  Elements that generate errors:", sets["CHECK43B"])
if (len(sets["CHECK44A"]) > 0.0):
    print("Error: CHECK44A;")
    print("  Elements that generate errors:", sets["CHECK44A"])
if (len(sets["CHECK45"]) > 0.0):
    print("Error: CHECK45;")
    print("  Elements that generate errors:", sets["CHECK45"])
if (len(sets["CHECK46"]) > 0.0):
    print("Error: CHECK46;")
    print("  Elements that generate errors:", sets["CHECK46"])

# original:
# CONSUMMIN(C)$FCN(C).. SUM(R, QCNSC(C, R)$RL(R)) =G= 0.5 *(DEMDAT(C, "HUMCONR") + DEMDAT(C, "HUMCONU"))

def CONSUMMIN_LHS(model, C):
    return sum([((model.QCNSC[C, R]) if (((R) in sets["RL"])) else 0) for R in sets["R"]])
def CONSUMMIN_RHS(model, C):
    return (0.5 * ((table_DEMDAT(C, "HUMCONR") + table_DEMDAT(C, "HUMCONU"))))
def CONSUMMIN(model, C):
    if ((C) in sets["FCN"]):
        constraint = (
            CONSUMMIN_LHS(model, C) >= CONSUMMIN_RHS(model, C)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CONSUMMIN(" + C + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CONSUMMIN(" + C + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CONSUMMIN_ERROR(model, C):
    if ((C) in sets["FCN"]):
        error = CONSUMMIN_RHS(model, C) - CONSUMMIN_LHS(model, C)
        return error
    else:
        return 0

# original:
# CONSUMMAX(C)$FCN(C).. SUM(R, QCNSC(C, R)$RL(R)) =L= 5 *(DEMDAT(C, "HUMCONR") + DEMDAT(C, "HUMCONU"))

def CONSUMMAX_LHS(model, C):
    return sum([((model.QCNSC[C, R]) if (((R) in sets["RL"])) else 0) for R in sets["R"]])
def CONSUMMAX_RHS(model, C):
    return (5.0 * ((table_DEMDAT(C, "HUMCONR") + table_DEMDAT(C, "HUMCONU"))))
def CONSUMMAX(model, C):
    if ((C) in sets["FCN"]):
        constraint = (
            CONSUMMAX_LHS(model, C) <= CONSUMMAX_RHS(model, C)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CONSUMMAX(" + C + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CONSUMMAX(" + C + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CONSUMMAX_ERROR(model, C):
    if ((C) in sets["FCN"]):
        error = CONSUMMAX_LHS(model, C) - CONSUMMAX_RHS(model, C)
        return error
    else:
        return 0

# original:
# IMPORT(C)$CN(C).. SUM(R, QIMPC(C, R)$RL(R)$PIMPC(C)) =E= IMPORTS(C)

def IMPORT_LHS(model, C):
    return sum([((model.QIMPC[C, R]) if (((R) in sets["RL"]) and PIMPC(model, C)) else 0) for R in sets["R"]])
def IMPORT_RHS(model, C):
    return model.IMPORTS[C]
def IMPORT(model, C):
    if ((C) in sets["CN"]):
        constraint = (
            IMPORT_LHS(model, C) == IMPORT_RHS(model, C)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: IMPORT(" + C + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: IMPORT(" + C + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def IMPORT_ERROR(model, C):
    if ((C) in sets["CN"]):
        error = np.abs(IMPORT_RHS(model, C) - IMPORT_LHS(model, C))
        return error
    else:
        return 0

# original:
# EXPORT(C).. SUM(R, QEXPC(C, R)$RL(R)$PEXPC(C)) =E= EXPORTS(C)

def EXPORT_LHS(model, C):
    return sum([((model.QEXPC[C, R]) if (((R) in sets["RL"]) and PEXPC(model, C)) else 0) for R in sets["R"]])
def EXPORT_RHS(model, C):
    return model.EXPORTS[C]
def EXPORT(model, C):
    if True:
        constraint = (
            EXPORT_LHS(model, C) == EXPORT_RHS(model, C)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: EXPORT(" + C + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: EXPORT(" + C + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def EXPORT_ERROR(model, C):
    if True:
        error = np.abs(EXPORT_RHS(model, C) - EXPORT_LHS(model, C))
        return error
    else:
        return 0

# original:
# SBEETROT("SBEET1", R)$RL(R)..SUM((PT, WI), XCROP("SBEET1", PT, WI, R)$RXCMAP(R, "SBEET1")) =L= QLNDSUP(R) / 4

def SBEETROT_LHS(model, R):
    return sum([((model.XCROP["SBEET1", PT, WI, R]) if (table_RXCMAP(R, "SBEET1")) else 0) for PT in sets["PT"] for WI in sets["WI"]])
def SBEETROT_RHS(model, R):
    return (QLNDSUP(model, R) / 4.0)
def SBEETROT(model, R):
    if ((R) in sets["RL"]):
        constraint = (
            SBEETROT_LHS(model, R) <= SBEETROT_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: SBEETROT(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: SBEETROT(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def SBEETROT_ERROR(model, R):
    if ((R) in sets["RL"]):
        error = SBEETROT_LHS(model, R) - SBEETROT_RHS(model, R)
        return error
    else:
        return 0

# original:
# POTATOROT("PTATON1", R)$RL(R)..SUM((PT, WI), XCROP("PTATON1", PT, WI, R)$RXCMAP(R, "PTATON1")) +SUM((PT, WI), XCROP("PTATOS1", PT, WI, R)$RXCMAP(R, "PTATOS1")) =L= QLNDSUP(R) / 3

def POTATOROT_LHS(model, R):
    return (sum([((model.XCROP["PTATON1", PT, WI, R]) if (table_RXCMAP(R, "PTATON1")) else 0) for PT in sets["PT"] for WI in sets["WI"]]) + sum([((model.XCROP["PTATOS1", PT, WI, R]) if (table_RXCMAP(R, "PTATOS1")) else 0) for PT in sets["PT"] for WI in sets["WI"]]))
def POTATOROT_RHS(model, R):
    return (QLNDSUP(model, R) / 3.0)
def POTATOROT(model, R):
    if ((R) in sets["RL"]):
        constraint = (
            POTATOROT_LHS(model, R) <= POTATOROT_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: POTATOROT(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: POTATOROT(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def POTATOROT_ERROR(model, R):
    if ((R) in sets["RL"]):
        error = POTATOROT_LHS(model, R) - POTATOROT_RHS(model, R)
        return error
    else:
        return 0

# original:
# FLAXROT("FLAX1", R)$RL(R)..SUM((PT, WI), XCROP("FLAX1", PT, WI, R)$RXCMAP(R, "FLAX1")) =L= QLNDSUP(R) / 3

def FLAXROT_LHS(model, R):
    return sum([((model.XCROP["FLAX1", PT, WI, R]) if (table_RXCMAP(R, "FLAX1")) else 0) for PT in sets["PT"] for WI in sets["WI"]])
def FLAXROT_RHS(model, R):
    return (QLNDSUP(model, R) / 3.0)
def FLAXROT(model, R):
    if ((R) in sets["RL"]):
        constraint = (
            FLAXROT_LHS(model, R) <= FLAXROT_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: FLAXROT(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: FLAXROT(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def FLAXROT_ERROR(model, R):
    if ((R) in sets["RL"]):
        error = FLAXROT_LHS(model, R) - FLAXROT_RHS(model, R)
        return error
    else:
        return 0

# original:
# SBERSEEROT("SBSEMW1", PT, R)$RL(R)..SUM(WI, XCROP("SBSEMW1", PT, WI, R)$RXCMAP(R, "SBSEMW1")) =G= SUM(WI, XCROP("SDELS1", PT, WI, R)$RXCMAP(R, "SDELS1")) + SUM(WI, XCROP("SDLS1", PT, WI, R)$RXCMAP(R, "SDLS1"))

def SBERSEEROT_LHS(model, PT, R):
    return sum([((model.XCROP["SBSEMW1", PT, WI, R]) if (table_RXCMAP(R, "SBSEMW1")) else 0) for WI in sets["WI"]])
def SBERSEEROT_RHS(model, PT, R):
    return (sum([((model.XCROP["SDELS1", PT, WI, R]) if (table_RXCMAP(R, "SDELS1")) else 0) for WI in sets["WI"]]) + sum([((model.XCROP["SDLS1", PT, WI, R]) if (table_RXCMAP(R, "SDLS1")) else 0) for WI in sets["WI"]]))
def SBERSEEROT(model, PT, R):
    if ((R) in sets["RL"]):
        constraint = (
            SBERSEEROT_LHS(model, PT, R) >= SBERSEEROT_RHS(model, PT, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: SBERSEEROT(" + PT + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: SBERSEEROT(" + PT + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def SBERSEEROT_ERROR(model, PT, R):
    if ((R) in sets["RL"]):
        error = SBERSEEROT_RHS(model, PT, R) - SBERSEEROT_LHS(model, PT, R)
        return error
    else:
        return 0

# original:
# BERSEEROT1("SBSEMW1", R)$RL(R)..SUM((WI, PT), XCROP("SBSEMW1", PT, WI, R)$RXCMAP(R, "SBSEMW1")) =G= 0.2 *SUM((WI, PT), XCROP("LBSEEM1", PT, WI, R)$RXCMAP(R, "LBSEEM1"))

def BERSEEROT1_LHS(model, R):
    return sum([((model.XCROP["SBSEMW1", PT, WI, R]) if (table_RXCMAP(R, "SBSEMW1")) else 0) for WI in sets["WI"] for PT in sets["PT"]])
def BERSEEROT1_RHS(model, R):
    return (0.2 * sum([((model.XCROP["LBSEEM1", PT, WI, R]) if (table_RXCMAP(R, "LBSEEM1")) else 0) for WI in sets["WI"] for PT in sets["PT"]]))
def BERSEEROT1(model, R):
    if ((R) in sets["RL"]):
        constraint = (
            BERSEEROT1_LHS(model, R) >= BERSEEROT1_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: BERSEEROT1(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: BERSEEROT1(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def BERSEEROT1_ERROR(model, R):
    if ((R) in sets["RL"]):
        error = BERSEEROT1_RHS(model, R) - BERSEEROT1_LHS(model, R)
        return error
    else:
        return 0

# original:
# BERSEEROT2("SBSEMW1", R)$RL(R)..SUM((WI, PT), XCROP("SBSEMW1", PT, WI, R)$RXCMAP(R, "SBSEMW1")) =L= 0.7 *SUM((WI, PT), XCROP("LBSEEM1", PT, WI, R)$RXCMAP(R, "LBSEEM1"))

def BERSEEROT2_LHS(model, R):
    return sum([((model.XCROP["SBSEMW1", PT, WI, R]) if (table_RXCMAP(R, "SBSEMW1")) else 0) for WI in sets["WI"] for PT in sets["PT"]])
def BERSEEROT2_RHS(model, R):
    return (0.7 * sum([((model.XCROP["LBSEEM1", PT, WI, R]) if (table_RXCMAP(R, "LBSEEM1")) else 0) for WI in sets["WI"] for PT in sets["PT"]]))
def BERSEEROT2(model, R):
    if ((R) in sets["RL"]):
        constraint = (
            BERSEEROT2_LHS(model, R) <= BERSEEROT2_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: BERSEEROT2(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: BERSEEROT2(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def BERSEEROT2_ERROR(model, R):
    if ((R) in sets["RL"]):
        error = BERSEEROT2_LHS(model, R) - BERSEEROT2_RHS(model, R)
        return error
    else:
        return 0

# original:
# SBDPMAX("SBDP")..SUM((R, M)$(XAMMAP("SBDP", M)$RL(R)),XLIVE("SBDP", M, R)) =L= 20

def SBDPMAX_LHS(model):
    return sum([model.XLIVE["SBDP", M, R] for R in sets["R"] for M in sets["M"] if ((((("SBDP", M) in sets["XAMMAP"])) if (((R) in sets["RL"])) else 0))])
def SBDPMAX_RHS(model):
    return 20.0
def SBDPMAX(model):
    if True:
        constraint = (
            SBDPMAX_LHS(model) <= SBDPMAX_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: SBDPMAX(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: SBDPMAX(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def SBDPMAX_ERROR(model):
    if True:
        error = SBDPMAX_LHS(model) - SBDPMAX_RHS(model)
        return error
    else:
        return 0

# original:
# SCDPMAX("SCDP")..SUM((R, M)$(XAMMAP("SCDP", M)$RL(R)),XLIVE("SCDP", M, R)) =L= 6.5

def SCDPMAX_LHS(model):
    return sum([model.XLIVE["SCDP", M, R] for R in sets["R"] for M in sets["M"] if ((((("SCDP", M) in sets["XAMMAP"])) if (((R) in sets["RL"])) else 0))])
def SCDPMAX_RHS(model):
    return 6.5
def SCDPMAX(model):
    if True:
        constraint = (
            SCDPMAX_LHS(model) <= SCDPMAX_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: SCDPMAX(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: SCDPMAX(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def SCDPMAX_ERROR(model):
    if True:
        error = SCDPMAX_LHS(model) - SCDPMAX_RHS(model)
        return error
    else:
        return 0

# original:
# CCDPMAX("CCDP")..SUM((R, M)$(XAMMAP("CCDP", M)$RL(R)),XLIVE("CCDP", M, R)) =L= 4.5

def CCDPMAX_LHS(model):
    return sum([model.XLIVE["CCDP", M, R] for R in sets["R"] for M in sets["M"] if ((((("CCDP", M) in sets["XAMMAP"])) if (((R) in sets["RL"])) else 0))])
def CCDPMAX_RHS(model):
    return 4.5
def CCDPMAX(model):
    if True:
        constraint = (
            CCDPMAX_LHS(model) <= CCDPMAX_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CCDPMAX(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CCDPMAX(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CCDPMAX_ERROR(model):
    if True:
        error = CCDPMAX_LHS(model) - CCDPMAX_RHS(model)
        return error
    else:
        return 0

# original:
# PRDCROP(C, R)$(RCMAP(R, C)$RL(R)).. QPRDC(C, R)$(RL(R)$(RCMAP(R, C))) =E= SUM((XC, PT, WI),YLDC(XC, PT, WI, C, R) *XCROP(XC, PT, WI, R)$RXCMAP(R, XC))

def PRDCROP_LHS(model, C, R):
    return ((model.QPRDC[C, R]) if ((((((R) in sets["RL"])) if ((((R, C) in sets["RCMAP"]))) else 0))) else 0)
def PRDCROP_RHS(model, C, R):
    return sum([(YLDC(model, XC, PT, WI, C, R) * ((model.XCROP[XC, PT, WI, R]) if (table_RXCMAP(R, XC)) else 0)) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"]])
def PRDCROP(model, C, R):
    if (((((R, C) in sets["RCMAP"])) if (((R) in sets["RL"])) else 0)):
        constraint = (
            PRDCROP_LHS(model, C, R) == PRDCROP_RHS(model, C, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: PRDCROP(" + C + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: PRDCROP(" + C + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def PRDCROP_ERROR(model, C, R):
    if (((((R, C) in sets["RCMAP"])) if (((R) in sets["RL"])) else 0)):
        error = np.abs(PRDCROP_RHS(model, C, R) - PRDCROP_LHS(model, C, R))
        return error
    else:
        return 0

# original:
# QCNSCDET(C, R)$(RL(R)$CN(C)).. QCNSC(C, R)$RL(R) =E= QCNSCR(C, R)+QCNSCU(C, R)

def QCNSCDET_LHS(model, C, R):
    return ((model.QCNSC[C, R]) if (((R) in sets["RL"])) else 0)
def QCNSCDET_RHS(model, C, R):
    return (model.QCNSCR[C, R] + model.QCNSCU[C, R])
def QCNSCDET(model, C, R):
    if (((((R) in sets["RL"])) if (((C) in sets["CN"])) else 0)):
        constraint = (
            QCNSCDET_LHS(model, C, R) == QCNSCDET_RHS(model, C, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: QCNSCDET(" + C + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: QCNSCDET(" + C + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def QCNSCDET_ERROR(model, C, R):
    if (((((R) in sets["RL"])) if (((C) in sets["CN"])) else 0)):
        error = np.abs(QCNSCDET_RHS(model, C, R) - QCNSCDET_LHS(model, C, R))
        return error
    else:
        return 0

# original:
# LANDCON(R, TM)$RL(R).. SUM((XC, PT, WI), XCROP(XC, PT, WI, R)$RXCMAP(R, XC) *LNDREQ(XC, PT, R, TM)) +FALLOW(R, TM) =E= (QLNDSUP(R) + LNDRECL(R)) *GROSNETLD

def LANDCON_LHS(model, R, TM):
    return (sum([(((model.XCROP[XC, PT, WI, R]) if (table_RXCMAP(R, XC)) else 0) * LNDREQ(model, XC, PT, R, TM)) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"]]) + model.FALLOW[R, TM])
def LANDCON_RHS(model, R, TM):
    return (((QLNDSUP(model, R) + LNDRECL(model, R))) * scalars["GROSNETLD"])
def LANDCON(model, R, TM):
    if ((R) in sets["RL"]):
        constraint = (
            LANDCON_LHS(model, R, TM) == LANDCON_RHS(model, R, TM)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: LANDCON(" + R + ", " + TM + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: LANDCON(" + R + ", " + TM + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def LANDCON_ERROR(model, R, TM):
    if ((R) in sets["RL"]):
        error = np.abs(LANDCON_RHS(model, R, TM) - LANDCON_LHS(model, R, TM))
        return error
    else:
        return 0

# original:
# CSTDEFLREC.. LRECCOST =E= (SUM(R, LNDRECL(R)$LNDRECL(R) * CSTRECL(R))) / 1E6

def CSTDEFLREC_LHS(model):
    return model.LRECCOST
def CSTDEFLREC_RHS(model):
    return ((sum([(((LNDRECL(model, R)) if (LNDRECL(model, R)) else 0) * CSTRECL(model, R)) for R in sets["R"]])) / 1000000.0)
def CSTDEFLREC(model):
    if True:
        constraint = (
            CSTDEFLREC_LHS(model) == CSTDEFLREC_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CSTDEFLREC(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CSTDEFLREC(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CSTDEFLREC_ERROR(model):
    if True:
        error = np.abs(CSTDEFLREC_RHS(model) - CSTDEFLREC_LHS(model))
        return error
    else:
        return 0

# original:
# XCDEFNAT(XC) .. XCROPNAT(XC) =E= SUM((PT, WI, R), XCROP(XC, PT, WI, R)$RXCMAP(R, XC))

def XCDEFNAT_LHS(model, XC):
    return model.XCROPNAT[XC]
def XCDEFNAT_RHS(model, XC):
    return sum([((model.XCROP[XC, PT, WI, R]) if (table_RXCMAP(R, XC)) else 0) for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"]])
def XCDEFNAT(model, XC):
    if True:
        constraint = (
            XCDEFNAT_LHS(model, XC) == XCDEFNAT_RHS(model, XC)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: XCDEFNAT(" + XC + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: XCDEFNAT(" + XC + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def XCDEFNAT_ERROR(model, XC):
    if True:
        error = np.abs(XCDEFNAT_RHS(model, XC) - XCDEFNAT_LHS(model, XC))
        return error
    else:
        return 0

# original:
# RICDEFREG(R).. XRICR(R) =E= SUM((XCRICE, PT, WI), XCROP(XCRICE, PT, WI, R)$RXCMAP(R, XCRICE))

def RICDEFREG_LHS(model, R):
    return model.XRICR[R]
def RICDEFREG_RHS(model, R):
    return sum([((model.XCROP[XCRICE, PT, WI, R]) if (table_RXCMAP(R, XCRICE)) else 0) for XCRICE in sets["XCRICE"] for PT in sets["PT"] for WI in sets["WI"]])
def RICDEFREG(model, R):
    if True:
        constraint = (
            RICDEFREG_LHS(model, R) == RICDEFREG_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: RICDEFREG(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: RICDEFREG(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def RICDEFREG_ERROR(model, R):
    if True:
        error = np.abs(RICDEFREG_RHS(model, R) - RICDEFREG_LHS(model, R))
        return error
    else:
        return 0

# original:
# RICEDEFNAT.. XRICENAT =E= SUM(XCRICE, XCROPNAT(XCRICE))

def RICEDEFNAT_LHS(model):
    return model.XRICENAT
def RICEDEFNAT_RHS(model):
    return sum([model.XCROPNAT[XCRICE] for XCRICE in sets["XCRICE"]])
def RICEDEFNAT(model):
    if True:
        constraint = (
            RICEDEFNAT_LHS(model) == RICEDEFNAT_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: RICEDEFNAT(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: RICEDEFNAT(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def RICEDEFNAT_ERROR(model):
    if True:
        error = np.abs(RICEDEFNAT_RHS(model) - RICEDEFNAT_LHS(model))
        return error
    else:
        return 0

# original:
# COTDEFREG(R).. XCOTR(R) =E= SUM((XCCOT, PT, WI), XCROP(XCCOT, PT, WI, R)$RXCMAP(R, XCCOT))

def COTDEFREG_LHS(model, R):
    return model.XCOTR[R]
def COTDEFREG_RHS(model, R):
    return sum([((model.XCROP[XCCOT, PT, WI, R]) if (table_RXCMAP(R, XCCOT)) else 0) for XCCOT in sets["XCCOT"] for PT in sets["PT"] for WI in sets["WI"]])
def COTDEFREG(model, R):
    if True:
        constraint = (
            COTDEFREG_LHS(model, R) == COTDEFREG_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: COTDEFREG(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: COTDEFREG(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def COTDEFREG_ERROR(model, R):
    if True:
        error = np.abs(COTDEFREG_RHS(model, R) - COTDEFREG_LHS(model, R))
        return error
    else:
        return 0

# original:
# SCADEFREG(R)$RXCMAP(R, "SCANE1").. XSCAR(R) =E= SUM((XCSCA, PT, WI), XCROP(XCSCA, PT, WI, R))

def SCADEFREG_LHS(model, R):
    return model.XSCAR[R]
def SCADEFREG_RHS(model, R):
    return sum([model.XCROP[XCSCA, PT, WI, R] for XCSCA in sets["XCSCA"] for PT in sets["PT"] for WI in sets["WI"]])
def SCADEFREG(model, R):
    if table_RXCMAP(R, "SCANE1"):
        constraint = (
            SCADEFREG_LHS(model, R) == SCADEFREG_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: SCADEFREG(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: SCADEFREG(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def SCADEFREG_ERROR(model, R):
    if table_RXCMAP(R, "SCANE1"):
        error = np.abs(SCADEFREG_RHS(model, R) - SCADEFREG_LHS(model, R))
        return error
    else:
        return 0

# original:
# SBEDEFREG(R)$RXCMAP(R, "SBEET1").. XSBER(R) =E= SUM((XCSBE, PT, WI), XCROP(XCSBE, PT, WI, R))

def SBEDEFREG_LHS(model, R):
    return model.XSBER[R]
def SBEDEFREG_RHS(model, R):
    return sum([model.XCROP[XCSBE, PT, WI, R] for XCSBE in sets["XCSBE"] for PT in sets["PT"] for WI in sets["WI"]])
def SBEDEFREG(model, R):
    if table_RXCMAP(R, "SBEET1"):
        constraint = (
            SBEDEFREG_LHS(model, R) == SBEDEFREG_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: SBEDEFREG(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: SBEDEFREG(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def SBEDEFREG_ERROR(model, R):
    if table_RXCMAP(R, "SBEET1"):
        error = np.abs(SBEDEFREG_RHS(model, R) - SBEDEFREG_LHS(model, R))
        return error
    else:
        return 0

# original:
# CITRDEFREG(R)$RXCMAP(R, "CITRUS1").. XCITR(R) =E= SUM((XCCIT, PT, WI), XCROP(XCCIT, PT, WI, R))

def CITRDEFREG_LHS(model, R):
    return model.XCITR[R]
def CITRDEFREG_RHS(model, R):
    return sum([model.XCROP[XCCIT, PT, WI, R] for XCCIT in sets["XCCIT"] for PT in sets["PT"] for WI in sets["WI"]])
def CITRDEFREG(model, R):
    if table_RXCMAP(R, "CITRUS1"):
        constraint = (
            CITRDEFREG_LHS(model, R) == CITRDEFREG_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CITRDEFREG(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CITRDEFREG(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CITRDEFREG_ERROR(model, R):
    if table_RXCMAP(R, "CITRUS1"):
        error = np.abs(CITRDEFREG_RHS(model, R) - CITRDEFREG_LHS(model, R))
        return error
    else:
        return 0

# original:
# VEGWDEFREG(R)$RXCMAP(R, "VEGETW1").. XVEGWR(R) =E= SUM((XCVEGW, PT, WI), XCROP(XCVEGW, PT, WI, R))

def VEGWDEFREG_LHS(model, R):
    return model.XVEGWR[R]
def VEGWDEFREG_RHS(model, R):
    return sum([model.XCROP[XCVEGW, PT, WI, R] for XCVEGW in sets["XCVEGW"] for PT in sets["PT"] for WI in sets["WI"]])
def VEGWDEFREG(model, R):
    if table_RXCMAP(R, "VEGETW1"):
        constraint = (
            VEGWDEFREG_LHS(model, R) == VEGWDEFREG_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: VEGWDEFREG(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: VEGWDEFREG(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def VEGWDEFREG_ERROR(model, R):
    if table_RXCMAP(R, "VEGETW1"):
        error = np.abs(VEGWDEFREG_RHS(model, R) - VEGWDEFREG_LHS(model, R))
        return error
    else:
        return 0

# original:
# VEGSDEFREG(R)$RXCMAP(R, "VEGETS1").. XVEGSR(R) =E= SUM((XCVEGS, PT, WI), XCROP(XCVEGS, PT, WI, R))

def VEGSDEFREG_LHS(model, R):
    return model.XVEGSR[R]
def VEGSDEFREG_RHS(model, R):
    return sum([model.XCROP[XCVEGS, PT, WI, R] for XCVEGS in sets["XCVEGS"] for PT in sets["PT"] for WI in sets["WI"]])
def VEGSDEFREG(model, R):
    if table_RXCMAP(R, "VEGETS1"):
        constraint = (
            VEGSDEFREG_LHS(model, R) == VEGSDEFREG_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: VEGSDEFREG(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: VEGSDEFREG(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def VEGSDEFREG_ERROR(model, R):
    if table_RXCMAP(R, "VEGETS1"):
        error = np.abs(VEGSDEFREG_RHS(model, R) - VEGSDEFREG_LHS(model, R))
        return error
    else:
        return 0

# original:
# VEGNDEFREG(R)$RXCMAP(R, "VEGETN1").. XVEGNR(R) =E= SUM((XCVEGN, PT, WI), XCROP(XCVEGN, PT, WI, R))

def VEGNDEFREG_LHS(model, R):
    return model.XVEGNR[R]
def VEGNDEFREG_RHS(model, R):
    return sum([model.XCROP[XCVEGN, PT, WI, R] for XCVEGN in sets["XCVEGN"] for PT in sets["PT"] for WI in sets["WI"]])
def VEGNDEFREG(model, R):
    if table_RXCMAP(R, "VEGETN1"):
        constraint = (
            VEGNDEFREG_LHS(model, R) == VEGNDEFREG_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: VEGNDEFREG(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: VEGNDEFREG(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def VEGNDEFREG_ERROR(model, R):
    if table_RXCMAP(R, "VEGETN1"):
        error = np.abs(VEGNDEFREG_RHS(model, R) - VEGNDEFREG_LHS(model, R))
        return error
    else:
        return 0

# original:
# GRAINDEFREG(R).. XGRAINR(R) =E= SUM((XCGRAIN, PT, WI), XCROP(XCGRAIN, PT, WI, R)$RXCMAP(R, XCGRAIN))

def GRAINDEFREG_LHS(model, R):
    return model.XGRAINR[R]
def GRAINDEFREG_RHS(model, R):
    return sum([((model.XCROP[XCGRAIN, PT, WI, R]) if (table_RXCMAP(R, XCGRAIN)) else 0) for XCGRAIN in sets["XCGRAIN"] for PT in sets["PT"] for WI in sets["WI"]])
def GRAINDEFREG(model, R):
    if True:
        constraint = (
            GRAINDEFREG_LHS(model, R) == GRAINDEFREG_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: GRAINDEFREG(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: GRAINDEFREG(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def GRAINDEFREG_ERROR(model, R):
    if True:
        error = np.abs(GRAINDEFREG_RHS(model, R) - GRAINDEFREG_LHS(model, R))
        return error
    else:
        return 0

# original:
# OILSDEFREG(R).. XOILSR(R) =E= SUM((XCOILS, PT, WI), XCROP(XCOILS, PT, WI, R)$RXCMAP(R, XCOILS))

def OILSDEFREG_LHS(model, R):
    return model.XOILSR[R]
def OILSDEFREG_RHS(model, R):
    return sum([((model.XCROP[XCOILS, PT, WI, R]) if (table_RXCMAP(R, XCOILS)) else 0) for XCOILS in sets["XCOILS"] for PT in sets["PT"] for WI in sets["WI"]])
def OILSDEFREG(model, R):
    if True:
        constraint = (
            OILSDEFREG_LHS(model, R) == OILSDEFREG_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: OILSDEFREG(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: OILSDEFREG(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def OILSDEFREG_ERROR(model, R):
    if True:
        error = np.abs(OILSDEFREG_RHS(model, R) - OILSDEFREG_LHS(model, R))
        return error
    else:
        return 0

# original:
# OTLEDEFREG(R).. XOTLEGR(R) =E= SUM((XCOTLEG, PT, WI), XCROP(XCOTLEG, PT, WI, R)$RXCMAP(R, XCOTLEG))

def OTLEDEFREG_LHS(model, R):
    return model.XOTLEGR[R]
def OTLEDEFREG_RHS(model, R):
    return sum([((model.XCROP[XCOTLEG, PT, WI, R]) if (table_RXCMAP(R, XCOTLEG)) else 0) for XCOTLEG in sets["XCOTLEG"] for PT in sets["PT"] for WI in sets["WI"]])
def OTLEDEFREG(model, R):
    if True:
        constraint = (
            OTLEDEFREG_LHS(model, R) == OTLEDEFREG_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: OTLEDEFREG(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: OTLEDEFREG(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def OTLEDEFREG_ERROR(model, R):
    if True:
        error = np.abs(OTLEDEFREG_RHS(model, R) - OTLEDEFREG_LHS(model, R))
        return error
    else:
        return 0

# original:
# FODDEFREG(R).. XFODR(R) =E= SUM((XCFOD, PT, WI), XCROP(XCFOD, PT, WI, R)$RXCMAP(R, XCFOD))

def FODDEFREG_LHS(model, R):
    return model.XFODR[R]
def FODDEFREG_RHS(model, R):
    return sum([((model.XCROP[XCFOD, PT, WI, R]) if (table_RXCMAP(R, XCFOD)) else 0) for XCFOD in sets["XCFOD"] for PT in sets["PT"] for WI in sets["WI"]])
def FODDEFREG(model, R):
    if True:
        constraint = (
            FODDEFREG_LHS(model, R) == FODDEFREG_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: FODDEFREG(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: FODDEFREG(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def FODDEFREG_ERROR(model, R):
    if True:
        error = np.abs(FODDEFREG_RHS(model, R) - FODDEFREG_LHS(model, R))
        return error
    else:
        return 0

# original:
# SORGDEFREG(R).. XSORGR(R) =E= SUM((XCSORG, PT, WI), XCROP(XCSORG, PT, WI, R)$RXCMAP(R, XCSORG))

def SORGDEFREG_LHS(model, R):
    return model.XSORGR[R]
def SORGDEFREG_RHS(model, R):
    return sum([((model.XCROP[XCSORG, PT, WI, R]) if (table_RXCMAP(R, XCSORG)) else 0) for XCSORG in sets["XCSORG"] for PT in sets["PT"] for WI in sets["WI"]])
def SORGDEFREG(model, R):
    if True:
        constraint = (
            SORGDEFREG_LHS(model, R) == SORGDEFREG_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: SORGDEFREG(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: SORGDEFREG(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def SORGDEFREG_ERROR(model, R):
    if True:
        error = np.abs(SORGDEFREG_RHS(model, R) - SORGDEFREG_LHS(model, R))
        return error
    else:
        return 0

# original:
# ACRPDEFREG(R).. XACROPR(R) =E= SUM((XC, PT, WI), XCROP(XC, PT, WI, R)$RXCMAP(R, XC))

def ACRPDEFREG_LHS(model, R):
    return model.XACROPR[R]
def ACRPDEFREG_RHS(model, R):
    return sum([((model.XCROP[XC, PT, WI, R]) if (table_RXCMAP(R, XC)) else 0) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"]])
def ACRPDEFREG(model, R):
    if True:
        constraint = (
            ACRPDEFREG_LHS(model, R) == ACRPDEFREG_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: ACRPDEFREG(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: ACRPDEFREG(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def ACRPDEFREG_ERROR(model, R):
    if True:
        error = np.abs(ACRPDEFREG_RHS(model, R) - ACRPDEFREG_LHS(model, R))
        return error
    else:
        return 0

# original:
# PRDLVST(C, R)$(RL(R)$CA(C)).. QPRDA(C, R) =E= SUM((XA, M),XLIVE(XA, M, R) *YLDA(XA, M, C))

def PRDLVST_LHS(model, C, R):
    return model.QPRDA[C, R]
def PRDLVST_RHS(model, C, R):
    return sum([(model.XLIVE[XA, M, R] * table_YLDA(XA, M, C)) for XA in sets["XA"] for M in sets["M"]])
def PRDLVST(model, C, R):
    if (((((R) in sets["RL"])) if (((C) in sets["CA"])) else 0)):
        constraint = (
            PRDLVST_LHS(model, C, R) == PRDLVST_RHS(model, C, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: PRDLVST(" + C + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: PRDLVST(" + C + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def PRDLVST_ERROR(model, C, R):
    if (((((R) in sets["RL"])) if (((C) in sets["CA"])) else 0)):
        error = np.abs(PRDLVST_RHS(model, C, R) - PRDLVST_LHS(model, C, R))
        return error
    else:
        return 0

# original:
# DSBALIP1("GRDNUT", R)$(XCPP("GNUT1")$XCCMAP("GNUT1", "GRDNUT")$RCMAP(R, "GRDNUT")$RL(R)).. QCNSC("GRDNUT", R)+QCNSCL("GNUTCAKE", R) / 0.555 =L= SUM((XC, PT, WI)$(GNU(XC)$RXCMAP(R, XC)), XCROP(XC, PT, WI, R) *YLDC(XC, PT, WI, "GRDNUT", R))

def DSBALIP1_LHS(model, R):
    return (model.QCNSC["GRDNUT", R] + (model.QCNSCL["GNUTCAKE", R] / 0.555))
def DSBALIP1_RHS(model, R):
    return sum([(model.XCROP[XC, PT, WI, R] * YLDC(model, XC, PT, WI, "GRDNUT", R)) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] if (((((XC) in sets["GNU"])) if (table_RXCMAP(R, XC)) else 0))])
def DSBALIP1(model, R):
    if ((((("GNUT1") in sets["XCPP"])) if ((("GNUT1", "GRDNUT") in sets["XCCMAP"]) and ((R, "GRDNUT") in sets["RCMAP"]) and ((R) in sets["RL"])) else 0)):
        constraint = (
            DSBALIP1_LHS(model, R) <= DSBALIP1_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: DSBALIP1(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: DSBALIP1(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def DSBALIP1_ERROR(model, R):
    if ((((("GNUT1") in sets["XCPP"])) if ((("GNUT1", "GRDNUT") in sets["XCCMAP"]) and ((R, "GRDNUT") in sets["RCMAP"]) and ((R) in sets["RL"])) else 0)):
        error = DSBALIP1_LHS(model, R) - DSBALIP1_RHS(model, R)
        return error
    else:
        return 0

# original:
# DSBALIP2("SOYBEAN", R)$(XCPP("SBEAN1")$XCCMAP("SBEAN1", "SOYBEAN")$RCMAP(R, "SOYBEAN")$RL(R)).. QCNSC("SOYBEAN", R)+QCNSCL("SOYACAKE", R) / 0.888 =L= SUM((XC, PT, WI)$(SOY(XC)$RXCMAP(R, XC)), XCROP(XC, PT, WI, R) *YLDC(XC, PT, WI, "SOYBEAN", R)) + QIMPC("SOYBEAN", R) * (1-WASTE("SOYBEAN"))

def DSBALIP2_LHS(model, R):
    return (model.QCNSC["SOYBEAN", R] + (model.QCNSCL["SOYACAKE", R] / 0.888))
def DSBALIP2_RHS(model, R):
    return (sum([(model.XCROP[XC, PT, WI, R] * YLDC(model, XC, PT, WI, "SOYBEAN", R)) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] if (((((XC) in sets["SOY"])) if (table_RXCMAP(R, XC)) else 0))]) + (model.QIMPC["SOYBEAN", R] * ((1.0 - WASTE(model, "SOYBEAN")))))
def DSBALIP2(model, R):
    if ((((("SBEAN1") in sets["XCPP"])) if ((("SBEAN1", "SOYBEAN") in sets["XCCMAP"]) and ((R, "SOYBEAN") in sets["RCMAP"]) and ((R) in sets["RL"])) else 0)):
        constraint = (
            DSBALIP2_LHS(model, R) <= DSBALIP2_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: DSBALIP2(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: DSBALIP2(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def DSBALIP2_ERROR(model, R):
    if ((((("SBEAN1") in sets["XCPP"])) if ((("SBEAN1", "SOYBEAN") in sets["XCCMAP"]) and ((R, "SOYBEAN") in sets["RCMAP"]) and ((R) in sets["RL"])) else 0)):
        error = DSBALIP2_LHS(model, R) - DSBALIP2_RHS(model, R)
        return error
    else:
        return 0

# original:
# DSBALCNR(C, R)$(RL(R)$CN(C)).. QCNSC(C, R)$CN(C)+QCNSCL(C, R)$CHL(C) =E= QPRDC(C, R)$(CC(C)$RCMAP(R, C)) * (1-(WASTE(C) + SEED(C))) + QPRDA(C, R)$CA(C) + QIMPC(C, R)$PIMPC(C) * (1-WASTE(C)) - QEXPC(C, R)$PEXPC(C) + REGTRADE(C, R)$CTR(C)

def DSBALCNR_LHS(model, C, R):
    return (((model.QCNSC[C, R]) if (((C) in sets["CN"])) else 0) + ((model.QCNSCL[C, R]) if (((C) in sets["CHL"])) else 0))
def DSBALCNR_RHS(model, C, R):
    return ((((model.QPRDC[C, R]) if ((((((C) in sets["CC"])) if (((R, C) in sets["RCMAP"])) else 0))) else 0) * ((1.0 - ((WASTE(model, C) + SEED(model, C)))))) + ((model.QPRDA[C, R]) if (((C) in sets["CA"])) else 0) + (((model.QIMPC[C, R]) if (PIMPC(model, C)) else 0) * ((1.0 - WASTE(model, C)))) - ((model.QEXPC[C, R]) if (PEXPC(model, C)) else 0) + ((model.REGTRADE[C, R]) if (((C) in sets["CTR"])) else 0))
def DSBALCNR(model, C, R):
    if (((((R) in sets["RL"])) if (((C) in sets["CN"])) else 0)):
        constraint = (
            DSBALCNR_LHS(model, C, R) == DSBALCNR_RHS(model, C, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: DSBALCNR(" + C + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: DSBALCNR(" + C + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def DSBALCNR_ERROR(model, C, R):
    if (((((R) in sets["RL"])) if (((C) in sets["CN"])) else 0)):
        error = np.abs(DSBALCNR_RHS(model, C, R) - DSBALCNR_LHS(model, C, R))
        return error
    else:
        return 0

# original:
# RTRADEBAL(C)$CTR(C).. SUM(R$RL(R),REGTRADE(C, R)$CTR(C))=E=0

def RTRADEBAL_LHS(model, C):
    return sum([((model.REGTRADE[C, R]) if (((C) in sets["CTR"])) else 0) for R in sets["R"] if ((R) in sets["RL"])])
def RTRADEBAL_RHS(model, C):
    return 0.0
def RTRADEBAL(model, C):
    if ((C) in sets["CTR"]):
        constraint = (
            RTRADEBAL_LHS(model, C) == RTRADEBAL_RHS(model, C)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: RTRADEBAL(" + C + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: RTRADEBAL(" + C + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def RTRADEBAL_ERROR(model, C):
    if ((C) in sets["CTR"]):
        error = np.abs(RTRADEBAL_RHS(model, C) - RTRADEBAL_LHS(model, C))
        return error
    else:
        return 0

# original:
# RTRAPRBAL(C, R)$(CTR(C)$RL(R)).. REGTRADE(C, R) =L= QPRDC(C, R)$(CC(C)$RCMAP(R, C)) * (1-(WASTE(C) + SEED(C))) + QPRDA(C, R)$CA(C)

def RTRAPRBAL_LHS(model, C, R):
    return model.REGTRADE[C, R]
def RTRAPRBAL_RHS(model, C, R):
    return ((((model.QPRDC[C, R]) if ((((((C) in sets["CC"])) if (((R, C) in sets["RCMAP"])) else 0))) else 0) * ((1.0 - ((WASTE(model, C) + SEED(model, C)))))) + ((model.QPRDA[C, R]) if (((C) in sets["CA"])) else 0))
def RTRAPRBAL(model, C, R):
    if (((((C) in sets["CTR"])) if (((R) in sets["RL"])) else 0)):
        constraint = (
            RTRAPRBAL_LHS(model, C, R) <= RTRAPRBAL_RHS(model, C, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: RTRAPRBAL(" + C + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: RTRAPRBAL(" + C + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def RTRAPRBAL_ERROR(model, C, R):
    if (((((C) in sets["CTR"])) if (((R) in sets["RL"])) else 0)):
        error = RTRAPRBAL_LHS(model, C, R) - RTRAPRBAL_RHS(model, C, R)
        return error
    else:
        return 0

# original:
# DSFEEDBAL(FEEDS, R)$RL(R).. SUM((XA, M),(XLIVE(XA, M, R) *FEEDREQ(XA, M, FEEDS))) =L= FEEDAV(FEEDS, R)

def DSFEEDBAL_LHS(model, FEEDS, R):
    return sum([((model.XLIVE[XA, M, R] * table_FEEDREQ(XA, M, FEEDS))) for XA in sets["XA"] for M in sets["M"]])
def DSFEEDBAL_RHS(model, FEEDS, R):
    return model.FEEDAV[FEEDS, R]
def DSFEEDBAL(model, FEEDS, R):
    if ((R) in sets["RL"]):
        constraint = (
            DSFEEDBAL_LHS(model, FEEDS, R) <= DSFEEDBAL_RHS(model, FEEDS, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: DSFEEDBAL(" + FEEDS + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: DSFEEDBAL(" + FEEDS + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def DSFEEDBAL_ERROR(model, FEEDS, R):
    if ((R) in sets["RL"]):
        error = DSFEEDBAL_LHS(model, FEEDS, R) - DSFEEDBAL_RHS(model, FEEDS, R)
        return error
    else:
        return 0

# original:
# LABBAL(R, TM)$RL(R).. SUM((XC, PT, WI)$RXCMAP(R, XC), XCROP(XC, PT, WI, R) * LABREQC(XC, PT, R, TM, WI)) + SUM((XA, M),XLIVE(XA, M, R) * SUM(LSLAB,LABREQLS(XA, M, LSLAB))) / 12 =E= QLABT(R, TM) + QLABF(R, TM)

def LABBAL_LHS(model, R, TM):
    return (sum([(model.XCROP[XC, PT, WI, R] * LABREQC(model, XC, PT, R, TM, WI)) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, XC)]) + (sum([(model.XLIVE[XA, M, R] * sum([table_LABREQLS(XA, M, LSLAB) for LSLAB in sets["LSLAB"]])) for XA in sets["XA"] for M in sets["M"]]) / 12.0))
def LABBAL_RHS(model, R, TM):
    return (model.QLABT[R, TM] + model.QLABF[R, TM])
def LABBAL(model, R, TM):
    if ((R) in sets["RL"]):
        constraint = (
            LABBAL_LHS(model, R, TM) == LABBAL_RHS(model, R, TM)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: LABBAL(" + R + ", " + TM + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: LABBAL(" + R + ", " + TM + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def LABBAL_ERROR(model, R, TM):
    if ((R) in sets["RL"]):
        error = np.abs(LABBAL_RHS(model, R, TM) - LABBAL_LHS(model, R, TM))
        return error
    else:
        return 0

# original:
# LABFAMCON(R, TM)$RL(R).. QLABF(R, TM) =L= QLABSUP(R)

def LABFAMCON_LHS(model, R, TM):
    return model.QLABF[R, TM]
def LABFAMCON_RHS(model, R, TM):
    return QLABSUP(model, R)
def LABFAMCON(model, R, TM):
    if ((R) in sets["RL"]):
        constraint = (
            LABFAMCON_LHS(model, R, TM) <= LABFAMCON_RHS(model, R, TM)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: LABFAMCON(" + R + ", " + TM + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: LABFAMCON(" + R + ", " + TM + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def LABFAMCON_ERROR(model, R, TM):
    if ((R) in sets["RL"]):
        error = LABFAMCON_LHS(model, R, TM) - LABFAMCON_RHS(model, R, TM)
        return error
    else:
        return 0

# original:
# CSTDEFLAB.. LABCOST =E= (SUM((R, TM)$RL(R),WAVG(R, TM) * (QLABT(R, TM) + (QLABF(R, TM) * WRF))) +SUM((R, XA, M),XLIVE(XA, M, R) *LABREQLS(XA, M, "FRMMAN") * CSTFRMMAN(R))) / 1E6

def CSTDEFLAB_LHS(model):
    return model.LABCOST
def CSTDEFLAB_RHS(model):
    return (((sum([(WAVG(model, R, TM) * ((model.QLABT[R, TM] + ((model.QLABF[R, TM] * scalars["WRF"]))))) for R in sets["R"] for TM in sets["TM"] if ((R) in sets["RL"])]) + sum([(model.XLIVE[XA, M, R] * table_LABREQLS(XA, M, "FRMMAN") * CSTFRMMAN(model, R)) for R in sets["R"] for XA in sets["XA"] for M in sets["M"]]))) / 1000000.0)
def CSTDEFLAB(model):
    if True:
        constraint = (
            CSTDEFLAB_LHS(model) == CSTDEFLAB_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CSTDEFLAB(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CSTDEFLAB(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CSTDEFLAB_ERROR(model):
    if True:
        error = np.abs(CSTDEFLAB_RHS(model) - CSTDEFLAB_LHS(model))
        return error
    else:
        return 0

# original:
# CSTDEFOINP.. OINPCOST =E= (SUM((XA, M, R, LSOINP)$RL(R),XLIVE(XA, M, R) *LSOICST(XA, M, LSOINP)) +SUM((C, FCTYPE, R)$(CFCTMAP(C, FCTYPE)$RL(R)),GAVFCR(C, FCTYPE, R) *FCCONT(C, FCTYPE, "TRCST")) + SUM((XC, PT, WI, C, R)$RXCMAP(R, XC),CSTOINP(XC, PT, WI, C, R) *XCROP(XC, PT, WI, R))) / 1E6

def CSTDEFOINP_LHS(model):
    return model.OINPCOST
def CSTDEFOINP_RHS(model):
    return (((sum([(model.XLIVE[XA, M, R] * table_LSOICST(XA, M, LSOINP)) for XA in sets["XA"] for M in sets["M"] for R in sets["R"] for LSOINP in sets["LSOINP"] if ((R) in sets["RL"])]) + sum([(model.GAVFCR[C, FCTYPE, R] * table_FCCONT(C, FCTYPE, "TRCST")) for C in sets["C"] for FCTYPE in sets["FCTYPE"] for R in sets["R"] if (((((C, FCTYPE) in sets["CFCTMAP"])) if (((R) in sets["RL"])) else 0))]) + sum([(CSTOINP(model, XC, PT, WI, C, R) * model.XCROP[XC, PT, WI, R]) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] for C in sets["C"] for R in sets["R"] if table_RXCMAP(R, XC)]))) / 1000000.0)
def CSTDEFOINP(model):
    if True:
        constraint = (
            CSTDEFOINP_LHS(model) == CSTDEFOINP_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CSTDEFOINP(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CSTDEFOINP(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CSTDEFOINP_ERROR(model):
    if True:
        error = np.abs(CSTDEFOINP_RHS(model) - CSTDEFOINP_LHS(model))
        return error
    else:
        return 0

# original:
# CSTDEFPM.. PMCOST =E= (SUM(C$CIP(C),(SUM(R$RL(R),QPRDC(C, R)$RCMAP(R, C)))) + SUM((C, R),QIMPC(C, R)$PIMPC(C) * CSTPR(C)) + SUM((CN, R)$(CNF(CN)$RL(R)),QPRDC(CN, R) * CSTMRKF(CN)) + SUM((CN, R)$(CND(CN)$RL(R)),QPRDC(CN, R) * CSTMRKD(CN))) / 1E6

def CSTDEFPM_LHS(model):
    return model.PMCOST
def CSTDEFPM_RHS(model):
    return (((sum([(sum([((model.QPRDC[C, R]) if (((R, C) in sets["RCMAP"])) else 0) for R in sets["R"] if ((R) in sets["RL"])])) for C in sets["C"] if ((C) in sets["CIP"])]) + sum([(((model.QIMPC[C, R]) if (PIMPC(model, C)) else 0) * CSTPR(model, C)) for C in sets["C"] for R in sets["R"]]) + sum([(model.QPRDC[CN, R] * CSTMRKF(model, CN)) for CN in sets["CN"] for R in sets["R"] if (((((CN) in sets["CNF"])) if (((R) in sets["RL"])) else 0))]) + sum([(model.QPRDC[CN, R] * CSTMRKD(model, CN)) for CN in sets["CN"] for R in sets["R"] if (((((CN) in sets["CND"])) if (((R) in sets["RL"])) else 0))]))) / 1000000.0)
def CSTDEFPM(model):
    if True:
        constraint = (
            CSTDEFPM_LHS(model) == CSTDEFPM_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CSTDEFPM(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CSTDEFPM(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CSTDEFPM_ERROR(model):
    if True:
        error = np.abs(CSTDEFPM_RHS(model) - CSTDEFPM_LHS(model))
        return error
    else:
        return 0

# original:
# GCOMPAV(R, CF, FCTYPE)$(CFCTMAP(CF, FCTYPE)$RCMAP(R, CF)$RL(R)).. GAVFCR(CF, FCTYPE, R) =L= (QPRDC(CF, R) -QCNSC(CF, R)$CN(CF) +QIMPC(CF, R)$PIMPC(CF) -QEXPC(CF, R)$PEXPC(CF)) * CFCTMAP(CF, FCTYPE)

def GCOMPAV_LHS(model, R, CF, FCTYPE):
    return model.GAVFCR[CF, FCTYPE, R]
def GCOMPAV_RHS(model, R, CF, FCTYPE):
    return (((model.QPRDC[CF, R] - ((model.QCNSC[CF, R]) if (((CF) in sets["CN"])) else 0) + ((model.QIMPC[CF, R]) if (PIMPC(model, CF)) else 0) - ((model.QEXPC[CF, R]) if (PEXPC(model, CF)) else 0))) * ((CF, FCTYPE) in sets["CFCTMAP"]))
def GCOMPAV(model, R, CF, FCTYPE):
    if (((((CF, FCTYPE) in sets["CFCTMAP"])) if (((R, CF) in sets["RCMAP"]) and ((R) in sets["RL"])) else 0)):
        constraint = (
            GCOMPAV_LHS(model, R, CF, FCTYPE) <= GCOMPAV_RHS(model, R, CF, FCTYPE)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: GCOMPAV(" + R + ", " + CF + ", " + FCTYPE + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: GCOMPAV(" + R + ", " + CF + ", " + FCTYPE + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def GCOMPAV_ERROR(model, R, CF, FCTYPE):
    if (((((CF, FCTYPE) in sets["CFCTMAP"])) if (((R, CF) in sets["RCMAP"]) and ((R) in sets["RL"])) else 0)):
        error = GCOMPAV_LHS(model, R, CF, FCTYPE) - GCOMPAV_RHS(model, R, CF, FCTYPE)
        return error
    else:
        return 0

# original:
# NCOMPAV(R, CF, FCTYPE)$(CFCTMAP(CF, FCTYPE)$RCMAP(R, CF)$RL(R)).. NAVFCR(CF, FCTYPE, R) =L= GAVFCR(CF, FCTYPE, R) *FCCONT(CF, FCTYPE, "DM") *FCCONT(CF, FCTYPE, "NETUSE") *FCCONT(CF, FCTYPE, "MAXUSE")

def NCOMPAV_LHS(model, R, CF, FCTYPE):
    return model.NAVFCR[CF, FCTYPE, R]
def NCOMPAV_RHS(model, R, CF, FCTYPE):
    return (model.GAVFCR[CF, FCTYPE, R] * table_FCCONT(CF, FCTYPE, "DM") * table_FCCONT(CF, FCTYPE, "NETUSE") * table_FCCONT(CF, FCTYPE, "MAXUSE"))
def NCOMPAV(model, R, CF, FCTYPE):
    if (((((CF, FCTYPE) in sets["CFCTMAP"])) if (((R, CF) in sets["RCMAP"]) and ((R) in sets["RL"])) else 0)):
        constraint = (
            NCOMPAV_LHS(model, R, CF, FCTYPE) <= NCOMPAV_RHS(model, R, CF, FCTYPE)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: NCOMPAV(" + R + ", " + CF + ", " + FCTYPE + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: NCOMPAV(" + R + ", " + CF + ", " + FCTYPE + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def NCOMPAV_ERROR(model, R, CF, FCTYPE):
    if (((((CF, FCTYPE) in sets["CFCTMAP"])) if (((R, CF) in sets["RCMAP"]) and ((R) in sets["RL"])) else 0)):
        error = NCOMPAV_LHS(model, R, CF, FCTYPE) - NCOMPAV_RHS(model, R, CF, FCTYPE)
        return error
    else:
        return 0

# original:
# FCDIST(CF, R)$(RCMAP(R, CF)$RL(R)).. SUM(FCTYPE, GAVFCR(CF, FCTYPE, R)$(CFCTMAP(CF, FCTYPE)$RL(R))) =E= QPRDC(CF, R) -QCNSC(CF, R)$CN(CF) +QIMPC(CF, R)$PIMPC(CF) -QEXPC(CF, R)$PEXPC(CF)

def FCDIST_LHS(model, CF, R):
    return sum([((model.GAVFCR[CF, FCTYPE, R]) if ((((((CF, FCTYPE) in sets["CFCTMAP"])) if (((R) in sets["RL"])) else 0))) else 0) for FCTYPE in sets["FCTYPE"]])
def FCDIST_RHS(model, CF, R):
    return (model.QPRDC[CF, R] - ((model.QCNSC[CF, R]) if (((CF) in sets["CN"])) else 0) + ((model.QIMPC[CF, R]) if (PIMPC(model, CF)) else 0) - ((model.QEXPC[CF, R]) if (PEXPC(model, CF)) else 0))
def FCDIST(model, CF, R):
    if (((((R, CF) in sets["RCMAP"])) if (((R) in sets["RL"])) else 0)):
        constraint = (
            FCDIST_LHS(model, CF, R) == FCDIST_RHS(model, CF, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: FCDIST(" + CF + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: FCDIST(" + CF + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def FCDIST_ERROR(model, CF, R):
    if (((((R, CF) in sets["RCMAP"])) if (((R) in sets["RL"])) else 0)):
        error = np.abs(FCDIST_RHS(model, CF, R) - FCDIST_LHS(model, CF, R))
        return error
    else:
        return 0

# original:
# FDCMAX(C, FCTYPE, FEEDS, R)$(CFCTFMAP(C, FCTYPE, FEEDS)$RL(R)).. FEEDAV(FEEDS, R) *FCMAX(C, FCTYPE, FEEDS) =G= FEEDCOMP(FEEDS, R, C, FCTYPE)

def FDCMAX_LHS(model, C, FCTYPE, FEEDS, R):
    return (model.FEEDAV[FEEDS, R] * table_FCMAX(C, FCTYPE, FEEDS))
def FDCMAX_RHS(model, C, FCTYPE, FEEDS, R):
    return model.FEEDCOMP[FEEDS, R, C, FCTYPE]
def FDCMAX(model, C, FCTYPE, FEEDS, R):
    if (((CFCTFMAP(model, C, FCTYPE, FEEDS)) if (((R) in sets["RL"])) else 0)):
        constraint = (
            FDCMAX_LHS(model, C, FCTYPE, FEEDS, R) >= FDCMAX_RHS(model, C, FCTYPE, FEEDS, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: FDCMAX(" + C + ", " + FCTYPE + ", " + FEEDS + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: FDCMAX(" + C + ", " + FCTYPE + ", " + FEEDS + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def FDCMAX_ERROR(model, C, FCTYPE, FEEDS, R):
    if (((CFCTFMAP(model, C, FCTYPE, FEEDS)) if (((R) in sets["RL"])) else 0)):
        error = FDCMAX_RHS(model, C, FCTYPE, FEEDS, R) - FDCMAX_LHS(model, C, FCTYPE, FEEDS, R)
        return error
    else:
        return 0

# original:
# FDCTOT(C, FCTYPE, R)$(CFCTMAP(C, FCTYPE)$RL(R)).. SUM(FEEDS, FEEDCOMP(FEEDS, R, C, FCTYPE) * CFCTFMAP(C, FCTYPE, FEEDS)) =L= NAVFCR(C, FCTYPE, R)

def FDCTOT_LHS(model, C, FCTYPE, R):
    return sum([(model.FEEDCOMP[FEEDS, R, C, FCTYPE] * CFCTFMAP(model, C, FCTYPE, FEEDS)) for FEEDS in sets["FEEDS"]])
def FDCTOT_RHS(model, C, FCTYPE, R):
    return model.NAVFCR[C, FCTYPE, R]
def FDCTOT(model, C, FCTYPE, R):
    if (((((C, FCTYPE) in sets["CFCTMAP"])) if (((R) in sets["RL"])) else 0)):
        constraint = (
            FDCTOT_LHS(model, C, FCTYPE, R) <= FDCTOT_RHS(model, C, FCTYPE, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: FDCTOT(" + C + ", " + FCTYPE + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: FDCTOT(" + C + ", " + FCTYPE + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def FDCTOT_ERROR(model, C, FCTYPE, R):
    if (((((C, FCTYPE) in sets["CFCTMAP"])) if (((R) in sets["RL"])) else 0)):
        error = FDCTOT_LHS(model, C, FCTYPE, R) - FDCTOT_RHS(model, C, FCTYPE, R)
        return error
    else:
        return 0

# original:
# FDCOMP(FEEDS, R)$RL(R).. FEEDAV(FEEDS, R) =L= SUM((C, FCTYPE),FEEDCOMP(FEEDS, R, C, FCTYPE) $(CFCTFMAP(C, FCTYPE, FEEDS)$RCMAP(R, C)))

def FDCOMP_LHS(model, FEEDS, R):
    return model.FEEDAV[FEEDS, R]
def FDCOMP_RHS(model, FEEDS, R):
    return sum([((model.FEEDCOMP[FEEDS, R, C, FCTYPE]) if ((((CFCTFMAP(model, C, FCTYPE, FEEDS)) if (((R, C) in sets["RCMAP"])) else 0))) else 0) for C in sets["C"] for FCTYPE in sets["FCTYPE"]])
def FDCOMP(model, FEEDS, R):
    if ((R) in sets["RL"]):
        constraint = (
            FDCOMP_LHS(model, FEEDS, R) <= FDCOMP_RHS(model, FEEDS, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: FDCOMP(" + FEEDS + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: FDCOMP(" + FEEDS + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def FDCOMP_ERROR(model, FEEDS, R):
    if ((R) in sets["RL"]):
        error = FDCOMP_LHS(model, FEEDS, R) - FDCOMP_RHS(model, FEEDS, R)
        return error
    else:
        return 0

# original:
# FEEDTDET(FEEDS, R)$((NOT POFEEDS(FEEDS))$RL(R)).. SUM((CF, FCTYPE),FEEDCOMP(FEEDS, R, CF, FCTYPE)$RCMAP(R, CF) *FCCONT(CF, FCTYPE, "TDN-DM") * CFCTFMAP(CF, FCTYPE, FEEDS)) =G= FEEDAV(FEEDS, R) *FEEDSCOMP(FEEDS, "TDN-DM")

def FEEDTDET_LHS(model, FEEDS, R):
    return sum([(((model.FEEDCOMP[FEEDS, R, CF, FCTYPE]) if (((R, CF) in sets["RCMAP"])) else 0) * table_FCCONT(CF, FCTYPE, "TDN-DM") * CFCTFMAP(model, CF, FCTYPE, FEEDS)) for CF in sets["CF"] for FCTYPE in sets["FCTYPE"]])
def FEEDTDET_RHS(model, FEEDS, R):
    return (model.FEEDAV[FEEDS, R] * table_FEEDSCOMP(FEEDS, "TDN-DM"))
def FEEDTDET(model, FEEDS, R):
    if (((((not (((FEEDS) in sets["POFEEDS"]))))) if (((R) in sets["RL"])) else 0)):
        constraint = (
            FEEDTDET_LHS(model, FEEDS, R) >= FEEDTDET_RHS(model, FEEDS, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: FEEDTDET(" + FEEDS + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: FEEDTDET(" + FEEDS + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def FEEDTDET_ERROR(model, FEEDS, R):
    if (((((not (((FEEDS) in sets["POFEEDS"]))))) if (((R) in sets["RL"])) else 0)):
        error = FEEDTDET_RHS(model, FEEDS, R) - FEEDTDET_LHS(model, FEEDS, R)
        return error
    else:
        return 0

# original:
# FEEDCDET(FEEDS, R)$RL(R).. SUM((CF, FCTYPE),FEEDCOMP(FEEDS, R, CF, FCTYPE)$RCMAP(R, CF) *FCCONT(CF, FCTYPE, "CP-DM") * CFCTFMAP(CF, FCTYPE, FEEDS)) =G= FEEDAV(FEEDS, R) *FEEDSCOMP(FEEDS, "CP-DM")

def FEEDCDET_LHS(model, FEEDS, R):
    return sum([(((model.FEEDCOMP[FEEDS, R, CF, FCTYPE]) if (((R, CF) in sets["RCMAP"])) else 0) * table_FCCONT(CF, FCTYPE, "CP-DM") * CFCTFMAP(model, CF, FCTYPE, FEEDS)) for CF in sets["CF"] for FCTYPE in sets["FCTYPE"]])
def FEEDCDET_RHS(model, FEEDS, R):
    return (model.FEEDAV[FEEDS, R] * table_FEEDSCOMP(FEEDS, "CP-DM"))
def FEEDCDET(model, FEEDS, R):
    if ((R) in sets["RL"]):
        constraint = (
            FEEDCDET_LHS(model, FEEDS, R) >= FEEDCDET_RHS(model, FEEDS, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: FEEDCDET(" + FEEDS + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: FEEDCDET(" + FEEDS + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def FEEDCDET_ERROR(model, FEEDS, R):
    if ((R) in sets["RL"]):
        error = FEEDCDET_RHS(model, FEEDS, R) - FEEDCDET_LHS(model, FEEDS, R)
        return error
    else:
        return 0

# original:
# FEEDMDET(FEEDS, R)$(POFEEDS(FEEDS)$RL(R)).. SUM((CF, FCTYPE),FEEDCOMP(FEEDS, R, CF, FCTYPE) *FCCONT(CF, FCTYPE, "ME-DM") * CFCTFMAP(CF, FCTYPE, FEEDS)) =G= FEEDAV(FEEDS, R) *FEEDSCOMP(FEEDS, "ME-DM")

def FEEDMDET_LHS(model, FEEDS, R):
    return sum([(model.FEEDCOMP[FEEDS, R, CF, FCTYPE] * table_FCCONT(CF, FCTYPE, "ME-DM") * CFCTFMAP(model, CF, FCTYPE, FEEDS)) for CF in sets["CF"] for FCTYPE in sets["FCTYPE"]])
def FEEDMDET_RHS(model, FEEDS, R):
    return (model.FEEDAV[FEEDS, R] * table_FEEDSCOMP(FEEDS, "ME-DM"))
def FEEDMDET(model, FEEDS, R):
    if (((((FEEDS) in sets["POFEEDS"])) if (((R) in sets["RL"])) else 0)):
        constraint = (
            FEEDMDET_LHS(model, FEEDS, R) >= FEEDMDET_RHS(model, FEEDS, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: FEEDMDET(" + FEEDS + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: FEEDMDET(" + FEEDS + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def FEEDMDET_ERROR(model, FEEDS, R):
    if (((((FEEDS) in sets["POFEEDS"])) if (((R) in sets["RL"])) else 0)):
        error = FEEDMDET_RHS(model, FEEDS, R) - FEEDMDET_LHS(model, FEEDS, R)
        return error
    else:
        return 0

# original:
# FEEDDET(FEEDS, R)$RL(R).. SUM((CF, FCTYPE),FEEDCOMP(FEEDS, R, CF, FCTYPE) * CFCTFMAP(CF, FCTYPE, FEEDS)) =E= FEEDAV(FEEDS, R)

def FEEDDET_LHS(model, FEEDS, R):
    return sum([(model.FEEDCOMP[FEEDS, R, CF, FCTYPE] * CFCTFMAP(model, CF, FCTYPE, FEEDS)) for CF in sets["CF"] for FCTYPE in sets["FCTYPE"]])
def FEEDDET_RHS(model, FEEDS, R):
    return model.FEEDAV[FEEDS, R]
def FEEDDET(model, FEEDS, R):
    if ((R) in sets["RL"]):
        constraint = (
            FEEDDET_LHS(model, FEEDS, R) == FEEDDET_RHS(model, FEEDS, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: FEEDDET(" + FEEDS + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: FEEDDET(" + FEEDS + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def FEEDDET_ERROR(model, FEEDS, R):
    if ((R) in sets["RL"]):
        error = np.abs(FEEDDET_RHS(model, FEEDS, R) - FEEDDET_LHS(model, FEEDS, R))
        return error
    else:
        return 0

# original:
# CHARGEE(R)$RL(R).. CHARGE(R) =E= (SUM(XC, (SUM(PT, (SUM(WI, XCROP(XC, PT, WI, R)$RXCMAP(R, XC)) *WATER1(XC, PT, R))) * CROPCHARGE(XC, R)))) / 1E6

def CHARGEE_LHS(model, R):
    return model.CHARGE[R]
def CHARGEE_RHS(model, R):
    return ((sum([((sum([((sum([((model.XCROP[XC, PT, WI, R]) if (table_RXCMAP(R, XC)) else 0) for WI in sets["WI"]]) * WATER1(model, XC, PT, R))) for PT in sets["PT"]]) * CROPCHARGE(model, XC, R))) for XC in sets["XC"]])) / 1000000.0)
def CHARGEE(model, R):
    if ((R) in sets["RL"]):
        constraint = (
            CHARGEE_LHS(model, R) == CHARGEE_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CHARGEE(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CHARGEE(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CHARGEE_ERROR(model, R):
    if ((R) in sets["RL"]):
        error = np.abs(CHARGEE_RHS(model, R) - CHARGEE_LHS(model, R))
        return error
    else:
        return 0

# original:
# WATERCOST.. TWATCOST =E= PWAT/1000 * SUM(UENV,RELEASE(UENV))

def WATERCOST_LHS(model):
    return model.TWATCOST
def WATERCOST_RHS(model):
    return (scalars["PWAT"] / 1000.0 * sum([model.RELEASE[UENV] for UENV in sets["UENV"]]))
def WATERCOST(model):
    if True:
        constraint = (
            WATERCOST_LHS(model) == WATERCOST_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: WATERCOST(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: WATERCOST(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def WATERCOST_ERROR(model):
    if True:
        error = np.abs(WATERCOST_RHS(model) - WATERCOST_LHS(model))
        return error
    else:
        return 0

# original:
# CROPAREA.. SUM((XC, PT, WI, R)$(RL(R)$RXCMAP(R, XC)), XCROP(XC, PT, WI, R))=L= TCROPAREA

def CROPAREA_LHS(model):
    return sum([model.XCROP[XC, PT, WI, R] for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if (((((R) in sets["RL"])) if (table_RXCMAP(R, XC)) else 0))])
def CROPAREA_RHS(model):
    return scalars["TCROPAREA"]
def CROPAREA(model):
    if True:
        constraint = (
            CROPAREA_LHS(model) <= CROPAREA_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CROPAREA(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CROPAREA(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CROPAREA_ERROR(model):
    if True:
        error = CROPAREA_LHS(model) - CROPAREA_RHS(model)
        return error
    else:
        return 0

# original:
# CROPAREAF.. SUM((XC, PT, WI, R)$(RL(R)$RXCMAP(R, XC)), XCROP(XC, PT, WI, R))=E= TCROPAREA

def CROPAREAF_LHS(model):
    return sum([model.XCROP[XC, PT, WI, R] for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if (((((R) in sets["RL"])) if (table_RXCMAP(R, XC)) else 0))])
def CROPAREAF_RHS(model):
    return scalars["TCROPAREA"]
def CROPAREAF(model):
    if True:
        constraint = (
            CROPAREAF_LHS(model) == CROPAREAF_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CROPAREAF(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CROPAREAF(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CROPAREAF_ERROR(model):
    if True:
        error = np.abs(CROPAREAF_RHS(model) - CROPAREAF_LHS(model))
        return error
    else:
        return 0

# original:
#  CRPAREASHA(XC, R)$(RL(R)$RXCMAP(R, XC)).. SUM((PT, WI)$RXCMAP(R, XC), XCROP(XC, PT, WI, R))=L=HAREAS(XC, R) * CRPAREAFRH

def CRPAREASHA_LHS(model, XC, R):
    return sum([model.XCROP[XC, PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, XC)])
def CRPAREASHA_RHS(model, XC, R):
    return (table_HAREAS(XC, R) * scalars["CRPAREAFRH"])
def CRPAREASHA(model, XC, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, XC)) else 0)):
        constraint = (
            CRPAREASHA_LHS(model, XC, R) <= CRPAREASHA_RHS(model, XC, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CRPAREASHA(" + XC + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CRPAREASHA(" + XC + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CRPAREASHA_ERROR(model, XC, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, XC)) else 0)):
        error = CRPAREASHA_LHS(model, XC, R) - CRPAREASHA_RHS(model, XC, R)
        return error
    else:
        return 0

# original:
#  CRPAREASMI(XC, R)$(RL(R)$RXCMAP(R, XC)).. SUM((PT, WI)$RXCMAP(R, XC), XCROP(XC, PT, WI, R))=G=HAREAS(XC, R) * CRPAREAFRL

def CRPAREASMI_LHS(model, XC, R):
    return sum([model.XCROP[XC, PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, XC)])
def CRPAREASMI_RHS(model, XC, R):
    return (table_HAREAS(XC, R) * scalars["CRPAREAFRL"])
def CRPAREASMI(model, XC, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, XC)) else 0)):
        constraint = (
            CRPAREASMI_LHS(model, XC, R) >= CRPAREASMI_RHS(model, XC, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CRPAREASMI(" + XC + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CRPAREASMI(" + XC + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CRPAREASMI_ERROR(model, XC, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, XC)) else 0)):
        error = CRPAREASMI_RHS(model, XC, R) - CRPAREASMI_LHS(model, XC, R)
        return error
    else:
        return 0

# original:
# NILEBAL.. SUM(R$RSW(R), (DIVA(R) +DIVARICE(R)$RICEMAP(R) + MUNDEM(R) +INDDEM(R) +EVAP(R))) +SEAFLOW +SEAFLOWFP =E= MAXREL +SUM(R$RSW(R), (((DIVA(R)) * (1-IEFF(R) *FEFF(R)) +DIVARICE(R)$RICEMAP(R) + MUNDEM(R) * MUNRET(R) +INDDEM(R) * INDRET(R)) *DRAINAGE(R, "TONILE")))

def NILEBAL_LHS(model):
    return (sum([((model.DIVA[R] + ((model.DIVARICE[R]) if (((R) in sets["RICEMAP"])) else 0) + MUNDEM(model, R) + INDDEM(model, R) + EVAP(model, R))) for R in sets["R"] if ((R) in sets["RSW"])]) + model.SEAFLOW + scalars["SEAFLOWFP"])
def NILEBAL_RHS(model):
    return (scalars["MAXREL"] + sum([((((((model.DIVA[R]) * ((1.0 - (IEFF(model, R) * FEFF(model, R))))) + ((model.DIVARICE[R]) if (((R) in sets["RICEMAP"])) else 0) + (MUNDEM(model, R) * MUNRET(model, R)) + (INDDEM(model, R) * INDRET(model, R)))) * table_DRAINAGE(R, "TONILE"))) for R in sets["R"] if ((R) in sets["RSW"])]))
def NILEBAL(model):
    if True:
        constraint = (
            NILEBAL_LHS(model) == NILEBAL_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: NILEBAL(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: NILEBAL(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def NILEBAL_ERROR(model):
    if True:
        error = np.abs(NILEBAL_RHS(model) - NILEBAL_LHS(model))
        return error
    else:
        return 0

# original:
# DGWBAL.. SUM(R$DGW(R), (DIVA(R) +DIVARICE(R)$RICEMAP(R) + MUNDEM(R) +INDDEM(R) +EVAP(R))) =L= MAXDGW

def DGWBAL_LHS(model):
    return sum([((model.DIVA[R] + ((model.DIVARICE[R]) if (((R) in sets["RICEMAP"])) else 0) + MUNDEM(model, R) + INDDEM(model, R) + EVAP(model, R))) for R in sets["R"] if ((R) in sets["DGW"])])
def DGWBAL_RHS(model):
    return scalars["MAXDGW"]
def DGWBAL(model):
    if True:
        constraint = (
            DGWBAL_LHS(model) <= DGWBAL_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: DGWBAL(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: DGWBAL(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def DGWBAL_ERROR(model):
    if True:
        error = DGWBAL_LHS(model) - DGWBAL_RHS(model)
        return error
    else:
        return 0

# original:
# DIVADEF(R)$(NOT SEA(R)).. DIVA(R) =E= (SUM((XC, PT, WI)$RXCMAP(R, XC), XCROP(XC, PT, WI, R) * WATREQ(XC, PT, WI, R)) + SUM(TM, FALLOW(R, TM) *FALET(R, TM))) / IEFF(R) / FEFF(R) / 1E6

def DIVADEF_LHS(model, R):
    return model.DIVA[R]
def DIVADEF_RHS(model, R):
    return (((sum([(model.XCROP[XC, PT, WI, R] * WATREQ(model, XC, PT, WI, R)) for XC in sets["XC"] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, XC)]) + sum([(model.FALLOW[R, TM] * table_FALET(R, TM)) for TM in sets["TM"]]))) / IEFF(model, R) / FEFF(model, R) / 1000000.0)
def DIVADEF(model, R):
    if ((not (((R) in sets["SEA"])))):
        constraint = (
            DIVADEF_LHS(model, R) == DIVADEF_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: DIVADEF(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: DIVADEF(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def DIVADEF_ERROR(model, R):
    if ((not (((R) in sets["SEA"])))):
        error = np.abs(DIVADEF_RHS(model, R) - DIVADEF_LHS(model, R))
        return error
    else:
        return 0

# original:
# DIVARICDEF(R)$RICEMAP(R).. DIVARICE(R) =E= SUM((XCRICE, PT, WI)$RXCMAP(R, XCRICE), XCROP(XCRICE, PT, WI, R)) *RICEPER/IEFF(R) / 1E6

def DIVARICDEF_LHS(model, R):
    return model.DIVARICE[R]
def DIVARICDEF_RHS(model, R):
    return (sum([model.XCROP[XCRICE, PT, WI, R] for XCRICE in sets["XCRICE"] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, XCRICE)]) * scalars["RICEPER"] / IEFF(model, R) / 1000000.0)
def DIVARICDEF(model, R):
    if ((R) in sets["RICEMAP"]):
        constraint = (
            DIVARICDEF_LHS(model, R) == DIVARICDEF_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: DIVARICDEF(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: DIVARICDEF(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def DIVARICDEF_ERROR(model, R):
    if ((R) in sets["RICEMAP"]):
        error = np.abs(DIVARICDEF_RHS(model, R) - DIVARICDEF_LHS(model, R))
        return error
    else:
        return 0

# original:
# CAFIX(XC, R)$(RL(R)$RXCMAP(R, XC)).. SUM((PT, WI), XCROP(XC, PT, WI, R)) =E= HAREAS(XC, R) * CRPAREAFRL

def CAFIX_LHS(model, XC, R):
    return sum([model.XCROP[XC, PT, WI, R] for PT in sets["PT"] for WI in sets["WI"]])
def CAFIX_RHS(model, XC, R):
    return (table_HAREAS(XC, R) * scalars["CRPAREAFRL"])
def CAFIX(model, XC, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, XC)) else 0)):
        constraint = (
            CAFIX_LHS(model, XC, R) == CAFIX_RHS(model, XC, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CAFIX(" + XC + ", " + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CAFIX(" + XC + ", " + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CAFIX_ERROR(model, XC, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, XC)) else 0)):
        error = np.abs(CAFIX_RHS(model, XC, R) - CAFIX_LHS(model, XC, R))
        return error
    else:
        return 0

# original:
# OBJFN.. CPS =E= (SUM(CN,(ALPHACR(CN) + 0.5 *BETACR(CN) * SUM(R$RL(R),QCNSCR(CN, R))) *SUM(R$RL(R),QCNSCR(CN, R))) + SUM(CN,(ALPHACU(CN) + 0.5 *BETACU(CN) * SUM(R$RL(R),QCNSCU(CN, R))) *SUM(R$RL(R),QCNSCU(CN, R))) + SUM((CN, R)$RCMAP(R, CN),QEXPC(CN, R) * PEXPC(CN)) - SUM((C, R)$(PIMPC(C)$RL(R)),QIMPC(C, R) *PIMPC(C))) / 1E6 - LABCOST - OINPCOST - PMCOST - LRECCOST - SUM(R$RL(R),CHARGE(R)) - TWATCOST

def OBJFN_LHS(model):
    return model.CPS
def OBJFN_RHS(model):
    return ((((sum([(((ALPHACR(model, CN) + (0.5 * BETACR(model, CN) * sum([model.QCNSCR[CN, R] for R in sets["R"] if ((R) in sets["RL"])])))) * sum([model.QCNSCR[CN, R] for R in sets["R"] if ((R) in sets["RL"])])) for CN in sets["CN"]]) + sum([(((ALPHACU(model, CN) + (0.5 * BETACU(model, CN) * sum([model.QCNSCU[CN, R] for R in sets["R"] if ((R) in sets["RL"])])))) * sum([model.QCNSCU[CN, R] for R in sets["R"] if ((R) in sets["RL"])])) for CN in sets["CN"]]) + sum([(model.QEXPC[CN, R] * PEXPC(model, CN)) for CN in sets["CN"] for R in sets["R"] if ((R, CN) in sets["RCMAP"])]) - sum([(model.QIMPC[C, R] * PIMPC(model, C)) for C in sets["C"] for R in sets["R"] if (((PIMPC(model, C)) if (((R) in sets["RL"])) else 0))]))) / 1000000.0) - model.LABCOST - model.OINPCOST - model.PMCOST - model.LRECCOST - sum([model.CHARGE[R] for R in sets["R"] if ((R) in sets["RL"])]) - model.TWATCOST)
def OBJFN(model):
    if True:
        constraint = (
            OBJFN_LHS(model) == OBJFN_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: OBJFN(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: OBJFN(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def OBJFN_ERROR(model):
    if True:
        error = np.abs(OBJFN_RHS(model) - OBJFN_LHS(model))
        return error
    else:
        return 0

# original:
#  VEGETW("VEGETW1", R)$(RL(R)$RXCMAP(R, "VEGETW1")).. SUM((PT, WI)$RXCMAP(R, "VEGETW1"), XCROP("VEGETW1", PT, WI, R))=G= (SUM((PT, WI)$RXCMAP(R, "VEGETW1"), XCROP("VEGETW1", PT, WI, R)) +SUM((PT, WI)$RXCMAP(R, "VEGETS1"), XCROP("VEGETS1", PT, WI, R)) +SUM((PT, WI)$RXCMAP(R, "VEGETN1"), XCROP("VEGETN1", PT, WI, R))) / 5

def VEGETW_LHS(model, R):
    return sum([model.XCROP["VEGETW1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "VEGETW1")])
def VEGETW_RHS(model, R):
    return (((sum([model.XCROP["VEGETW1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "VEGETW1")]) + sum([model.XCROP["VEGETS1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "VEGETS1")]) + sum([model.XCROP["VEGETN1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "VEGETN1")]))) / 5.0)
def VEGETW(model, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, "VEGETW1")) else 0)):
        constraint = (
            VEGETW_LHS(model, R) >= VEGETW_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: VEGETW(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: VEGETW(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def VEGETW_ERROR(model, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, "VEGETW1")) else 0)):
        error = VEGETW_RHS(model, R) - VEGETW_LHS(model, R)
        return error
    else:
        return 0

# original:
#  VEGETS("VEGETS1", R)$(RL(R)$RXCMAP(R, "VEGETS1")).. SUM((PT, WI)$RXCMAP(R, "VEGETS1"), XCROP("VEGETS1", PT, WI, R))=G= (SUM((PT, WI)$RXCMAP(R, "VEGETW1"), XCROP("VEGETW1", PT, WI, R)) +SUM((PT, WI)$RXCMAP(R, "VEGETS1"), XCROP("VEGETS1", PT, WI, R)) +SUM((PT, WI)$RXCMAP(R, "VEGETN1"), XCROP("VEGETN1", PT, WI, R))) / 5

def VEGETS_LHS(model, R):
    return sum([model.XCROP["VEGETS1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "VEGETS1")])
def VEGETS_RHS(model, R):
    return (((sum([model.XCROP["VEGETW1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "VEGETW1")]) + sum([model.XCROP["VEGETS1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "VEGETS1")]) + sum([model.XCROP["VEGETN1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "VEGETN1")]))) / 5.0)
def VEGETS(model, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, "VEGETS1")) else 0)):
        constraint = (
            VEGETS_LHS(model, R) >= VEGETS_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: VEGETS(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: VEGETS(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def VEGETS_ERROR(model, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, "VEGETS1")) else 0)):
        error = VEGETS_RHS(model, R) - VEGETS_LHS(model, R)
        return error
    else:
        return 0

# original:
#  VEGETN("VEGETN1", R)$(RL(R)$RXCMAP(R, "VEGETN1")).. SUM((PT, WI)$RXCMAP(R, "VEGETN1"), XCROP("VEGETN1", PT, WI, R))=G= (SUM((PT, WI)$RXCMAP(R, "VEGETW1"), XCROP("VEGETW1", PT, WI, R)) +SUM((PT, WI)$RXCMAP(R, "VEGETS1"), XCROP("VEGETS1", PT, WI, R)) +SUM((PT, WI)$RXCMAP(R, "VEGETN1"), XCROP("VEGETN1", PT, WI, R))) / 10

def VEGETN_LHS(model, R):
    return sum([model.XCROP["VEGETN1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "VEGETN1")])
def VEGETN_RHS(model, R):
    return (((sum([model.XCROP["VEGETW1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "VEGETW1")]) + sum([model.XCROP["VEGETS1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "VEGETS1")]) + sum([model.XCROP["VEGETN1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "VEGETN1")]))) / 10.0)
def VEGETN(model, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, "VEGETN1")) else 0)):
        constraint = (
            VEGETN_LHS(model, R) >= VEGETN_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: VEGETN(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: VEGETN(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def VEGETN_ERROR(model, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, "VEGETN1")) else 0)):
        error = VEGETN_RHS(model, R) - VEGETN_LHS(model, R)
        return error
    else:
        return 0

# original:
#  TOMATW("TMATOW1", R)$(RL(R)$RXCMAP(R, "TMATOW1")).. SUM((PT, WI)$RXCMAP(R, "TMATOW1"), XCROP("TMATOW1", PT, WI, R))=G= (SUM((PT, WI)$RXCMAP(R, "TMATOW1"), XCROP("TMATOW1", PT, WI, R)) +SUM((PT, WI)$RXCMAP(R, "TMATOS1"), XCROP("TMATOS1", PT, WI, R)) +SUM((PT, WI)$RXCMAP(R, "TMATON1"), XCROP("TMATON1", PT, WI, R))) / 5

def TOMATW_LHS(model, R):
    return sum([model.XCROP["TMATOW1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "TMATOW1")])
def TOMATW_RHS(model, R):
    return (((sum([model.XCROP["TMATOW1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "TMATOW1")]) + sum([model.XCROP["TMATOS1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "TMATOS1")]) + sum([model.XCROP["TMATON1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "TMATON1")]))) / 5.0)
def TOMATW(model, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, "TMATOW1")) else 0)):
        constraint = (
            TOMATW_LHS(model, R) >= TOMATW_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: TOMATW(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: TOMATW(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def TOMATW_ERROR(model, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, "TMATOW1")) else 0)):
        error = TOMATW_RHS(model, R) - TOMATW_LHS(model, R)
        return error
    else:
        return 0

# original:
#  TOMATS("TMATOS1", R)$(RL(R)$RXCMAP(R, "TMATOS1")).. SUM((PT, WI)$RXCMAP(R, "TMATOS1"), XCROP("TMATOS1", PT, WI, R))=G= (SUM((PT, WI)$RXCMAP(R, "TMATOW1"), XCROP("TMATOW1", PT, WI, R)) +SUM((PT, WI)$RXCMAP(R, "TMATOS1"), XCROP("TMATOS1", PT, WI, R)) +SUM((PT, WI)$RXCMAP(R, "TMATON1"), XCROP("TMATON1", PT, WI, R))) / 5

def TOMATS_LHS(model, R):
    return sum([model.XCROP["TMATOS1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "TMATOS1")])
def TOMATS_RHS(model, R):
    return (((sum([model.XCROP["TMATOW1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "TMATOW1")]) + sum([model.XCROP["TMATOS1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "TMATOS1")]) + sum([model.XCROP["TMATON1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "TMATON1")]))) / 5.0)
def TOMATS(model, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, "TMATOS1")) else 0)):
        constraint = (
            TOMATS_LHS(model, R) >= TOMATS_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: TOMATS(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: TOMATS(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def TOMATS_ERROR(model, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, "TMATOS1")) else 0)):
        error = TOMATS_RHS(model, R) - TOMATS_LHS(model, R)
        return error
    else:
        return 0

# original:
#  TOMATN("TMATON1", R)$(RL(R)$RXCMAP(R, "TMATON1")).. SUM((PT, WI)$RXCMAP(R, "TMATON1"), XCROP("TMATON1", PT, WI, R))=G= (SUM((PT, WI)$RXCMAP(R, "TMATOW1"), XCROP("TMATOW1", PT, WI, R)) +SUM((PT, WI)$RXCMAP(R, "TMATOS1"), XCROP("TMATOS1", PT, WI, R)) +SUM((PT, WI)$RXCMAP(R, "TMATON1"), XCROP("TMATON1", PT, WI, R))) / 10

def TOMATN_LHS(model, R):
    return sum([model.XCROP["TMATON1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "TMATON1")])
def TOMATN_RHS(model, R):
    return (((sum([model.XCROP["TMATOW1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "TMATOW1")]) + sum([model.XCROP["TMATOS1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "TMATOS1")]) + sum([model.XCROP["TMATON1", PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] if table_RXCMAP(R, "TMATON1")]))) / 10.0)
def TOMATN(model, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, "TMATON1")) else 0)):
        constraint = (
            TOMATN_LHS(model, R) >= TOMATN_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: TOMATN(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: TOMATN(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def TOMATN_ERROR(model, R):
    if (((((R) in sets["RL"])) if (table_RXCMAP(R, "TMATON1")) else 0)):
        error = TOMATN_RHS(model, R) - TOMATN_LHS(model, R)
        return error
    else:
        return 0

# original:
#  CROPMIN(XC).. SUM((PT, WI, R)$(RL(R)$RXCMAP(R, XC)), XCROP(XC, PT, WI, R))=G=0.001

def CROPMIN_LHS(model, XC):
    return sum([model.XCROP[XC, PT, WI, R] for PT in sets["PT"] for WI in sets["WI"] for R in sets["R"] if (((((R) in sets["RL"])) if (table_RXCMAP(R, XC)) else 0))])
def CROPMIN_RHS(model, XC):
    return 0.001
def CROPMIN(model, XC):
    if True:
        constraint = (
            CROPMIN_LHS(model, XC) >= CROPMIN_RHS(model, XC)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: CROPMIN(" + XC + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: CROPMIN(" + XC + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def CROPMIN_ERROR(model, XC):
    if True:
        error = CROPMIN_RHS(model, XC) - CROPMIN_LHS(model, XC)
        return error
    else:
        return 0

# original:
#  DIVATOTN.. TOTDIVAN=E=SUM(R$RSW(R),(DIVA(R)+DIVARICE(R)$RICEMAP(R)))

def DIVATOTN_LHS(model):
    return model.TOTDIVAN
def DIVATOTN_RHS(model):
    return sum([((model.DIVA[R] + ((model.DIVARICE[R]) if (((R) in sets["RICEMAP"])) else 0))) for R in sets["R"] if ((R) in sets["RSW"])])
def DIVATOTN(model):
    if True:
        constraint = (
            DIVATOTN_LHS(model) == DIVATOTN_RHS(model)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: DIVATOTN(" + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: DIVATOTN(" + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def DIVATOTN_ERROR(model):
    if True:
        error = np.abs(DIVATOTN_RHS(model) - DIVATOTN_LHS(model))
        return error
    else:
        return 0

# original:
#  DIVAPROP(R)$RSW(R).. (DIVA(R)+DIVARICE(R)$RICEMAP(R))=L=50.776 *PROPDIVA(R)

def DIVAPROP_LHS(model, R):
    return ((model.DIVA[R] + ((model.DIVARICE[R]) if (((R) in sets["RICEMAP"])) else 0)))
def DIVAPROP_RHS(model, R):
    return (50.776 * PROPDIVA(model, R))
def DIVAPROP(model, R):
    if ((R) in sets["RSW"]):
        constraint = (
            DIVAPROP_LHS(model, R) <= DIVAPROP_RHS(model, R)
        )
        if type(constraint) == np.bool_ or type(constraint) == bool:
            if constraint:
                # print("Warning: Always true constraint found, skip: DIVAPROP(" + R + ")")
                return pyo.Constraint.Skip
            else:
                print("Error: Unfeasable constraint found: DIVAPROP(" + R + ")")
                exit()
        else:
            return constraint
    else:
        return pyo.Constraint.Skip
def DIVAPROP_ERROR(model, R):
    if ((R) in sets["RSW"]):
        error = DIVAPROP_LHS(model, R) - DIVAPROP_RHS(model, R)
        return error
    else:
        return 0


if args.mode.lower() == "opt":
    model.add_component("CC", pyo.Set(initialize=sets["CC"], within=model.C))
    model.add_component("NL", pyo.Set(initialize=sets["NL"], within=model.R))
    model.add_component("CHL", pyo.Set(initialize=sets["CHL"], within=model.C))
    model.add_component("RICEMAP", pyo.Set(initialize=sets["RICEMAP"], within=model.R))
    model.add_component("RCMAP", pyo.Set(initialize=sets["RCMAP"], within=model.R * model.C))
    model.add_component("CHECK0", pyo.Set(initialize=sets["CHECK0"], within=model.XC * model.PT * model.R * model.TM))
    model.add_component("CHECK0AA", pyo.Set(initialize=sets["CHECK0AA"], within=model.XC * model.PT * model.R))
    model.add_component("CHECK0A", pyo.Set(initialize=sets["CHECK0A"], within=model.XC * model.PT * model.R))
    model.add_component("CHECK1", pyo.Set(initialize=sets["CHECK1"], within=model.XC * model.PT * model.R * model.TM))
    model.add_component("CHECK1A", pyo.Set(initialize=sets["CHECK1A"], within=model.XC * model.PT * model.R))
    model.add_component("CHECK2A", pyo.Set(initialize=sets["CHECK2A"], within=model.XC * model.PT * model.R * model.TM))
    model.add_component("CHECK2", pyo.Set(initialize=sets["CHECK2"], within=model.XC * model.PT * model.R * model.TM))
    model.add_component("CHECK3", pyo.Set(initialize=sets["CHECK3"], within=model.R * model.TM))
    model.add_component("CHECK6", pyo.Set(initialize=sets["CHECK6"], within=model.XC * model.PT * model.R))
    model.add_component("CHECK6A", pyo.Set(initialize=sets["CHECK6A"], within=model.XC * model.PT * model.R))
    model.add_component("CHECK12", pyo.Set(initialize=sets["CHECK12"], within=model.XC * model.C * model.R))
    model.add_component("CHECK12H", pyo.Set(initialize=sets["CHECK12H"], within=model.XC * model.C * model.R))
    model.add_component("CHECK12A", pyo.Set(initialize=sets["CHECK12A"]))
    model.add_component("CHECK12AA", pyo.Set(initialize=sets["CHECK12AA"]))
    model.add_component("CHECK12B", pyo.Set(initialize=sets["CHECK12B"], within=model.XC * model.C))
    model.add_component("CHECK48", pyo.Set(initialize=sets["CHECK48"], within=model.WI))
    model.add_component("CHECK12C", pyo.Set(initialize=sets["CHECK12C"], within=model.XC))
    model.add_component("CHECK12D", pyo.Set(initialize=sets["CHECK12D"], within=model.XC * model.INP))
    model.add_component("CHECK12F", pyo.Set(initialize=sets["CHECK12F"], within=model.XC * model.INP))
    model.add_component("CHECK12E", pyo.Set(initialize=sets["CHECK12E"], within=model.XC * model.INP))
    model.add_component("CHECK13", pyo.Set(initialize=sets["CHECK13"], within=model.CIP))
    model.add_component("CHECK14", pyo.Set(initialize=sets["CHECK14"], within=model.CIP))
    model.add_component("CHECK15", pyo.Set(initialize=sets["CHECK15"]))
    model.add_component("CHECK15D", pyo.Set(initialize=sets["CHECK15D"]))
    model.add_component("CHECK16A", pyo.Set(initialize=sets["CHECK16A"]))
    model.add_component("CHECK16B", pyo.Set(initialize=sets["CHECK16B"]))
    model.add_component("CHECK17A", pyo.Set(initialize=sets["CHECK17A"]))
    model.add_component("CHECK17B", pyo.Set(initialize=sets["CHECK17B"]))
    model.add_component("CHECK17C", pyo.Set(initialize=sets["CHECK17C"]))
    model.add_component("CHECK17D", pyo.Set(initialize=sets["CHECK17D"]))
    model.add_component("CHECK17E", pyo.Set(initialize=sets["CHECK17E"]))
    model.add_component("CHECK12K", pyo.Set(initialize=sets["CHECK12K"]))
    model.add_component("CHECK12G", pyo.Set(initialize=sets["CHECK12G"]))
    model.add_component("CHECK40", pyo.Set(initialize=sets["CHECK40"], within=model.XC * model.R))
    model.add_component("CHECK18", pyo.Set(initialize=sets["CHECK18"], within=model.XA * model.M))
    model.add_component("CHECK22", pyo.Set(initialize=sets["CHECK22"], within=model.XA * model.M * model.LSLAB))
    model.add_component("CHECK23", pyo.Set(initialize=sets["CHECK23"], within=model.XA * model.M))
    model.add_component("CHECK24", pyo.Set(initialize=sets["CHECK24"], within=model.XA * model.M))
    model.add_component("CHECK43", pyo.Set(initialize=sets["CHECK43"], within=model.R))
    model.add_component("CHECK43B", pyo.Set(initialize=sets["CHECK43B"], within=model.R))
    model.add_component("CHECK44A", pyo.Set(initialize=sets["CHECK44A"], within=model.R))
    model.add_component("CHECK45", pyo.Set(initialize=sets["CHECK45"], within=model.R))
    model.add_component("CHECK46", pyo.Set(initialize=sets["CHECK46"], within=model.R))

    model.add_component("CHARGE", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("DGWPUMP", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("DIVA", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("DIVARICE", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("DWRU", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("FALLOW", pyo.Var(model.R, model.TM, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("FCTYPES", pyo.Var(model.C, model.FCTYPE, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("FEEDAV", pyo.Var(model.FEEDS, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("FEEDCOMP", pyo.Var(model.FEEDS, model.R, model.C, model.FCTYPE, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("GAVFCR", pyo.Var(model.C, model.FCTYPE, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("GENDRAIN", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("LABCOST", pyo.Var(within=pyo.NonNegativeReals, initialize=0))
    model.add_component("LRECCOST", pyo.Var(within=pyo.NonNegativeReals, initialize=0))
    model.add_component("NAVFCR", pyo.Var(model.C, model.FCTYPE, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("OINPCOST", pyo.Var(within=pyo.NonNegativeReals, initialize=0))
    model.add_component("PMCOST", pyo.Var(within=pyo.NonNegativeReals, initialize=0))
    model.add_component("QCNSC", pyo.Var(model.C, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("QCNSCR", pyo.Var(model.C, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("QCNSCU", pyo.Var(model.C, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("QCNSCL", pyo.Var(model.C, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("QCNSCLR", pyo.Var(model.C, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("QCNSCLU", pyo.Var(model.C, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("QEXPC", pyo.Var(model.C, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("QIMPC", pyo.Var(model.C, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("QLABF", pyo.Var(model.R, model.TM, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("QLABT", pyo.Var(model.R, model.TM, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("QPRDA", pyo.Var(model.C, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("QPRDC", pyo.Var(model.C, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("RELEASE", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))

    def SEAFLOW_bounds(model, ):
        low = None
        high = None
        low = 0.7
        return (low, high)

    model.add_component("SEAFLOW", pyo.Var(within=pyo.NonNegativeReals, bounds=SEAFLOW_bounds, initialize=0))
    model.add_component("TWATCOST", pyo.Var(within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XCITR", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XCOTR", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XCROP", pyo.Var(model.XC, model.PT, model.WI, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XCROPNAT", pyo.Var(model.XC, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XLIVE", pyo.Var(model.XA, model.M, model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XRICENAT", pyo.Var(within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XRICR", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XSBER", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XSCAR", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XVEGNR", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XVEGSR", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XVEGWR", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XGRAINR", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XOILSR", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XOTLEGR", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XFODR", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XSORGR", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("XACROPR", pyo.Var(model.R, within=pyo.NonNegativeReals, initialize=0))
    model.add_component("CPS", pyo.Var(within=pyo.Reals, initialize=0))
    model.add_component("REGTRADE", pyo.Var(model.C, model.R, within=pyo.Reals, initialize=0))
    model.add_component("IMPORTS", pyo.Var(model.C, within=pyo.Reals, initialize=0))
    model.add_component("EXPORTS", pyo.Var(model.C, within=pyo.Reals, initialize=0))
    model.add_component("TOTDIVAN", pyo.Var(within=pyo.Reals, initialize=0))

    model.add_component("CONSUMMAX", pyo.Constraint(model.C, rule=CONSUMMAX))
    model.add_component("CITRDEFREG", pyo.Constraint(model.R, rule=CITRDEFREG))
    model.add_component("BERSEEROT1", pyo.Constraint(model.R, rule=BERSEEROT1))
    model.add_component("CCDPMAX", pyo.Constraint(rule=CCDPMAX))
    # model.add_component("CONSUMMIN", pyo.Constraint(model.C, rule=CONSUMMIN))
    model.add_component("COTDEFREG", pyo.Constraint(model.R, rule=COTDEFREG))
    model.add_component("CROPAREA", pyo.Constraint(rule=CROPAREA))
    model.add_component("CSTDEFLAB", pyo.Constraint(rule=CSTDEFLAB))
    model.add_component("CSTDEFLREC", pyo.Constraint(rule=CSTDEFLREC))
    model.add_component("CSTDEFOINP", pyo.Constraint(rule=CSTDEFOINP))
    model.add_component("CSTDEFPM", pyo.Constraint(rule=CSTDEFPM))
    model.add_component("DIVADEF", pyo.Constraint(model.R, rule=DIVADEF))
    model.add_component("DIVARICDEF", pyo.Constraint(model.R, rule=DIVARICDEF))
    model.add_component("DGWBAL", pyo.Constraint(rule=DGWBAL))
    model.add_component("DSBALCNR", pyo.Constraint(model.C, model.R, rule=DSBALCNR))
    model.add_component("DSBALIP1", pyo.Constraint(model.R, rule=DSBALIP1))
    model.add_component("DSBALIP2", pyo.Constraint(model.R, rule=DSBALIP2))
    model.add_component("DSFEEDBAL", pyo.Constraint(model.FEEDS, model.R, rule=DSFEEDBAL))
    model.add_component("EXPORT", pyo.Constraint(model.C, rule=EXPORT))
    model.add_component("FCDIST", pyo.Constraint(model.CF, model.R, rule=FCDIST))
    model.add_component("FDCMAX", pyo.Constraint(model.C, model.FCTYPE, model.FEEDS, model.R, rule=FDCMAX))
    model.add_component("FDCOMP", pyo.Constraint(model.FEEDS, model.R, rule=FDCOMP))
    model.add_component("FDCTOT", pyo.Constraint(model.C, model.FCTYPE, model.R, rule=FDCTOT))
    model.add_component("FEEDCDET", pyo.Constraint(model.FEEDS, model.R, rule=FEEDCDET))
    model.add_component("FEEDTDET", pyo.Constraint(model.FEEDS, model.R, rule=FEEDTDET))
    model.add_component("FEEDMDET", pyo.Constraint(model.FEEDS, model.R, rule=FEEDMDET))
    model.add_component("FEEDDET", pyo.Constraint(model.FEEDS, model.R, rule=FEEDDET))
    model.add_component("FLAXROT", pyo.Constraint(model.R, rule=FLAXROT))
    model.add_component("GCOMPAV", pyo.Constraint(model.R, model.CF, model.FCTYPE, rule=GCOMPAV))
    model.add_component("IMPORT", pyo.Constraint(model.C, rule=IMPORT))
    model.add_component("LABBAL", pyo.Constraint(model.R, model.TM, rule=LABBAL))
    model.add_component("LANDCON", pyo.Constraint(model.R, model.TM, rule=LANDCON))
    model.add_component("NCOMPAV", pyo.Constraint(model.R, model.CF, model.FCTYPE, rule=NCOMPAV))
    model.add_component("NILEBAL", pyo.Constraint(rule=NILEBAL))
    model.add_component("OBJFN", pyo.Constraint(rule=OBJFN))
    model.add_component("POTATOROT", pyo.Constraint(model.R, rule=POTATOROT))
    model.add_component("PRDCROP", pyo.Constraint(model.C, model.R, rule=PRDCROP))
    model.add_component("PRDLVST", pyo.Constraint(model.C, model.R, rule=PRDLVST))
    model.add_component("QCNSCDET", pyo.Constraint(model.C, model.R, rule=QCNSCDET))
    model.add_component("RICDEFREG", pyo.Constraint(model.R, rule=RICDEFREG))
    model.add_component("RICEDEFNAT", pyo.Constraint(rule=RICEDEFNAT))
    model.add_component("RTRADEBAL", pyo.Constraint(model.C, rule=RTRADEBAL))
    model.add_component("RTRAPRBAL", pyo.Constraint(model.C, model.R, rule=RTRAPRBAL))
    model.add_component("SBDPMAX", pyo.Constraint(rule=SBDPMAX))
    model.add_component("SBEDEFREG", pyo.Constraint(model.R, rule=SBEDEFREG))
    model.add_component("SCADEFREG", pyo.Constraint(model.R, rule=SCADEFREG))
    model.add_component("SBEETROT", pyo.Constraint(model.R, rule=SBEETROT))
    model.add_component("SBERSEEROT", pyo.Constraint(model.PT, model.R, rule=SBERSEEROT))
    model.add_component("SCDPMAX", pyo.Constraint(rule=SCDPMAX))
    model.add_component("VEGWDEFREG", pyo.Constraint(model.R, rule=VEGWDEFREG))
    model.add_component("VEGNDEFREG", pyo.Constraint(model.R, rule=VEGNDEFREG))
    model.add_component("VEGSDEFREG", pyo.Constraint(model.R, rule=VEGSDEFREG))
    model.add_component("WATERCOST", pyo.Constraint(rule=WATERCOST))
    model.add_component("XCDEFNAT", pyo.Constraint(model.XC, rule=XCDEFNAT))
    model.add_component("VEGETW", pyo.Constraint(model.R, rule=VEGETW))
    model.add_component("VEGETS", pyo.Constraint(model.R, rule=VEGETS))
    model.add_component("VEGETN", pyo.Constraint(model.R, rule=VEGETN))
    model.add_component("TOMATW", pyo.Constraint(model.R, rule=TOMATW))
    model.add_component("TOMATS", pyo.Constraint(model.R, rule=TOMATS))
    model.add_component("TOMATN", pyo.Constraint(model.R, rule=TOMATN))
    model.add_component("CROPMIN", pyo.Constraint(model.XC, rule=CROPMIN))

if args.mode.lower() == "sim":
    tolerance = 10 ** -int(args.tolerance)

    print("Info: Starting to check constraints")
    print("Info: Tolerance: " + str(tolerance))

    for C in sets["C"]:
        error = CONSUMMAX_ERROR(model, C)
        if error > tolerance:
            print("Error: Constraint CONSUMMAX(" + C + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = CITRDEFREG_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint CITRDEFREG(" + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = BERSEEROT1_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint BERSEEROT1(" + R + ") is not satisfied, error = " + str(error))

    error = CCDPMAX_ERROR(model)
    if error > tolerance:
        print("Error: Constraint CCDPMAX is not satisfied, error = " + str(error))

    for C in sets["C"]:
        error = CONSUMMIN_ERROR(model, C)
        if error > tolerance:
            print("Error: Constraint CONSUMMIN(" + C + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = COTDEFREG_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint COTDEFREG(" + R + ") is not satisfied, error = " + str(error))

    error = CROPAREA_ERROR(model)
    if error > tolerance:
        print("Error: Constraint CROPAREA is not satisfied, error = " + str(error))

    error = CSTDEFLAB_ERROR(model)
    if error > tolerance:
        print("Error: Constraint CSTDEFLAB is not satisfied, error = " + str(error))

    error = CSTDEFLREC_ERROR(model)
    if error > tolerance:
        print("Error: Constraint CSTDEFLREC is not satisfied, error = " + str(error))

    error = CSTDEFOINP_ERROR(model)
    if error > tolerance:
        print("Error: Constraint CSTDEFOINP is not satisfied, error = " + str(error))

    error = CSTDEFPM_ERROR(model)
    if error > tolerance:
        print("Error: Constraint CSTDEFPM is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = DIVADEF_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint DIVADEF(" + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = DIVARICDEF_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint DIVARICDEF(" + R + ") is not satisfied, error = " + str(error))

    error = DGWBAL_ERROR(model)
    if error > tolerance:
        print("Error: Constraint DGWBAL is not satisfied, error = " + str(error))

    for C, R in itertools.product(sets["C"], sets["R"]):
        error = DSBALCNR_ERROR(model, C, R)
        if error > tolerance:
            print("Error: Constraint DSBALCNR(" + C + ", " + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = DSBALIP1_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint DSBALIP1(" + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = DSBALIP2_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint DSBALIP2(" + R + ") is not satisfied, error = " + str(error))

    for FEEDS, R in itertools.product(sets["FEEDS"], sets["R"]):
        error = DSFEEDBAL_ERROR(model, FEEDS, R)
        if error > tolerance:
            print("Error: Constraint DSFEEDBAL(" + FEEDS + ", " + R + ") is not satisfied, error = " + str(error))

    for C in sets["C"]:
        error = EXPORT_ERROR(model, C)
        if error > tolerance:
            print("Error: Constraint EXPORT(" + C + ") is not satisfied, error = " + str(error))

    for CF, R in itertools.product(sets["CF"], sets["R"]):
        error = FCDIST_ERROR(model, CF, R)
        if error > tolerance:
            print("Error: Constraint FCDIST(" + CF + ", " + R + ") is not satisfied, error = " + str(error))

    for C, FCTYPE, FEEDS, R in itertools.product(sets["C"], sets["FCTYPE"], sets["FEEDS"], sets["R"]):
        error = FDCMAX_ERROR(model, C, FCTYPE, FEEDS, R)
        if error > tolerance:
            print("Error: Constraint FDCMAX(" + C + ", " + FCTYPE + ", " + FEEDS + ", " + R + ") is not satisfied, error = " + str(error))

    for FEEDS, R in itertools.product(sets["FEEDS"], sets["R"]):
        error = FDCOMP_ERROR(model, FEEDS, R)
        if error > tolerance:
            print("Error: Constraint FDCOMP(" + FEEDS + ", " + R + ") is not satisfied, error = " + str(error))

    for C, FCTYPE, R in itertools.product(sets["C"], sets["FCTYPE"], sets["R"]):
        error = FDCTOT_ERROR(model, C, FCTYPE, R)
        if error > tolerance:
            print("Error: Constraint FDCTOT(" + C + ", " + FCTYPE + ", " + R + ") is not satisfied, error = " + str(error))

    for FEEDS, R in itertools.product(sets["FEEDS"], sets["R"]):
        error = FEEDCDET_ERROR(model, FEEDS, R)
        if error > tolerance:
            print("Error: Constraint FEEDCDET(" + FEEDS + ", " + R + ") is not satisfied, error = " + str(error))

    for FEEDS, R in itertools.product(sets["FEEDS"], sets["R"]):
        error = FEEDTDET_ERROR(model, FEEDS, R)
        if error > tolerance:
            print("Error: Constraint FEEDTDET(" + FEEDS + ", " + R + ") is not satisfied, error = " + str(error))

    for FEEDS, R in itertools.product(sets["FEEDS"], sets["R"]):
        error = FEEDMDET_ERROR(model, FEEDS, R)
        if error > tolerance:
            print("Error: Constraint FEEDMDET(" + FEEDS + ", " + R + ") is not satisfied, error = " + str(error))

    for FEEDS, R in itertools.product(sets["FEEDS"], sets["R"]):
        error = FEEDDET_ERROR(model, FEEDS, R)
        if error > tolerance:
            print("Error: Constraint FEEDDET(" + FEEDS + ", " + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = FLAXROT_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint FLAXROT(" + R + ") is not satisfied, error = " + str(error))

    for R, CF, FCTYPE in itertools.product(sets["R"], sets["CF"], sets["FCTYPE"]):
        error = GCOMPAV_ERROR(model, R, CF, FCTYPE)
        if error > tolerance:
            print("Error: Constraint GCOMPAV(" + R + ", " + CF + ", " + FCTYPE + ") is not satisfied, error = " + str(error))

    for C in sets["C"]:
        error = IMPORT_ERROR(model, C)
        if error > tolerance:
            print("Error: Constraint IMPORT(" + C + ") is not satisfied, error = " + str(error))

    for R, TM in itertools.product(sets["R"], sets["TM"]):
        error = LABBAL_ERROR(model, R, TM)
        if error > tolerance:
            print("Error: Constraint LABBAL(" + R + ", " + TM + ") is not satisfied, error = " + str(error))

    for R, TM in itertools.product(sets["R"], sets["TM"]):
        error = LANDCON_ERROR(model, R, TM)
        if error > tolerance:
            print("Error: Constraint LANDCON(" + R + ", " + TM + ") is not satisfied, error = " + str(error))

    for R, CF, FCTYPE in itertools.product(sets["R"], sets["CF"], sets["FCTYPE"]):
        error = NCOMPAV_ERROR(model, R, CF, FCTYPE)
        if error > tolerance:
            print("Error: Constraint NCOMPAV(" + R + ", " + CF + ", " + FCTYPE + ") is not satisfied, error = " + str(error))

    error = NILEBAL_ERROR(model)
    if error > tolerance:
        print("Error: Constraint NILEBAL is not satisfied, error = " + str(error))

    error = OBJFN_ERROR(model)
    if error > tolerance:
        print("Error: Constraint OBJFN is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = POTATOROT_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint POTATOROT(" + R + ") is not satisfied, error = " + str(error))

    for C, R in itertools.product(sets["C"], sets["R"]):
        error = PRDCROP_ERROR(model, C, R)
        if error > tolerance:
            print("Error: Constraint PRDCROP(" + C + ", " + R + ") is not satisfied, error = " + str(error))

    for C, R in itertools.product(sets["C"], sets["R"]):
        error = PRDLVST_ERROR(model, C, R)
        if error > tolerance:
            print("Error: Constraint PRDLVST(" + C + ", " + R + ") is not satisfied, error = " + str(error))

    for C, R in itertools.product(sets["C"], sets["R"]):
        error = QCNSCDET_ERROR(model, C, R)
        if error > tolerance:
            print("Error: Constraint QCNSCDET(" + C + ", " + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = RICDEFREG_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint RICDEFREG(" + R + ") is not satisfied, error = " + str(error))

    error = RICEDEFNAT_ERROR(model)
    if error > tolerance:
        print("Error: Constraint RICEDEFNAT is not satisfied, error = " + str(error))

    for C in sets["C"]:
        error = RTRADEBAL_ERROR(model, C)
        if error > tolerance:
            print("Error: Constraint RTRADEBAL(" + C + ") is not satisfied, error = " + str(error))

    for C, R in itertools.product(sets["C"], sets["R"]):
        error = RTRAPRBAL_ERROR(model, C, R)
        if error > tolerance:
            print("Error: Constraint RTRAPRBAL(" + C + ", " + R + ") is not satisfied, error = " + str(error))

    error = SBDPMAX_ERROR(model)
    if error > tolerance:
        print("Error: Constraint SBDPMAX is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = SBEDEFREG_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint SBEDEFREG(" + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = SCADEFREG_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint SCADEFREG(" + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = SBEETROT_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint SBEETROT(" + R + ") is not satisfied, error = " + str(error))

    for PT, R in itertools.product(sets["PT"], sets["R"]):
        error = SBERSEEROT_ERROR(model, PT, R)
        if error > tolerance:
            print("Error: Constraint SBERSEEROT(" + PT + ", " + R + ") is not satisfied, error = " + str(error))

    error = SCDPMAX_ERROR(model)
    if error > tolerance:
        print("Error: Constraint SCDPMAX is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = VEGWDEFREG_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint VEGWDEFREG(" + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = VEGNDEFREG_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint VEGNDEFREG(" + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = VEGSDEFREG_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint VEGSDEFREG(" + R + ") is not satisfied, error = " + str(error))

    error = WATERCOST_ERROR(model)
    if error > tolerance:
        print("Error: Constraint WATERCOST is not satisfied, error = " + str(error))

    for XC in sets["XC"]:
        error = XCDEFNAT_ERROR(model, XC)
        if error > tolerance:
            print("Error: Constraint XCDEFNAT(" + XC + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = VEGETW_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint VEGETW(" + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = VEGETS_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint VEGETS(" + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = VEGETN_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint VEGETN(" + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = TOMATW_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint TOMATW(" + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = TOMATS_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint TOMATS(" + R + ") is not satisfied, error = " + str(error))

    for R in sets["R"]:
        error = TOMATN_ERROR(model, R)
        if error > tolerance:
            print("Error: Constraint TOMATN(" + R + ") is not satisfied, error = " + str(error))

    for XC in sets["XC"]:
        error = CROPMIN_ERROR(model, XC)
        if error > tolerance:
            print("Error: Constraint CROPMIN(" + XC + ") is not satisfied, error = " + str(error))

    print("Info: Finished checking constraints")



for R in [x for x in  set(sets["R"]) if x in  set(sets["RL"]).intersection(set(sets["R"]))]:
    if ((abs((1.0 - XX(model, R)))) > 0.001):
        print("Error: xx;")
        print("depending on: ", R)

if args.mode.lower() == "opt":
    model.add_component("OBJECTIVE", pyo.Objective(expr=model.CPS, sense=pyo.maximize))

    print(build_model_size_report(model))
    print("Model loaded.")
    print("Solving...")

    results = solver.solve(model, tee=True)

print("Info: Starting exporting custom output files")

file_INDICATOR_WB = open("output/INDICATOR_WB.txt", "w")
file_INDICATOR_WB = open("output/INDICATOR_WB.txt", "w")
helper.appendFile(file_INDICATOR_WB, ["=================================================================================\n"])
helper.appendFile(file_INDICATOR_WB, ["MAIN OUTPUT PARAMETERS\n"])
helper.appendFile(file_INDICATOR_WB, ["=================================================================================\n"])
helper.appendFile(file_INDICATOR_WB, ["Run specification                                ", lambda: helper.toString("GAMS_CONST.FP", 0, 2), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Available Nile water (HAD release)               BCM                 ", lambda: helper.toString(scalars["MAXREL"], 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Available deep ground water                      BCM                 ", lambda: helper.toString(scalars["MAXDGW"], 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Available desalinated water                      BCM                 ", lambda: helper.toString(DESALTOT(model), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Effective rain                                   BCM                 ", lambda: helper.toString(((EFECTRAINN(model) + EFECTRAIND(model))), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Inflow to Delta                                  BCM                 ", lambda: helper.toString((REPDIVDELT(model, "TOTDELTA")), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Reuse in Delta                                   BCM                 ", lambda: helper.toString((REPREUSED(model, "TOTDELTA")), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Reuse in Egypt                                   BCM                 ", lambda: helper.toString(REPDIVCONN(model, "EGYPT", "TONILE-T"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Drainage to Sea from Delta                       BCM                 ", lambda: helper.toString((REPDRASEAD(model, "TOTDELTA")), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Agricultural diversions Nile                     BCM                 ", lambda: helper.toString(((sum([REPDIVCONN(model, R, "DIV-AGR") for R in sets["R"] if ((not (((R) in sets["DGW"]))))]) + sum([REPDIVCONN(model, R, "DIV-RIC") for R in sets["R"] if ((not (((R) in sets["DGW"]))))]))), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Municipal diversion Nile                         BCM                 ", lambda: helper.toString(sum([REPDIVCONN(model, R, "DIV-MUN") for R in sets["R"] if ((not (((R) in sets["DGW"]))))]), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Industrial diversions Nile                       BCM                 ", lambda: helper.toString(sum([REPDIVCONN(model, R, "DIV-IND") for R in sets["R"] if ((not (((R) in sets["DGW"]))))]), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Deep groundwater use                             BCM                 ", lambda: helper.toString(sum([REPDIVCOND(model, R, "DIV-TOT") for R in sets["R"] if ((R) in sets["DGW"])]), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Virtual water import                             BCM                 ", lambda: helper.toString(VIRWATIMP(model), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Virtual water export                             BCM                 ", lambda: helper.toString(VIRWATEXP(model), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Net virtual water import                         BCM                 ", lambda: helper.toString(VIRWATNIN(model), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Net virtual irrigation water deficit             BCM                 ", lambda: helper.toString((((VIRWATNIN(model) / ((SYSTEMEF(model) / 100.0))))), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Overall system efficiency Nile                   %                   ", lambda: helper.toString(SYSTEMEF(model), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Population                                       Million             ", lambda: helper.toString(((TOTPOPF(model) / 1000.0)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Urbanisation                                     Ratio               ", lambda: helper.toString(((sum([table_POPULATION(R, "URB") for R in sets["R"] if (((R) in sets["RL"]))]) / TOTPOPF(model))), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Water availability per capita                    m3                  ", lambda: helper.toString(((((scalars["MAXREL"] + scalars["MAXDGW"] + EFECTRAINN(model) + EFECTRAIND(model) + DESALTOT(model))) / TOTPOPF(model) * 1000000.0)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Irrigable area Nile                              000 feddan          ", lambda: helper.toString(sum([((QLNDSUP(model, R) + LNDRECL(model, R))) for R in sets["R"] if ((not (((R) in sets["DGW"]))))]), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Irrigable area Deep Groundwater                  000 feddan          ", lambda: helper.toString(sum([((QLNDSUP(model, R) + LNDRECL(model, R))) for R in sets["R"] if (((R) in sets["DGW"]))]), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Gross agr. prod. value at farm gate prices       BLE                 ", lambda: helper.toString(((REPREVFG(model, "EGYPT", "GPV") / 1000.0)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Net agr. prod. value at farm gate prices         BLE                 ", lambda: helper.toString(((REPREVFG(model, "EGYPT", "NPV") / 1000.0)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Net agr. prod. val. p. fed. at farm gate prices  LE/fed              ", lambda: helper.toString(REPREVFFG(model, "EGYPT", "NPVPFED"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Net agr. prod. val. p. m3 at farm gate prices    LE/m3               ", lambda: helper.toString(REPREVFFG(model, "EGYPT", "NPVPM3"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Net return at farm gate prices per man day       LE/md               ", lambda: helper.toString(REPREVFFG(model, "EGYPT", "NPVPWORK"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Relative ET to ETm incl rain (%)                 %                   ", lambda: helper.toString((REPRELET(model, "AVERAGE", "EGYPT")), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cropping intensity                               %                   ", lambda: helper.toString(((REPCA(model, "INTENSTY", "EGYPT") * 100.0)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Average ET                                       m3/fed              ", lambda: helper.toString(WATDISTE(model), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Marginal value of water                          LE/m3               ", lambda: helper.toString(WATERSHAD(model), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Consumer-producer surplus                        BLE                 ", lambda: helper.toString(model.CPS.value, 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cropped area Old Lands                           000 feddan          ", lambda: helper.toString(sum([REPCA(model, "TOTAL", R) for R in sets["R"] if ((R) in sets["OL"])]), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cropped area Old New Lands                       000 feddan          ", lambda: helper.toString(sum([REPCA(model, "TOTAL", R) for R in sets["R"] if ((R) in sets["ONL"])]), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cropped area Toshka                              000 feddan          ", lambda: helper.toString(REPCA(model, "TOTAL", "TOSHKA"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cropped area El-Salaam                           000 feddan          ", lambda: helper.toString(REPCA(model, "TOTAL", "NSINAI"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Total cropped area surface irrigation            000 feddan          ", lambda: helper.toString(sum([REPCA(model, "TOTAL", R) for R in sets["R"] if ((R) in sets["RSW"])]), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cropped area groundwater irrigation              000 feddan          ", lambda: helper.toString(sum([REPCA(model, "TOTAL", R) for R in sets["R"] if ((R) in sets["DGW"])]), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Total cropped area                               000 feddan          ", lambda: helper.toString(sum([REPCA(model, "TOTAL", R) for R in sets["R"] if ((R) in sets["RL"])]), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Total water charges                              MLE                 ", lambda: helper.toString((sum([CROPCHARGE(model, XC, R) for XC in sets["XC"] for R in sets["R"]])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, [" \n"])
helper.appendFile(file_INDICATOR_WB, ["NILE WATER BALANCE\n"])
helper.appendFile(file_INDICATOR_WB, ["HAD Release                                      BCM                 ", lambda: helper.toString(scalars["MAXREL"], 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Effective rainfall                               BCM                 ", lambda: helper.toString(EFECTRAINN(model), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Environmental flow to Sea                        BCM                 ", lambda: helper.toString(((-(0.7))), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Additional flow to Sea                           BCM                 ", lambda: helper.toString(((-(REPWATBAL(model, "ADD_FLOW_TO_SEA", " ")))), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Drainage to Sea                                  BCM                 ", lambda: helper.toString(REPWATBAL(model, "DRAIN_TO_SEA", " "), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Drainage of fish ponds to Sea                    BCM                 ", lambda: helper.toString(REPWATBAL(model, "FISH_POND_TO_SEA", " "), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Drainage to sinks                                BCM                 ", lambda: helper.toString(REPWATBAL(model, "DRAIN_TO_SINK", " "), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Agricultural water consumption_GCCU              BCM                 ", lambda: helper.toString(REPWATBAL(model, "AGR_CONSUM_GCCU", " "), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Municipal water cons. excl. desalination         BCM                 ", lambda: helper.toString(REPWATBAL(model, "MUN_CONSUM_EX-DESIL", " "), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Industrial water consumption                     BCM                 ", lambda: helper.toString(REPWATBAL(model, "IND_CONSUM", " "), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Fallow land evaporation                          BCM                 ", lambda: helper.toString(REPWATBAL(model, "FALLOW_EVAP", " "), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Open water evaporation                           BCM                 ", lambda: helper.toString(REPWATBAL(model, "WET_SURF_EVAP", " "), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Balance                                          BCM                 ", lambda: helper.toString(REPWATBAL(model, "RESIDUAL", " "), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, [" \n"])
helper.appendFile(file_INDICATOR_WB, ["Desalination                                     BCM                 ", lambda: helper.toString((sum([DESAL(model, R) for R in sets["R"]])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Municipal abstraction                            BCM                 ", lambda: helper.toString(REPDIVCONN(model, "EGYPT", "DIV-MUN"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Industrial abstraction                           BCM                 ", lambda: helper.toString(REPDIVCONN(model, "EGYPT", "DIV-IND"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Agricultural abstraction                         BCM                 ", lambda: helper.toString(((REPDIVCONN(model, "EGYPT", "DIV-AGR") + REPDIVCONN(model, "EGYPT", "DIV-RIC"))), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Diversion of Nile water to the Deltas            BCM                 ", lambda: helper.toString(REPDIVDELT(model, "TOTDELTA"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Reuse of drainage water in Delta                 BCM                 ", lambda: helper.toString(REPWATBAL(model, "REUSE_DELTA", " "), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, [" \n"])
helper.appendFile(file_INDICATOR_WB, ["STRATEGIES \n"])
helper.appendFile(file_INDICATOR_WB, ["Rice area                                        000 fed             ", lambda: helper.toString(sum([REPCA(model, "PADDY1", R) for R in sets["R"] if ((R) in sets["RSW"])]), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Sugar Cane area                                  000 fed             ", lambda: helper.toString((sum([REPCA(model, "SCANE1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cotton area                                      000 fed             ", lambda: helper.toString(((sum([REPCA(model, "SDELS1", R) for R in sets["R"] if ((R) in sets["RSW"])]) + sum([REPCA(model, "SDLS1", R) for R in sets["R"] if ((R) in sets["RSW"])]))), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Orchards area                                    000 fed             ", lambda: helper.toString((sum([REPCA(model, "CITRUS1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["\n"])
helper.appendFile(file_INDICATOR_WB, ["ENERGY\n"])
helper.appendFile(file_INDICATOR_WB, ["Energy used for crop production and processing   TJ                  ", lambda: helper.toString((((COMENERGY(model, "TOTAL", "MJ")) / 1000000.0)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Energy used for crop production and processing   GJ/feddan           ", lambda: helper.toString((((((COMENERGY(model, "TOTAL", "MJ")) / sum([REPCA(model, "TOTAL", R) for R in sets["R"] if ((R) in sets["RL"])]))) / 1000.0)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Energy used for crop production and processing   MJ/m3               ", lambda: helper.toString((((-((((COMENERGY(model, "TOTAL", "MJ")) / (((REPWATBAL(model, "AGR_CONSUM_GCCU", " ")) + (REPWATBALD(model, "AGR_CONSUM_GCCU", " ")))))))) / 1000000000.0)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, [" \n"])
helper.appendFile(file_INDICATOR_WB, ["CROPPING PATTERN EGYPT\n"])
helper.appendFile(file_INDICATOR_WB, ["Barley                                           000 fed             ", lambda: helper.toString((sum([REPCA(model, "BARLEY1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Orchards                                         000 fed             ", lambda: helper.toString((sum([REPCA(model, "CITRUS1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Faba bean                                        000 fed             ", lambda: helper.toString((sum([REPCA(model, "FBEAN1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Flax                                             000 fed             ", lambda: helper.toString((sum([REPCA(model, "FLAX1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Groundnut                                        000 fed             ", lambda: helper.toString((sum([REPCA(model, "GNUT1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Long berseem                                     000 fed             ", lambda: helper.toString((sum([REPCA(model, "LBSEEM1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Lentil                                           000 fed             ", lambda: helper.toString((sum([REPCA(model, "LENTIL1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Nili Maize                                       000 fed             ", lambda: helper.toString((sum([REPCA(model, "MAIZEN1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Summer Maize                                     000 fed             ", lambda: helper.toString((sum([REPCA(model, "MAIZES1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Other legumes                                    000 fed             ", lambda: helper.toString((sum([REPCA(model, "OLGUME1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Summer Onion                                     000 fed             ", lambda: helper.toString((sum([REPCA(model, "ONIONS1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Winter Onion                                     000 fed             ", lambda: helper.toString((sum([REPCA(model, "ONIONW1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Rice                                             000 fed             ", lambda: helper.toString(sum([REPCA(model, "PADDY1", R) for R in sets["R"] if ((R) in sets["RSW"])]), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Nili Potato                                      000 fed             ", lambda: helper.toString((sum([REPCA(model, "PTATON1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Summer Potato                                    000 fed             ", lambda: helper.toString((sum([REPCA(model, "PTATOS1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Soybeans and Sunflower                           000 fed             ", lambda: helper.toString((sum([REPCA(model, "SBEAN1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Sugar Beet                                       000 fed             ", lambda: helper.toString((sum([REPCA(model, "SBEET1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Short berseem                                    000 fed             ", lambda: helper.toString((sum([REPCA(model, "SBSEMW1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Sugar Cane                                       000 fed             ", lambda: helper.toString((sum([REPCA(model, "SCANE1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cotton area                                      000 fed             ", lambda: helper.toString(((sum([REPCA(model, "SDELS1", R) for R in sets["R"] if ((R) in sets["RSW"])]) + sum([REPCA(model, "SDLS1", R) for R in sets["R"] if ((R) in sets["RSW"])]))), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Sesame                                           000 fed             ", lambda: helper.toString((sum([REPCA(model, "SESAME1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Nili Sorghum                                     000 fed             ", lambda: helper.toString((sum([REPCA(model, "SORGMN1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Summer Sorghum                                   000 fed             ", lambda: helper.toString((sum([REPCA(model, "SORGMS1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Nili Tomato                                      000 fed             ", lambda: helper.toString((sum([REPCA(model, "TMATON1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Summer Tomato                                    000 fed             ", lambda: helper.toString((sum([REPCA(model, "TMATOS1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Winter Tomato                                    000 fed             ", lambda: helper.toString((sum([REPCA(model, "TMATOW1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Nili Vegetables and Other crops                  000 fed             ", lambda: helper.toString((sum([REPCA(model, "VEGETN1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Summer Vegetables and Other crops                000 fed             ", lambda: helper.toString((sum([REPCA(model, "VEGETS1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Winter Vegetables and Other crops                000 fed             ", lambda: helper.toString((sum([REPCA(model, "VEGETW1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Wheat                                            000 fed             ", lambda: helper.toString((sum([REPCA(model, "WHEAT1", R) for R in sets["R"] if ((R) in sets["RSW"])])), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, [" \n"])
helper.appendFile(file_INDICATOR_WB, ["IMPORTS\n"])
helper.appendFile(file_INDICATOR_WB, ["Barley                                           000 t               ", lambda: helper.toString(REPIMP(model, "BARLEY", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Citrus                                           000 t               ", lambda: helper.toString(REPIMP(model, "CITRUS", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cotton ELF                                       000 t               ", lambda: helper.toString(REPIMP(model, "CTONELS", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cotton LF                                        000 t               ", lambda: helper.toString(REPIMP(model, "CTONLS", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Fava beans                                       000 t               ", lambda: helper.toString(REPIMP(model, "FBEAN", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Flax fibre                                       000 t               ", lambda: helper.toString(REPIMP(model, "FXFIB", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Groundnuts                                       000 t               ", lambda: helper.toString(REPIMP(model, "GRDNUT", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Lentils                                          000 t               ", lambda: helper.toString(REPIMP(model, "LENTIL", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Maize                                            000 t               ", lambda: helper.toString(REPIMP(model, "MAIZE", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Onions                                           000 t               ", lambda: helper.toString(REPIMP(model, "ONION", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Rice                                             000 t               ", lambda: helper.toString(REPIMP(model, "RICE", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Potatoes                                         000 t               ", lambda: helper.toString(REPIMP(model, "POTATO", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Sesame                                           000 t               ", lambda: helper.toString(REPIMP(model, "SESAME", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Sorghum                                          000 t               ", lambda: helper.toString(REPIMP(model, "SORGHUM", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Soybeans                                         000 t               ", lambda: helper.toString(REPIMP(model, "SOYBEAN", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Sugar                                            000 t               ", lambda: helper.toString(REPIMP(model, "SUGAR", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Tomatoes                                         000 t               ", lambda: helper.toString(REPIMP(model, "TOMATO", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Vegetable oil                                    000 t               ", lambda: helper.toString(REPIMP(model, "VEG-OIL", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Vegetables                                       000 t               ", lambda: helper.toString(REPIMP(model, "VEGET", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Wheat                                            000 t               ", lambda: helper.toString(((REPIMP(model, "WHEATF", "EGYPT") / 0.8)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Fresh beef                                       000 t               ", lambda: helper.toString(REPIMP(model, "CBEEF", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Frozen beef                                      000 t               ", lambda: helper.toString(REPIMP(model, "FBEEF", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Veal                                             000 t               ", lambda: helper.toString(REPIMP(model, "VEAL", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Sheep/goat meat                                  000 t               ", lambda: helper.toString(REPIMP(model, "SGMT", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Buffalow milk                                    000 t               ", lambda: helper.toString(REPIMP(model, "BMILK", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cow milk                                         000 t               ", lambda: helper.toString(REPIMP(model, "CMILK", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Ind. processing milk                             000 t               ", lambda: helper.toString(REPIMP(model, "IMILK", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Poultry meat                                     000 t               ", lambda: helper.toString(REPIMP(model, "PMEAT", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Value of imports 2021                            BLE                 ", lambda: helper.toString(REPVALIMP(model), 0, 2), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Value of imports 2021                            BUSD                ", lambda: helper.toString(((REPVALIMP(model) / 7.08)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Value of imports 2021                            % GDP               ", lambda: helper.toString(((REPVALIMP(model) / 2205.594 * 100.0)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, [" \n"])
helper.appendFile(file_INDICATOR_WB, ["EXPORTS\n"])
helper.appendFile(file_INDICATOR_WB, ["Barley                                           000 t               ", lambda: helper.toString(REPEXP(model, "BARLEY", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Citrus                                           000 t               ", lambda: helper.toString(REPEXP(model, "CITRUS", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cotton ELF                                       000 t               ", lambda: helper.toString(REPEXP(model, "CTONELS", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cotton LF                                        000 t               ", lambda: helper.toString(REPEXP(model, "CTONLS", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Fava beans                                       000 t               ", lambda: helper.toString(REPEXP(model, "FBEAN", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Flax fibre                                       000 t               ", lambda: helper.toString(REPEXP(model, "FXFIB", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Groundnuts                                       000 t               ", lambda: helper.toString(REPEXP(model, "GRDNUT", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Lentils                                          000 t               ", lambda: helper.toString(REPEXP(model, "LENTIL", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Maize                                            000 t               ", lambda: helper.toString(REPEXP(model, "MAIZE", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Onions                                           000 t               ", lambda: helper.toString(REPEXP(model, "ONION", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Rice                                             000 t               ", lambda: helper.toString(REPEXP(model, "RICE", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Potatoes                                         000 t               ", lambda: helper.toString(REPEXP(model, "POTATO", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Sesame                                           000 t               ", lambda: helper.toString(REPEXP(model, "SESAME", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Sorghum                                          000 t               ", lambda: helper.toString(REPEXP(model, "SORGHUM", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Soybeans                                         000 t               ", lambda: helper.toString(REPEXP(model, "SOYBEAN", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Sugar                                            000 t               ", lambda: helper.toString(REPEXP(model, "SUGAR", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Tomatoes                                         000 t               ", lambda: helper.toString(REPEXP(model, "TOMATO", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Vegetable oil                                    000 t               ", lambda: helper.toString(REPEXP(model, "VEG-OIL", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Vegetables                                       000 t               ", lambda: helper.toString(REPEXP(model, "VEGET", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Wheat                                            000 t               ", lambda: helper.toString(((REPEXP(model, "WHEATF", "EGYPT") / 0.8)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Fresh beef                                       000 t               ", lambda: helper.toString(REPEXP(model, "CBEEF", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Frozen beef                                      000 t               ", lambda: helper.toString(REPEXP(model, "FBEEF", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Veal                                             000 t               ", lambda: helper.toString(REPEXP(model, "VEAL", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Sheep/goat meat                                  000 t               ", lambda: helper.toString(REPEXP(model, "SGMT", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Buffalow milk                                    000 t               ", lambda: helper.toString(REPEXP(model, "BMILK", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cow milk                                         000 t               ", lambda: helper.toString(REPEXP(model, "CMILK", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Ind. processing milk                             000 t               ", lambda: helper.toString(REPEXP(model, "IMILK", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Poultry meat                                     000 t               ", lambda: helper.toString(REPEXP(model, "PMEAT", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Eggs                                             000 t               ", lambda: helper.toString(REPEXP(model, "EGGS", "EGYPT"), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Value of exports 2021                            BLE                 ", lambda: helper.toString(REPVALEXP(model), 0, 2), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Value of exports 2021                            BUSD                ", lambda: helper.toString(((REPVALEXP(model) / 7.08)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Value of exports 2021                            % GDP               ", lambda: helper.toString(((REPVALEXP(model) / 2205.594 * 100.0)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["\n"])
helper.appendFile(file_INDICATOR_WB, ["FOOD SELF-SUFFICIENCY\n"])
helper.appendFile(file_INDICATOR_WB, ["Wheat self-sufficiency                           %                   ", lambda: helper.toString((SELFFOOD(model, "WHEAT")), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Maize self-sufficiency                           %                   ", lambda: helper.toString((SELFFOOD(model, "MAIZE")), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Vegetable oil self-sufficiency                   %                   ", lambda: helper.toString((SELFFOOD(model, "VEG-OIL")), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Rice self-sufficiency                            %                   ", lambda: helper.toString((SELFFOOD(model, "RICE")), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Sugar self-sufficiency                           %                   ", lambda: helper.toString((SELFFOOD(model, "SUGAR")), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Meat self-sufficiency                            %                   ", lambda: helper.toString((SELFFOOD(model, "MEAT")), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Milk self-sufficiency                            %                   ", lambda: helper.toString((SELFFOOD(model, "MILK")), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Cereal self-sufficiency                          %                   ", lambda: helper.toString((SELFFOOD(model, "CEREALS")), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Inequity water distribution in agriculture       stdev m3/fed        ", lambda: helper.toString(VARREGF(model), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["\n"])
helper.appendFile(file_INDICATOR_WB, ["EMPLOYMENT\n"])
helper.appendFile(file_INDICATOR_WB, ["Employment crop production                       M mandays           ", lambda: helper.toString(((REPEMPL(model, "EGYPT", "CROPS") / 1000.0)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Employment animal husbandry                      M mandays           ", lambda: helper.toString(((REPEMPL(model, "EGYPT", "ANIMALS") / 1000.0)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Employment agro processing                       M mandays           ", lambda: helper.toString(((REPEMPL(model, "EGYPT", "AGROPROCES") / 1000.0)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Employment agricultural sector                   M mandays           ", lambda: helper.toString(((REPEMPL(model, "EGYPT", "TOTAL") / 1000.0)), 12, 3), "\n"])
helper.appendFile(file_INDICATOR_WB, ["Number of agri. and agro-industry jobs           M jobs              ", lambda: helper.toString(((REPEMPL(model, "EGYPT", "TOTAL") / ((143.648 * 1000.0)))), 12, 3), "\n"])
file_INDICATOR_WB.close()

file_INDICATOR_WB.close()

print("Info: Finished exporting custom output files")

if args.mode.lower() == "opt":
    print("Info: Start exporting variables")

    helper.funcToXlsx("variables_output/", "CHARGE", [sets["R"]], lambda R: model.CHARGE[R].value)
    helper.funcToXlsx("variables_output/", "DGWPUMP", [sets["R"]], lambda R: model.DGWPUMP[R].value)
    helper.funcToXlsx("variables_output/", "DIVA", [sets["R"]], lambda R: model.DIVA[R].value)
    helper.funcToXlsx("variables_output/", "DIVARICE", [sets["R"]], lambda R: model.DIVARICE[R].value)
    helper.funcToXlsx("variables_output/", "DWRU", [sets["R"]], lambda R: model.DWRU[R].value)
    helper.funcToXlsx("variables_output/", "FALLOW", [sets["R"], sets["TM"]], lambda R, TM: model.FALLOW[R, TM].value)
    helper.funcToXlsx("variables_output/", "FCTYPES", [sets["C"], sets["FCTYPE"]], lambda C, FCTYPE: model.FCTYPES[C, FCTYPE].value)
    helper.funcToXlsx("variables_output/", "FEEDAV", [sets["FEEDS"], sets["R"]], lambda FEEDS, R: model.FEEDAV[FEEDS, R].value)
    helper.funcToXlsx("variables_output/", "FEEDCOMP", [sets["FEEDS"], sets["R"], sets["C"], sets["FCTYPE"]], lambda FEEDS, R, C, FCTYPE: model.FEEDCOMP[FEEDS, R, C, FCTYPE].value)
    helper.funcToXlsx("variables_output/", "GAVFCR", [sets["C"], sets["FCTYPE"], sets["R"]], lambda C, FCTYPE, R: model.GAVFCR[C, FCTYPE, R].value)
    helper.funcToXlsx("variables_output/", "GENDRAIN", [sets["R"]], lambda R: model.GENDRAIN[R].value)
    helper.funcToXlsx("variables_output/", "LABCOST", [], lambda: model.LABCOST.value)
    helper.funcToXlsx("variables_output/", "LRECCOST", [], lambda: model.LRECCOST.value)
    helper.funcToXlsx("variables_output/", "NAVFCR", [sets["C"], sets["FCTYPE"], sets["R"]], lambda C, FCTYPE, R: model.NAVFCR[C, FCTYPE, R].value)
    helper.funcToXlsx("variables_output/", "OINPCOST", [], lambda: model.OINPCOST.value)
    helper.funcToXlsx("variables_output/", "PMCOST", [], lambda: model.PMCOST.value)
    helper.funcToXlsx("variables_output/", "QCNSC", [sets["C"], sets["R"]], lambda C, R: model.QCNSC[C, R].value)
    helper.funcToXlsx("variables_output/", "QCNSCR", [sets["C"], sets["R"]], lambda C, R: model.QCNSCR[C, R].value)
    helper.funcToXlsx("variables_output/", "QCNSCU", [sets["C"], sets["R"]], lambda C, R: model.QCNSCU[C, R].value)
    helper.funcToXlsx("variables_output/", "QCNSCL", [sets["C"], sets["R"]], lambda C, R: model.QCNSCL[C, R].value)
    helper.funcToXlsx("variables_output/", "QCNSCLR", [sets["C"], sets["R"]], lambda C, R: model.QCNSCLR[C, R].value)
    helper.funcToXlsx("variables_output/", "QCNSCLU", [sets["C"], sets["R"]], lambda C, R: model.QCNSCLU[C, R].value)
    helper.funcToXlsx("variables_output/", "QEXPC", [sets["C"], sets["R"]], lambda C, R: model.QEXPC[C, R].value)
    helper.funcToXlsx("variables_output/", "QIMPC", [sets["C"], sets["R"]], lambda C, R: model.QIMPC[C, R].value)
    helper.funcToXlsx("variables_output/", "QLABF", [sets["R"], sets["TM"]], lambda R, TM: model.QLABF[R, TM].value)
    helper.funcToXlsx("variables_output/", "QLABT", [sets["R"], sets["TM"]], lambda R, TM: model.QLABT[R, TM].value)
    helper.funcToXlsx("variables_output/", "QPRDA", [sets["C"], sets["R"]], lambda C, R: model.QPRDA[C, R].value)
    helper.funcToXlsx("variables_output/", "QPRDC", [sets["C"], sets["R"]], lambda C, R: model.QPRDC[C, R].value)
    helper.funcToXlsx("variables_output/", "RELEASE", [sets["R"]], lambda R: model.RELEASE[R].value)
    helper.funcToXlsx("variables_output/", "SEAFLOW", [], lambda: model.SEAFLOW.value)
    helper.funcToXlsx("variables_output/", "TWATCOST", [], lambda: model.TWATCOST.value)
    helper.funcToXlsx("variables_output/", "XCITR", [sets["R"]], lambda R: model.XCITR[R].value)
    helper.funcToXlsx("variables_output/", "XCOTR", [sets["R"]], lambda R: model.XCOTR[R].value)
    helper.funcToXlsx("variables_output/", "XCROP", [sets["XC"], sets["PT"], sets["WI"], sets["R"]], lambda XC, PT, WI, R: model.XCROP[XC, PT, WI, R].value)
    helper.funcToXlsx("variables_output/", "XCROPNAT", [sets["XC"]], lambda XC: model.XCROPNAT[XC].value)
    helper.funcToXlsx("variables_output/", "XLIVE", [sets["XA"], sets["M"], sets["R"]], lambda XA, M, R: model.XLIVE[XA, M, R].value)
    helper.funcToXlsx("variables_output/", "XRICENAT", [], lambda: model.XRICENAT.value)
    helper.funcToXlsx("variables_output/", "XRICR", [sets["R"]], lambda R: model.XRICR[R].value)
    helper.funcToXlsx("variables_output/", "XSBER", [sets["R"]], lambda R: model.XSBER[R].value)
    helper.funcToXlsx("variables_output/", "XSCAR", [sets["R"]], lambda R: model.XSCAR[R].value)
    helper.funcToXlsx("variables_output/", "XVEGNR", [sets["R"]], lambda R: model.XVEGNR[R].value)
    helper.funcToXlsx("variables_output/", "XVEGSR", [sets["R"]], lambda R: model.XVEGSR[R].value)
    helper.funcToXlsx("variables_output/", "XVEGWR", [sets["R"]], lambda R: model.XVEGWR[R].value)
    helper.funcToXlsx("variables_output/", "XGRAINR", [sets["R"]], lambda R: model.XGRAINR[R].value)
    helper.funcToXlsx("variables_output/", "XOILSR", [sets["R"]], lambda R: model.XOILSR[R].value)
    helper.funcToXlsx("variables_output/", "XOTLEGR", [sets["R"]], lambda R: model.XOTLEGR[R].value)
    helper.funcToXlsx("variables_output/", "XFODR", [sets["R"]], lambda R: model.XFODR[R].value)
    helper.funcToXlsx("variables_output/", "XSORGR", [sets["R"]], lambda R: model.XSORGR[R].value)
    helper.funcToXlsx("variables_output/", "XACROPR", [sets["R"]], lambda R: model.XACROPR[R].value)
    helper.funcToXlsx("variables_output/", "CPS", [], lambda: model.CPS.value)
    helper.funcToXlsx("variables_output/", "REGTRADE", [sets["C"], sets["R"]], lambda C, R: model.REGTRADE[C, R].value)
    helper.funcToXlsx("variables_output/", "IMPORTS", [sets["C"]], lambda C: model.IMPORTS[C].value)
    helper.funcToXlsx("variables_output/", "EXPORTS", [sets["C"]], lambda C: model.EXPORTS[C].value)
    helper.funcToXlsx("variables_output/", "TOTDIVAN", [], lambda: model.TOTDIVAN.value)

    print("Info: Variables exported")

print("Info: Printing selected parameters")

if not os.path.exists("output"):
    os.makedirs("output")

helper.funcToXlsx("output/", "LNDREQ", [sets["XC"], sets["PT"], sets["R"], sets["TM"]], lambda XC, PT, R, TM: LNDREQ(model, XC, PT, R, TM))
helper.funcToXlsx("output/", "LABREQC", [sets["XC"], sets["PT"], sets["R"], sets["TM"], sets["WI"]], lambda XC, PT, R, TM, WI: LABREQC(model, XC, PT, R, TM, WI))
helper.funcToXlsx("output/", "RAINFALL", [sets["XC"], sets["PT"], sets["R"]], lambda XC, PT, R: RAINFALL(model, XC, PT, R))
helper.funcToXlsx("output/", "WATER1", [sets["XC"], sets["PT"], sets["R"]], lambda XC, PT, R: WATER1(model, XC, PT, R))
helper.funcToXlsx("output/", "YIELD0", [sets["XC"], sets["C"], sets["R"]], lambda XC, C, R: YIELD0(model, XC, C, R))
helper.funcToXlsx("output/", "YIELD1", [sets["XC"], sets["PT"], sets["C"], sets["R"]], lambda XC, PT, C, R: YIELD1(model, XC, PT, C, R))
helper.funcToXlsx("output/", "TOT21", [sets["R"]], lambda R: TOT21(model, R))
helper.funcToXlsx("output/", "TOT25L", [sets["R"]], lambda R: TOT25L(model, R))
helper.funcToXlsx("output/", "TOT25M", [sets["R"]], lambda R: TOT25M(model, R))
helper.funcToXlsx("output/", "TOT25H", [sets["R"]], lambda R: TOT25H(model, R))
helper.funcToXlsx("output/", "TOT30L", [sets["R"]], lambda R: TOT30L(model, R))
helper.funcToXlsx("output/", "TOT30M", [sets["R"]], lambda R: TOT30M(model, R))
helper.funcToXlsx("output/", "TOT30H", [sets["R"]], lambda R: TOT30H(model, R))
helper.funcToXlsx("output/", "TOT35M", [sets["R"]], lambda R: TOT35M(model, R))
helper.funcToXlsx("output/", "TOT35H", [sets["R"]], lambda R: TOT35H(model, R))
helper.funcToXlsx("output/", "TOT37L", [sets["R"]], lambda R: TOT37L(model, R))
helper.funcToXlsx("output/", "TOT37M", [sets["R"]], lambda R: TOT37M(model, R))
helper.funcToXlsx("output/", "TOT37H", [sets["R"]], lambda R: TOT37H(model, R))
helper.funcToXlsx("output/", "RURPOPC", [], lambda: RURPOPC(model, ))
helper.funcToXlsx("output/", "URBPOPC", [], lambda: URBPOPC(model, ))
helper.funcToXlsx("output/", "TOTPOPC", [], lambda: TOTPOPC(model, ))
helper.funcToXlsx("output/", "SALRED", [sets["R"], sets["XC"]], lambda R, XC: SALRED(model, R, XC))
helper.funcToXlsx("output/", "HCOM", [sets["C"]], lambda C: HCOM(model, C))
helper.funcToXlsx("output/", "MUNDEM", [sets["R"]], lambda R: MUNDEM(model, R))
helper.funcToXlsx("output/", "MUNDEMTOT", [], lambda: MUNDEMTOT(model, ))
helper.funcToXlsx("output/", "CSTOINP", [sets["XC"], sets["PT"], sets["WI"], sets["C"], sets["R"]], lambda XC, PT, WI, C, R: CSTOINP(model, XC, PT, WI, C, R))
helper.funcToXlsx("output/", "BETACR", [sets["C"]], lambda C: BETACR(model, C))
helper.funcToXlsx("output/", "BETACU", [sets["C"]], lambda C: BETACU(model, C))
helper.funcToXlsx("output/", "ALPHACR", [sets["C"]], lambda C: ALPHACR(model, C))
helper.funcToXlsx("output/", "ALPHACU", [sets["C"]], lambda C: ALPHACU(model, C))
helper.funcToXlsx("output/", "EVAP", [sets["R"]], lambda R: EVAP(model, R))
helper.funcToXlsx("output/", "CROPCHARGE", [sets["XC"], sets["R"]], lambda XC, R: CROPCHARGE(model, XC, R))
helper.funcToXlsx("output/", "REPCA", [["TOTAL", "INTENSNL", "INTENSTY"] + sets["XC"], ["MALR", "EGYPT"] + sets["R"]], lambda DIM_0, DIM_1: REPCA(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "EFECTRAINR", [sets["R"]], lambda R: EFECTRAINR(model, R))
helper.funcToXlsx("output/", "EFECTRAINN", [], lambda: EFECTRAINN(model, ))
helper.funcToXlsx("output/", "EFECTRAIND", [], lambda: EFECTRAIND(model, ))
helper.funcToXlsx("output/", "REPWATBAL", [["REUSE_DELTA", "IND_CONSUM_VAR", "IND_CONSUM_EDR", "IND_CONSUM_MDR", "IND_CONSUM_WDR", "MUN_CONSUM_EX-DESIL_VAR", "MUN_CONSUM_EX-DESIL_EDR", "MUN_CONSUM_EX-DESIL_MDR", "MUN_CONSUM_EX-DESIL_WDR", "AGR_CONSUM_VAR", "AGR_CONSUM_EDR", "AGR_CONSUM_MDR", "AGR_CONSUM_WDR", "RESIDUAL", "WET_SURF_EVAP", "FALLOW_EVAP", "IND_CONSUM", "MUN_CONSUM_EX-DESIL", "AGR_CONSUM_GCCU", "DRAIN_TO_SINK", "FISH_POND_TO_SEA", "DRAIN_TO_SEA", "ADD_FLOW_TO_SEA", "ENV_FLOW_TO_SEA", "EFFECT_RAIN", "HAD_RELEASE"], [" "]], lambda DIM_0, DIM_1: REPWATBAL(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "DESAL", [sets["R"]], lambda R: DESAL(model, R))
helper.funcToXlsx("output/", "DESALTOT", [], lambda: DESALTOT(model, ))
helper.funcToXlsx("output/", "REPWATBALD", [["UNUSED", "FALLOW_EVAP", "IND_CONSUM", "MUN_CONSUM_EX-DESIL", "AGR_CONSUM_GCCU", "TO_SINK", "EFFECT_RAIN", "MAX_DEEPGW"], [" "]], lambda DIM_0, DIM_1: REPWATBALD(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "SYSTEMEF", [], lambda: SYSTEMEF(model, ))
helper.funcToXlsx("output/", "REPREUSED", [["TOTDELTA", "WESTDELTA", "MIDLDELTA", "EASTDELTA"]], lambda DIM_0: REPREUSED(model, DIM_0))
helper.funcToXlsx("output/", "REPDRASEAD", [["TOTDELTA", "WESTDELTA", "MIDLDELTA", "EASTDELTA"]], lambda DIM_0: REPDRASEAD(model, DIM_0))
helper.funcToXlsx("output/", "REPDIV", [["TOTAL", "IND", "MUN", "TOTAL-AG", "NSINAI", "TOSHKA", "OLDLANDS"] + sets["R"]], lambda DIM_0: REPDIV(model, DIM_0))
helper.funcToXlsx("output/", "REPDIV2", [["NSINAI", "TOSHKA", "OLDLANDS"] + sets["R"]], lambda DIM_0: REPDIV2(model, DIM_0))
helper.funcToXlsx("output/", "REPDIV3", [["OLDLANDS"] + sets["R"]], lambda DIM_0: REPDIV3(model, DIM_0))
helper.funcToXlsx("output/", "REPLABUSE", [sets["XC"]], lambda XC: REPLABUSE(model, XC))
helper.funcToXlsx("output/", "REPREVFG", [["EGYPT"] + sets["R"], ["FCOSTSP", "FCOSTSC", "FCOSTSA", "NPV", "FCOSTS", "GPV"]], lambda DIM_0, DIM_1: REPREVFG(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "REPREVFFG", [["EGYPT"] + sets["R"], ["NPVPWONL", "NPVPWOOL", "NPVPWORK", "NPVPFARM", "NPVPM3", "NPVPFED"]], lambda DIM_0, DIM_1: REPREVFFG(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "CPSUR", [], lambda: CPSUR(model, ))
helper.funcToXlsx("output/", "PSUR", [], lambda: PSUR(model, ))
helper.funcToXlsx("output/", "CSUR", [], lambda: CSUR(model, ))
helper.funcToXlsx("output/", "PRODVAL", [], lambda: PRODVAL(model, ))
helper.funcToXlsx("output/", "PRODVAL2", [], lambda: PRODVAL2(model, ))
helper.funcToXlsx("output/", "LANDSHAD", [sets["R"]], lambda R: LANDSHAD(model, R))
helper.funcToXlsx("output/", "LABSHAD", [sets["R"], sets["TM"]], lambda R, TM: LABSHAD(model, R, TM))
helper.funcToXlsx("output/", "WATERSHAD", [], lambda: WATERSHAD(model, ))
helper.funcToXlsx("output/", "PIMPC", [sets["C"]], lambda C: PIMPC(model, C))
helper.funcToXlsx("output/", "PEXPC", [sets["C"]], lambda C: PEXPC(model, C))
helper.funcToXlsx("output/", "REPIMP", [sets["C"], ["EGYPT"]], lambda C, DIM_1: REPIMP(model, C, DIM_1))
helper.funcToXlsx("output/", "REPEXP", [sets["C"], ["EGYPT"]], lambda C, DIM_1: REPEXP(model, C, DIM_1))
helper.funcToXlsx("output/", "REPNIMP", [sets["C"], ["EGYPT"]], lambda C, DIM_1: REPNIMP(model, C, DIM_1))
helper.funcToXlsx("output/", "REPVALIMP", [], lambda: REPVALIMP(model, ))
helper.funcToXlsx("output/", "REPVALEXP", [], lambda: REPVALEXP(model, ))
helper.funcToXlsx("output/", "REPPRODC", [sets["C"], ["EGYPT"] + sets["R"]], lambda DIM_0, DIM_1: REPPRODC(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "REPPRODA", [sets["C"], ["EGYPT"] + sets["R"]], lambda C, DIM_1: REPPRODA(model, C, DIM_1))
helper.funcToXlsx("output/", "REPCONS", [sets["C"], ["TR39", "EGYPT"]], lambda C, DIM_1: REPCONS(model, C, DIM_1))
helper.funcToXlsx("output/", "CAPCAL", [["PROTEIN", "FAT", "CALORI"]], lambda DIM_0: CAPCAL(model, DIM_0))
helper.funcToXlsx("output/", "REPFEED", [sets["FEEDS"], ["EGYPT"] + sets["R"]], lambda FEEDS, DIM_1: REPFEED(model, FEEDS, DIM_1))
helper.funcToXlsx("output/", "DURATION", [sets["XC"], sets["PT"], sets["R"]], lambda XC, PT, R: DURATION(model, XC, PT, R))
helper.funcToXlsx("output/", "REPIMPEXP", [["IMPEXPBAL"]], lambda DIM_0: REPIMPEXP(model, DIM_0))
helper.funcToXlsx("output/", "REPWATCHAR", [["EGYPT"]], lambda DIM_0: REPWATCHAR(model, DIM_0))
helper.funcToXlsx("output/", "SELFFOOD", [["CEREALS", "VEG-OIL", "MILK", "MEAT", "SUGAR", "RICE", "MAIZE", "WHEAT"]], lambda DIM_0: SELFFOOD(model, DIM_0))
helper.funcToXlsx("output/", "WATDIST", [sets["R"]], lambda R: WATDIST(model, R))
helper.funcToXlsx("output/", "WATDISTE", [], lambda: WATDISTE(model, ))
helper.funcToXlsx("output/", "SCORR", [sets["R"]], lambda R: SCORR(model, R))
helper.funcToXlsx("output/", "NONSCORR", [sets["R"]], lambda R: NONSCORR(model, R))
helper.funcToXlsx("output/", "NONSCORE", [], lambda: NONSCORE(model, ))
helper.funcToXlsx("output/", "REPFEED1", [sets["R"], sets["C"], sets["FCTYPE"]], lambda R, C, FCTYPE: REPFEED1(model, R, C, FCTYPE))
helper.funcToXlsx("output/", "REPCA1", [sets["R"], sets["XC"], sets["PT"], sets["WI"]], lambda R, DIM_1, DIM_2, WI: REPCA1(model, R, DIM_1, DIM_2, WI))
helper.funcToXlsx("output/", "REPCA2", [sets["R"], ["%FALLOW", "QLNDSUP", "TOTAL", "FALLOW", "S-TOTAL"] + sets["XC"], ["*"] + sets["PT"], sets["TM"]], lambda R, DIM_1, DIM_2, TM: REPCA2(model, R, DIM_1, DIM_2, TM))
helper.funcToXlsx("output/", "QLNDSUP", [sets["R"]], lambda R: QLNDSUP(model, R))
helper.funcToXlsx("output/", "TOTPOPF", [], lambda: TOTPOPF(model, ))
helper.funcToXlsx("output/", "TOTAREA", [], lambda: TOTAREA(model, ))
helper.funcToXlsx("output/", "TOTNAREA", [], lambda: TOTNAREA(model, ))
helper.funcToXlsx("output/", "BASEAREA", [], lambda: BASEAREA(model, ))
helper.funcToXlsx("output/", "REPETC1", [sets["C"], ["BCM"]], lambda C, DIM_1: REPETC1(model, C, DIM_1))
helper.funcToXlsx("output/", "REPETC2", [sets["C"], ["m3/t"]], lambda C, DIM_1: REPETC2(model, C, DIM_1))
helper.funcToXlsx("output/", "VIRWATIMP", [], lambda: VIRWATIMP(model, ))
helper.funcToXlsx("output/", "VIRWATEXP", [], lambda: VIRWATEXP(model, ))
helper.funcToXlsx("output/", "VIRWATNIN", [], lambda: VIRWATNIN(model, ))
helper.funcToXlsx("output/", "VIRWATNINC", [sets["C"], ["Mm3"]], lambda C, DIM_1: VIRWATNINC(model, C, DIM_1))
helper.funcToXlsx("output/", "WATPRO", [], lambda: WATPRO(model, ))
helper.funcToXlsx("output/", "DROPCROPA", [sets["XC"], sets["C"], sets["PT"], sets["WI"], sets["R"]], lambda XC, C, PT, WI, R: DROPCROPA(model, XC, C, PT, WI, R))
helper.funcToXlsx("output/", "DROPCROPR", [sets["XC"], sets["C"], sets["PT"], sets["WI"], sets["R"]], lambda XC, C, PT, WI, R: DROPCROPR(model, XC, C, PT, WI, R))
helper.funcToXlsx("output/", "DROPCROPP", [sets["XC"], sets["C"], sets["PT"], sets["WI"], sets["R"]], lambda XC, C, PT, WI, R: DROPCROPP(model, XC, C, PT, WI, R))
helper.funcToXlsx("output/", "CROPDROPA", [sets["XC"], sets["C"], sets["PT"], sets["WI"], sets["R"]], lambda XC, C, PT, WI, R: CROPDROPA(model, XC, C, PT, WI, R))
helper.funcToXlsx("output/", "CROPDROPR", [sets["XC"], sets["C"], sets["PT"], sets["WI"], sets["R"]], lambda XC, C, PT, WI, R: CROPDROPR(model, XC, C, PT, WI, R))
helper.funcToXlsx("output/", "CROPDROPP", [sets["XC"], sets["C"], sets["PT"], sets["WI"], sets["R"]], lambda XC, C, PT, WI, R: CROPDROPP(model, XC, C, PT, WI, R))
helper.funcToXlsx("output/", "ACRODROPAU", [sets["XC"], ["kg/m3"]], lambda XC, DIM_1: ACRODROPAU(model, XC, DIM_1))
helper.funcToXlsx("output/", "ACRODROPAM", [sets["XC"], ["kg/m3"]], lambda XC, DIM_1: ACRODROPAM(model, XC, DIM_1))
helper.funcToXlsx("output/", "ACRODROPAL", [sets["XC"], ["kg/m3"]], lambda XC, DIM_1: ACRODROPAL(model, XC, DIM_1))
helper.funcToXlsx("output/", "ACRODROPRL", [sets["XC"], ["kg/m3"]], lambda XC, DIM_1: ACRODROPRL(model, XC, DIM_1))
helper.funcToXlsx("output/", "ACRODROPPU", [sets["XC"], ["m3/t"]], lambda XC, DIM_1: ACRODROPPU(model, XC, DIM_1))
helper.funcToXlsx("output/", "ACRODROPPM", [sets["XC"], ["m3/t"]], lambda XC, DIM_1: ACRODROPPM(model, XC, DIM_1))
helper.funcToXlsx("output/", "ACRODROPPL", [sets["XC"], ["m3/t"]], lambda XC, DIM_1: ACRODROPPL(model, XC, DIM_1))
helper.funcToXlsx("output/", "BUCKDROPA", [sets["XC"], sets["C"], sets["PT"], sets["WI"], sets["R"]], lambda XC, C, PT, WI, R: BUCKDROPA(model, XC, C, PT, WI, R))
helper.funcToXlsx("output/", "BUCKDROPR", [sets["XC"], sets["C"], sets["PT"], sets["WI"], sets["R"]], lambda XC, C, PT, WI, R: BUCKDROPR(model, XC, C, PT, WI, R))
helper.funcToXlsx("output/", "BUCKDROPP", [sets["XC"], sets["C"], sets["PT"], sets["WI"], sets["R"]], lambda XC, C, PT, WI, R: BUCKDROPP(model, XC, C, PT, WI, R))
helper.funcToXlsx("output/", "ADRPCROPAU", [sets["XC"], ["m3/t"]], lambda XC, DIM_1: ADRPCROPAU(model, XC, DIM_1))
helper.funcToXlsx("output/", "ADRPCROPAM", [sets["XC"], ["m3/t"]], lambda XC, DIM_1: ADRPCROPAM(model, XC, DIM_1))
helper.funcToXlsx("output/", "ADRPCROPAL", [sets["XC"], ["m3/t"]], lambda XC, DIM_1: ADRPCROPAL(model, XC, DIM_1))
helper.funcToXlsx("output/", "ADRPCROPRL", [sets["XC"], ["m3/t"]], lambda XC, DIM_1: ADRPCROPRL(model, XC, DIM_1))
helper.funcToXlsx("output/", "ADRPCROPPU", [sets["XC"], ["m3/t"]], lambda XC, DIM_1: ADRPCROPPU(model, XC, DIM_1))
helper.funcToXlsx("output/", "ADRPCROPPM", [sets["XC"], ["m3/t"]], lambda XC, DIM_1: ADRPCROPPM(model, XC, DIM_1))
helper.funcToXlsx("output/", "ADRPCROPPL", [sets["XC"], ["m3/t"]], lambda XC, DIM_1: ADRPCROPPL(model, XC, DIM_1))
helper.funcToXlsx("output/", "ABUCKDRPAU", [sets["XC"], ["LE/m3"]], lambda XC, DIM_1: ABUCKDRPAU(model, XC, DIM_1))
helper.funcToXlsx("output/", "ABUCKDRPAM", [sets["XC"], ["LE/m3"]], lambda XC, DIM_1: ABUCKDRPAM(model, XC, DIM_1))
helper.funcToXlsx("output/", "ABUCKDRPAL", [sets["XC"], ["LE/m3"]], lambda XC, DIM_1: ABUCKDRPAL(model, XC, DIM_1))
helper.funcToXlsx("output/", "ABUCKDRPRL", [sets["XC"], ["LE/m3"]], lambda XC, DIM_1: ABUCKDRPRL(model, XC, DIM_1))
helper.funcToXlsx("output/", "ABUCKDRPPU", [sets["XC"], ["LE/m3"]], lambda XC, DIM_1: ABUCKDRPPU(model, XC, DIM_1))
helper.funcToXlsx("output/", "ABUCKDRPPM", [sets["XC"], ["LE/m3"]], lambda XC, DIM_1: ABUCKDRPPM(model, XC, DIM_1))
helper.funcToXlsx("output/", "ABUCKDRPPL", [sets["XC"], ["LE/m3"]], lambda XC, DIM_1: ABUCKDRPPL(model, XC, DIM_1))
helper.funcToXlsx("output/", "CROPVIEW", [sets["XC"], sets["C"], ["NPV/m3", "NPV-FGP", "PPRCCST", "MARKCST", "PRODCST", "OIPCST", "LABCST", "WATUSE", "WATREQ", "FGP-PRICE", "MKT-PRICE", "PROD/FED", "PROD", "AREA"]], lambda XC, C, DIM_2: CROPVIEW(model, XC, C, DIM_2))
helper.funcToXlsx("output/", "CROPFED", [sets["XC"]], lambda XC: CROPFED(model, XC))
helper.funcToXlsx("output/", "CROPFEDR", [sets["XC"], sets["R"]], lambda XC, R: CROPFEDR(model, XC, R))
helper.funcToXlsx("output/", "HAREASDI", [sets["XC"], ["TOTAL", "DEEPGW", "VALLEY", "EASTDEL", "MIDDEL", "WESTDEL"]], lambda XC, DIM_1: HAREASDI(model, XC, DIM_1))
helper.funcToXlsx("output/", "QFERT", [["EGYPT"] + sets["R"], ["TOTAL"] + sets["XC"], sets["FERT"]], lambda DIM_0, DIM_1, FERT: QFERT(model, DIM_0, DIM_1, FERT))
helper.funcToXlsx("output/", "EFERT", [["EGYPT"] + sets["R"], ["TOTAL"] + sets["XC"], sets["FERT"]], lambda DIM_0, DIM_1, FERT: EFERT(model, DIM_0, DIM_1, FERT))
helper.funcToXlsx("output/", "TFERT", [["EGYPT", "TOTAL"] + sets["R"], ["TOTAL"] + sets["XC"]], lambda DIM_0, DIM_1: TFERT(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "ETFERT", [["EGYPT", "TOTAL"] + sets["R"], ["TOTAL"] + sets["XC"]], lambda DIM_0, DIM_1: ETFERT(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "WATPUMP", [["EGYPT", "TOTAL"] + sets["R"], ["TOTAL"] + sets["XC"]], lambda DIM_0, DIM_1: WATPUMP(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "EWATPUMP", [["EGYPT", "TOTAL"] + sets["R"], ["TOTAL"] + sets["XC"]], lambda DIM_0, DIM_1: EWATPUMP(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "EWATPPXCN", [["AVERAGE"] + sets["XC"], ["AVERAGE"] + sets["R"]], lambda DIM_0, DIM_1: EWATPPXCN(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "EWATPPXCD", [["AVERAGE"] + sets["XC"], ["AVERAGE"] + sets["R"]], lambda DIM_0, DIM_1: EWATPPXCD(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "EWATPPXCNA", [sets["XC"], ["AVERAGE"]], lambda DIM_0, DIM_1: EWATPPXCNA(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "EWATPPXCDA", [sets["XC"], ["AVERAGE"]], lambda DIM_0, DIM_1: EWATPPXCDA(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "TCOM", [["EGYPT", "TOTAL"] + sets["R"], ["TOTAL"] + sets["C"]], lambda DIM_0, DIM_1: TCOM(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "ECOM", [["EGYPT", "TOTAL"] + sets["R"], ["TOTAL"] + sets["C"]], lambda DIM_0, DIM_1: ECOM(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "QTMECH", [["EGYPT"] + sets["R"], ["TOTAL"] + sets["XC"]], lambda DIM_0, DIM_1: QTMECH(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "ETMECH", [["EGYPT", "TOTAL"] + sets["R"], ["TOTAL"] + sets["XC"]], lambda DIM_0, DIM_1: ETMECH(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "TOTENERGY", [["EGYPT", "TOTAL"] + sets["R"], ["TOTAL"] + sets["XC"]], lambda DIM_0, DIM_1: TOTENERGY(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "QAGPROCES", [["EGYPT"] + sets["R"], ["TOTAL"] + sets["CIP"]], lambda DIM_0, DIM_1: QAGPROCES(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "EAGPROCES", [["EGYPT"] + sets["R"], ["TOTAL"] + sets["CIP"]], lambda DIM_0, DIM_1: EAGPROCES(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "COMENERGY", [["TOTAL"] + sets["C"], ["MJ"]], lambda DIM_0, DIM_1: COMENERGY(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "COMENERGYT", [sets["C"], ["MJ/t"]], lambda DIM_0, DIM_1: COMENERGYT(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "COMENERGYJ", [sets["C"], ["kg/TJ"]], lambda DIM_0, DIM_1: COMENERGYJ(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "COMENERGYV", [sets["C"], ["MJ"]], lambda DIM_0, DIM_1: COMENERGYV(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "COMENERGYR", [sets["C"], ["EU/EV"]], lambda DIM_0, DIM_1: COMENERGYR(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "VIRTENEXP", [["EGGS", "SGMT", "FBEEF", "CBEEF", "VEAL", "CMILK", "BMILK", "IMILK"] + sets["C"], ["MJ"]], lambda DIM_0, DIM_1: VIRTENEXP(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "VIRTENIMP", [["EGGS", "SGMT", "FBEEF", "CBEEF", "VEAL", "CMILK", "BMILK", "IMILK"] + sets["C"], ["MJ"]], lambda DIM_0, DIM_1: VIRTENIMP(model, DIM_0, DIM_1))
helper.funcToXlsx("output/", "VIRTENNIMP", [sets["C"], ["MJ"]], lambda DIM_0, DIM_1: VIRTENNIMP(model, DIM_0, DIM_1))
