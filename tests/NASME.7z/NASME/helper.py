import numpy as np
import pandas as pd
import os
import itertools 
import traceback

class Value:
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return str(self.value)
    def __repr__(self):
        return str(self.value)
    def __add__(self, other):
        if type(other) == Value:
            return self.value + other.value
        else:
            return self.value + other
    def __radd__(self, other):
        return self.__add__(other)
    def __sub__(self, other):
        if type(other) == Value:
            return self.value - other.value
        else:
            return self.value - other
    def __rsub__(self, other):
        if type(other) == Value:
            return other.value - self.value
        else:
            return other - self.value
    def __mul__(self, other):
        if type(other) == Value:
            return self.value * other.value
        else:
            return self.value * other
    def __rmul__(self, other):
        return self.__mul__(other)
    def __truediv__(self, other):
        if type(other) == Value:
            return self.value / other.value
        else:
            return self.value / other
    def __rtruediv__(self, other):
        if type(other) == Value:
            return other.value / self.value
        else:
            return other / self.value 
    def __pow__(self, other):
        if type(other) == Value:
            return self.value ** other.value
        else:
            return self.value ** other
    def __rpow__(self, other):
        if type(other) == Value:
            return other.value ** self.value
        else:
            return other ** self.value
    def __lt__(self, other):
        if type(other) == Value:
            return self.value < other.value
        else:
            return self.value < other
    def __le__(self, other):
        if type(other) == Value:
            return self.value <= other.value
        else:
            return self.value <= other
    def __eq__(self, other):
        if type(other) == Value:
            return self.value == other.value
        else:
            return self.value == other
    def __ne__(self, other):
        if type(other) == Value:
            return self.value != other.value
        else:
            return self.value != other
    def __gt__(self, other):
        if type(other) == Value:
            return self.value > other.value
        else:
            return self.value > other
    def __ge__(self, other):
        if type(other) == Value:
            return self.value >= other.value
        else:
            return self.value >= other
    def __neg__(self):
        return -self.value
    def __pos__(self):
        return +self.value
    def __abs__(self):
        return abs(self.value)
    def __round__(self, n):
        return round(self.value, n)
    def __floor__(self):
        return np.floor(self.value)
    def __ceil__(self):
        return np.ceil(self.value)
    def __trunc__(self):
        return np.trunc(self.value)
    def __int__(self):
        return int(self.value)
    def __float__(self):
        return float(self.value)
    def __bool__(self):
        return bool(self.value)

class DualUnavailable(Exception):
    pass

class Dual:
    def __init__(self):
        pass
  
    def __getitem__(self, key):
        raise DualUnavailable("Dual unavailable")

class Model:
    def __init__(self):
        pass

def makeModel(path):

    model = Model()

    setattr(model, "dual", Dual())

    for filename in os.listdir(path):
        variable = filename.split(".")[0]

        f = os.path.join(path, filename)
        df = pd.read_excel(f)

        if "names" not in df:
            setattr(model, variable, Value(df[variable][0]))

        elif len(df.columns) == 2 and df.columns[1] == "values":
            setattr(model, variable, {})

            for i in range(len(df["names"])):
                key = df["names"][i]
                value = df["values"][i]
                getattr(model, variable)[key] = Value(value)

        else:
            setattr(model, variable, {})

            for column in df:
                if column != "names":
                    for i in range(len(df[column])):
                        key = df["names"][i].split(".") + [column]
                        value = df[column][i]
                        getattr(model, variable)[tuple(key)] = Value(value)

    return model

def toString(value, width, digits):
    if value is None:
        return "None".rjust(width)
    elif type(value) is str:
        return value.rjust(width)
    else:
        return f'{value:{width}.{digits}f}'
    
def loadScalars(path):
    df = pd.read_excel(path)
    scalars = {}

    for i in range(len(df["name"])):
        scalars[df["name"][i]] = df["value"][i]

    return scalars

def loadParameter(path):
    df = pd.read_excel(path)
    parameter = {}

    for i in range(len(df["index"])):
        parameter[df["index"][i]] = df["value"][i]

    return parameter

def funcToXlsx(folder, name, sets, func):
    try:
        if len(sets) == 0:
            try:
                df = pd.DataFrame(data = { name : func() }, index = [0])
            except KeyboardInterrupt:
                exit()
            except DualUnavailable as e:
                print("Warning: Dual unavailable in exporting " + name + ", skip")
                return
            except RecursionError as re:
                print("Recursion error in exporting " + name)
                traceback.print_exc()
                return
            except Exception as e:
                df = pd.DataFrame(data = { name : 0 }, index = [0])

            df.to_excel(folder + name + ".xlsx", sheet_name = "data", index = False)

        elif len(sets) == 1:
            names = sets[0]
            values = []
            
            for e in sets[0]:
                try:
                    values.append(func(e))
                except KeyboardInterrupt:
                    exit()
                except DualUnavailable as e:
                    print("Warning: Dual unavailable in exporting " + name + ", skip")
                    return
                except RecursionError as re:
                    print("Recursion error in exporting " + name)
                    traceback.print_exc()
                    return
                except Exception as e:
                    values.append(0)

            df = pd.DataFrame(data = {"names" : names, "values" : values}, index = np.arange(len(values)))
            df.to_excel(folder + name + ".xlsx", sheet_name = "data", index = False)

        else:
            values = {}
            values["names"] = [".".join(x) for x in itertools.product(*sets[:-1])]

            for col in sets[-1]:
                values[col] = []

                for dims in itertools.product(*sets[:-1]):
                    try:
                        values[col].append(func(*dims, col))
                    except KeyboardInterrupt:
                        exit()
                    except DualUnavailable as e:
                        print("Warning: Dual unavailable in simulation mode for " + name + ", skip")
                        return
                    except RecursionError as re:
                        print("Recursion error in exporting " + name)
                        traceback.print_exc()
                        return
                    except Exception as e:
                        values[col].append(0)

            df = pd.DataFrame(data = values)
            df.to_excel(folder + name + ".xlsx", sheet_name = "data", index = False)

    except KeyboardInterrupt:
        exit()
    except Exception as e:
        print("Error in exporting " + name + " (" + str(e) + "):")
        traceback.print_exc()

def appendFile(file, listOfParts):
    try:
        line = ""
        for part in listOfParts:
            if callable(part):
                line += str(part())
            else:
                line += str(part)
        file.write(line)
    except KeyboardInterrupt:
        exit()
    except DualUnavailable as e:
        line = ""
        for part in listOfParts:
            if callable(part):
                line += "<Dual unavailable>"
            else:
                line += str(part)
        while "  " in line:
            line = line.replace("  ", " ")
        print("Warning: Dual unavailable in simulation mode for \"" + line.replace("\n", "") + "\", skip")
        return
    except Exception as e:
        line = ""
        for part in listOfParts:
            if callable(part):
                line += "<Error>"
            else:
                line += str(part)
        print("Error in appending file: " + line)
        traceback.print_exc()