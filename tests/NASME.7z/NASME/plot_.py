##########################
# By Hosam El Nagar
# This will plot outputs
##########################

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# output_file = "output\INDICATOR_WB.txt"

output_file = r"output\REPCA.xlsx"
cols = ['names', 'MALR', 'EGYPT']

df = pd.read_excel(output_file, usecols=cols, index_col="names")

df.index.names = ['Crops']
df.rename(columns={'EGYPT': 'Model'}, inplace=True, errors='raise')


df = df.T
totals = df.pop("TOTAL")
df = df.T

myplot = sns.lineplot(df, markers=True, dashes=False)
myplot.axes.text(0, 5000, totals.to_string())
myplot.set_xticklabels(myplot.get_xticklabels(), rotation=90, size=6)
plt.show()
